 

import bpy
from bpy_extras import anim_utils

from .. import utils

group_name = 'animaide'
user_preview_range = {}
user_scene_range = {}

def get_fcurve_for_obj(obj):
    fcurves = list()

    # if obj.type == "GREASEPENCIL" or obj.type == "GREASEPENCIL_V3":
        
    #     action = bpy.data.grease_pencils.new(obj.data.name)
    #     print("find now layers-------- " +str(action.layers))
    #     print("find now layers-------- " +str(action.layers[0].current_frame()))
        
    #     if getattr(obj.data, "grease_pencils", None):
    #         if obj.data.grease_pencils.animation_data and obj.data.grease_pencils.animation_data.action:
    #             gp_action = obj.data.grease_pencils.animation_data.action
    #             list_fcurves = get_fcurves_for_action(gp_action)
    #             fcurves.extend(list_fcurves)

    
    if getattr(obj.data, "shape_keys", None) and obj.data.shape_keys.animation_data and obj.data.shape_keys.animation_data.action:
        shapes_action = obj.data.shape_keys.animation_data.action
        list_fcurves = get_fcurves_for_action(shapes_action)
        fcurves.extend(list_fcurves)

    if obj.animation_data and obj.animation_data.action:
        list_fcurves = utils.curve.get_fcurves_for_action(obj.animation_data.action)
        fcurves.extend(list_fcurves)

        # data = getattr(obj.data, other, None)
        # if data and getattr(obj.data, "animation_data", None) and data.animation_data.action:
        #     action = data.animation_data.action
        #     list_fcurves = utils.curve.get_fcurves_for_action(action)
        #     fcurves.extend(list_fcurves)

    return fcurves
    
def get_fcurves_for_action(action, only_first_slot = False):
    if not action:
        return list()
    
    channelbag = None
    fcurves = list()
    for slot in action.slots:
        channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)
        if not channelbag:
            if len(action.layers) == 0:
                action.layers.new("layer0")
            if len(action.layers[0].strips) == 0:
                action.layers[0].strips.new(type='KEYFRAME')
            channelbag = action.layers[0].strips[0].channelbag(slot, ensure=True)

        if only_first_slot:
            return channelbag.fcurves if channelbag else list()
        
        fcurves.extend(channelbag.fcurves)
        
    return fcurves


def get_fcurves_list(fcurves_collection):
    if fcurves_collection is None:
        return []

    try:
        return list(fcurves_collection)
    except TypeError:
        try:
            return [f for _, f in fcurves_collection.items()]
        except (TypeError, AttributeError):
            return []


def get_fcurve_count(fcurves_collection):
    if fcurves_collection is None:
        return 0

    try:
        return len(fcurves_collection)
    except TypeError:
        return len(get_fcurves_list(fcurves_collection))


def get_first_fcurve(fcurves_collection):
    if fcurves_collection is None:
        return None

    try:
        return fcurves_collection[0]
    except (TypeError, KeyError, IndexError):
        fcurves_list = get_fcurves_list(fcurves_collection)
        return fcurves_list[0] if fcurves_list else None


def new_fcurve(fcurves, data_path, index, group_name_value):
    """Create new fcurve with correct parameter name for Blender version"""
    return fcurves.new(data_path=data_path, index=index, group_name=group_name_value)


def add_curve3d(context, name, key_amount=0):
    curve_data = bpy.data.curves.new(name, 'CURVE')
    spline = curve_data.splines.new('BEZIER')
    if key_amount > 0:
        spline.bezier_points.add(key_amount)
    obj = bpy.data.objects.new(name, curve_data)
    context.collection.objects.link(obj)
    return obj


def new(action_group_name, keys_to_add, key_interp='AUTO_CLAMPED', color=(1, 1, 1)):
    action = utils.set_animaide_action()
    fcurves = get_fcurves_for_action(action, only_first_slot = True)
    
    # if not fcurves:
    #     return None

    blends_curve = new_fcurve(fcurves, data_path=group_name, index=0, group_name_value=action_group_name)
    blends_curve.color_mode = 'CUSTOM'
    blends_curve.color = color
    keys = blends_curve.keyframe_points
    keys.add(keys_to_add)

    for k in keys:
        k.handle_left_type = key_interp
        k.handle_right_type = key_interp

    blends_curve.lock = True
    blends_curve.select = True
    blends_curve.keyframe_points.sort()
    blends_curve.keyframe_points.handles_recalc()
    
    return blends_curve


def create_path(context, fcurves):
    curve_obj = add_curve3d(context, "animaide_path")
    curve_obj.data.dimensions = '3D'
    curve_obj.data.bevel_depth = 0.1

    x = {}
    y = {}
    z = {}
    frames = []
    for fcurve in fcurves:
        if fcurve.data_path == 'location':
            for k in fcurve.keyframe_points:
                f = k.co.x
                if f not in frames:
                    frames.append(f)
                if fcurve.array_index == 0:
                    x['curve'] = fcurve
                    x[f] = k.co.y
                elif fcurve.array_index == 1:
                    y['curve'] = fcurve
                    y[f] = k.co.y
                elif fcurve.array_index == 2:
                    z['curve'] = fcurve
                    z[f] = k.co.y
    frames.sort()
    print(f'frames: {frames}')
    print(f'x: {x}')
    print(f'y: {y}')
    print(f'z: {z}')
    points = curve_obj.data.splines[0].bezier_points
    points.add(len(frames))
    print(f'amount of frames: {len(frames)}')
    n = 0
    for f in frames:
        if x.get(f) is None:
            points[n].co.x = x['curve'].evaluate(f)
        else:
            points[n].co.x = x.get(f)

        if y.get(f) is None:
            points[n].co.y = y['curve'].evaluate(f)
        else:
            points[n].co.y = y.get(f)

        if x.get(f) is None:
            points[n].co.z = z['curve'].evaluate(f)
        else:
            points[n].co.z = z.get(f)

        points[n].handle_left_type = 'AUTO'
        points[n].handle_right_type = 'AUTO'

        print(f'frame: {f}')
        print(f'point coordinate: {points[n].co}')
        print(f'n: {n}')

        n += 1


def get_selected(fcurves):
    """return selected fcurves in the current action with the exception of the reference fcurves"""

    selected = []

    for fcurve in fcurves:
        if getattr(fcurve.group, 'name', None) == group_name:
            continue        # we don't want to add to the list the helper curves we have created

        if fcurve.select:
            selected.append(fcurve)

    return selected


def get_all_action(obj):
    actions = list()

    if obj.animation_data and obj.animation_data.action:
        actions.append(obj.animation_data.action)
   
    if getattr(obj.data, "shape_keys", None) and obj.data.shape_keys.animation_data and obj.data.shape_keys.animation_data.action:
        actions.append(obj.data.shape_keys.animation_data.action)
    
    return actions


def remove_helpers(objects):
    for obj in objects:
        action = obj.animation_data.action

        for slot in action.slots:
            channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)
            fcurves_list = get_fcurves_list(channelbag.fcurves)
            for fcurve in fcurves_list:
                if getattr(fcurve.group, 'name', None) == group_name:
                    channelbag.fcurves.remove(fcurve)


def remove_fcurve(objects, curve):
    for obj in objects:
        action = obj.animation_data.action

        for slot in action.slots:
            channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)
            fcurves_list = get_fcurves_list(channelbag.fcurves)
            for fcurve in fcurves_list:
                if fcurve.data_path == curve.data_path:
                    channelbag.fcurves.remove(fcurve)



def get_slope(fcurve):
    """Gets the slope of a curve at a specific range"""
    selected_keys = utils.key.get_selected_index(fcurve)
    first_key, last_key = utils.key.first_and_last_selected(fcurve, selected_keys)
    slope = (first_key.co.y**2 - last_key.co.y**2) / \
        (first_key.co.x**2 - last_key.co.x**2)
    return slope


def add_cycle(fcurve, before='MIRROR', after='MIRROR'):
    """Adds cycle modifier to an fcurve"""
    cycle = fcurve.modifiers.new('CYCLES')

    cycle.mode_before = before
    cycle.mode_after = after


def duplicate(fcurve, selected_keys=True, before='NONE', after='NONE', lock=False):
    action = fcurve.id_data
    fcurves = get_fcurves_for_action(action, only_first_slot = True)

    # if fcurves is None:
    #     return None

    index = get_fcurve_count(fcurves)

    if selected_keys:
        selected_keys = get_selected(fcurve)
    else:
        selected_keys = fcurve.keyframe_points.items()

    clone_name = '%s.%d.clone' % (fcurve.data_path, fcurve.array_index)

    dup = new_fcurve(fcurves, data_path=clone_name, index=index, group_name_value=group_name)
    dup.keyframe_points.add(len(selected_keys))
    dup.color_mode = 'CUSTOM'
    dup.color = (0, 0, 0)

    dup.lock = lock
    dup.select = False

    # Blender < 5.0 has action groups; Blender 5.0+ uses slots/layers system

    for i, (index, key) in enumerate(selected_keys):
        dup.keyframe_points[i].co = key.co

    add_cycle(dup, before=before, after=after)

    dup.keyframe_points.sort()
    dup.keyframe_points.handles_recalc()

    return dup
    

def duplicate_from_data(fcurves, global_fcurve, new_data_path, before='NONE', after='NONE', lock=False):
    """Duplicates a curve using the global values"""
    index = 0
    if fcurves: 
        index = len(fcurves)
    every_key = global_fcurve['every_key']
    original_keys = global_fcurve['original_keys']

    dup = new_fcurve(fcurves, data_path=new_data_path, index=index, group_name_value=group_name)
    dup.keyframe_points.add(len(every_key))
    dup.color_mode = 'CUSTOM'
    dup.color = (0, 0, 0)

    dup.lock = lock
    dup.select = False

    i = 0

    for index in every_key:
        dup.keyframe_points[i].co.x = original_keys[index]['x']
        dup.keyframe_points[i].co.y = original_keys[index]['y']

        i += 1

    add_cycle(dup, before=before, after=after)

    dup.keyframe_points.sort()
    dup.keyframe_points.handles_recalc()

    return dup


def add_clone(objects, cycle_before='NONE', cycle_after="NONE", selected_keys=False):
    for obj in objects:
        # action = obj.animation_data.action
        # fcurves = get_fcurves_for_action(action)
        fcurves = get_fcurve_for_obj(obj)
        if fcurves is None:
            continue

        fcurves_list = get_fcurves_list(fcurves)
        for fcurve in fcurves_list:
            if getattr(fcurve.group, 'name', None) == group_name:
                continue

            if fcurve.hide or not fcurve.select:
                continue

            duplicate(fcurve, selected_keys=selected_keys, before=cycle_before, after=cycle_after)

            fcurve.keyframe_points.sort()
            fcurve.keyframe_points.handles_recalc()


def remove_clone(objects):
    for obj in objects:
        # action = obj.animation_data.action
        # fcurves = get_fcurves_for_action(action)
        fcurves = get_fcurve_for_obj(obj)

        if fcurves is None:
            continue

        animaide = bpy.context.scene.animretarget
        aclones = animaide.clone_data.clones
        clones_n = len(aclones)
        fcurves_list = get_fcurves_list(fcurves)
        blender_n = len(fcurves_list) - clones_n

        for n in range(clones_n):
            if blender_n + n < len(fcurves_list):
                maybe_clone = fcurves_list[blender_n + n]
                if 'clone' in maybe_clone.data_path:
                    #fcurves.remove(maybe_clone)
                    remove_fcurve(obj, maybe_clone)
                    aclones.remove(0)


def move_clone(objects):
    for obj in objects:
        # action = obj.animation_data.action
        # fcurves = get_fcurves_for_action(action)
        fcurves = get_fcurve_for_obj(obj)

        if fcurves is None:
            continue

        fcurves_list = get_fcurves_list(fcurves)

        animaide = bpy.context.scene.animretarget
        aclone_data = animaide.clone_data
        aclones = aclone_data.clones
        move_factor = aclone_data.move_factor

        for aclone in aclones:
            if aclone.fcurve.index < len(fcurves_list) and aclone.original_fcurve.index < len(fcurves_list):
                clone = fcurves_list[aclone.fcurve.index]
                fcurve = fcurves_list[aclone.original_fcurve.index]
                selected_keys = utils.key.get_selected_index(fcurve)
                key1, key2 = utils.key.first_and_last_selected(fcurve, selected_keys)
                amount = abs(key2.co.x - key1.co.x)
                for key in clone.keyframe_points:
                    key.co.x = key.co.x + (amount * move_factor)

                clone.keyframe_points.sort()
                clone.keyframe_points.handles_recalc()

                utils.key.attach_selection_to_fcurve(
                    fcurve, clone, is_gradual=False)

                fcurve.keyframe_points.sort()
                fcurve.keyframe_points.handles_recalc()



def valid_obj(context, obj, check_ui=True):

    # fcurves = get_fcurve_for_obj(obj)
    # if not fcurves:
    #     return False

    if check_ui:
        visible = obj.visible_get()

        if context.area.type != 'VIEW_3D':
            if not context.space_data.dopesheet.show_hidden and not visible:
                return False

    return True


def are_frames_selected_in_fcurve(fcurve):
    for keyframe in fcurve.keyframe_points:
        if keyframe.select_control_point:
            return True
    return False


def valid_fcurve(context, obj, fcurve, action_type='transfrom_action', check_ui=True, checkselect = True):

    if not fcurve:
        return False

    if checkselect and not are_frames_selected_in_fcurve(fcurve):
        return False

    try:
        # if action_type == 'transfrom_action' and obj.type == 'ARMATURE':
        prop = obj.path_resolve(fcurve.data_path)
    except:
        prop = None


    if check_ui and context.area.type == 'GRAPH_EDITOR':
        if context.space_data.use_only_selected_keyframe_handles and not fcurve.select:
            return False

        # if context.area.type != 'VIEW_3D':
        if fcurve.lock or fcurve.hide:
            return False

    if getattr(fcurve.group, 'name', None) == utils.curve.group_name:
        return False  # we don't want to select keys on reference fcurves

    if prop != None:
        if obj.type == 'ARMATURE':

            if getattr(fcurve.group, 'name', None) == 'Object Transforms':
                # When animating an object, by default its fcurves grouped with this name.
                return False

            elif not fcurve.group:
                transforms = (
                    'location', 'rotation_euler', 'scale',
                    'rotation_quaternion', 'rotation_axis_angle',
                    '[\"',  # custom property
                )
                if fcurve.data_path.startswith(transforms):
                    # fcurve belongs to the  object, so skip it
                    return False

            # if fcurve.group.name not in bones_names:
                # return

            split_data_path = fcurve.data_path.split(sep='"')
            if len(split_data_path) > 1:
                bone_name = split_data_path[1]
                bone = obj.data.bones.get(bone_name)
            else:
                bone = None

            if not bone:
                return False

            if check_ui:
                if bone.hide:
                    return False

                pose_bone = obj.pose.bones.get(bone_name) if bone else None
                bone_selected = pose_bone.select if pose_bone else False
            

                if context.area.type == 'VIEW_3D':
                    if not bone_selected:
                        return False
                else:
                    only_selected = context.space_data.dopesheet.show_only_selected
                    if only_selected and not bone_selected:
                        return False

    # if getattr(fcurve.group, 'name', None) == utils.curve.group_name:
    #     return False  # we don't want to select keys on reference fcurves

    return True
