 

import bpy


# import utils.general
# import utils.key
from . import support
from .. import utils
from ... import preferences
# from .utils import curve, key
from bpy.props import StringProperty, FloatProperty, EnumProperty
from bpy.types import Operator


# ---------------  TOOLS  ------------------


class ANIMRETARGET_OT:
    """Slider Operators Preset"""
    bl_options = {'UNDO_GROUPED'}

    # slope: FloatProperty(default=2.0)
    factor: FloatProperty(default=1.0)
    # op_context: StringProperty(default='INVOKE_DEFAULT', options={'SKIP_SAVE'})
    op_context: EnumProperty(
        items=[('INVOKE_DEFAULT', 'Slider', 'Execute as slider', '', 1),
               ('EXEC_DEFAULT', 'Steps', 'Execute as steps', '', 2)],
        name="Mode",
        options={'SKIP_SAVE'},
        default='INVOKE_DEFAULT'
    )

    tool_type = None

    def __init__(self):
        self.cursor_keys = []
        self.display_info = ''
        pass

    def __del__(self):
        pass

    @classmethod
    def poll(cls, context):
        return utils.general.poll(context)

    def execute(self, context):
        return

    def add_key(self, context, fcurve):
        # if context.area.type == 'GRAPH_EDITOR':
        #     bpy.ops.graph.keyframe_insert(type='ALL')
        #     support.get_globals(context)
        #     bpy.ops.graph.select_all(action='DESELECT')
        # else:
        #     bpy.ops.anim.keyframe_insert_menu(type='Available')
        #     support.get_globals(context)

        keys = fcurve.keyframe_points
        cur_frame = context.scene.frame_current
        y = fcurve.evaluate(cur_frame)
        # keys.insert(cur_frame, y)
        utils.key.insert_key(keys, cur_frame, y)
        support.get_globals(context)

    def reset_tool_factor(self, context):
        tool = context.scene.animretarget.tool
        tool.show_factor = False
        tool.factor = 0.0
        tool.factor_overshoot = 0.0
        context.window.cursor_set("DEFAULT")
        context.window.workspace.status_text_set(None)
        context.area.tag_redraw()
        # bpy.ops.wm.redraw_timer(type='DRAW', iterations=1)
        # bpy.ops.wm.redraw_timer()
        # bpy.data.window_managers['WinMan'].windows.update()
        # bpy.data.window_managers['WinMan'].update_tag()

    def start(self, context, event):
        self.activated = True
        # context.scene.animretarget.tool.show_factor = True
        self.init_mouse_x = event.mouse_x

    def end(self, context):
        self.activated = False
        # context.scene.animretarget.tool.show_factor = False
        self.reset_tool_factor(context)
        return {'FINISHED'}

    def modal(self, context, event):
        tool = context.scene.animretarget.tool
        info_tool = tool.selector.title().replace('_', ' ')
        info_factor = int(utils.clamp((self.factor * 100), -100, 100))

        # context.window.workspace.status_text_set()
        self.display_info = f"{info_tool}: {info_factor:3d}%               " \
                            f"MOUSE-RB: Exit {info_tool} mode"

        context.window.cursor_set("SCROLL_X")
        tool.show_factor = True

        if event.type == 'LEFTMOUSE':
            if event.value == 'PRESS':
                # if tool.flip:
                if self.pref.tool_on_release:
                    return self.end(context)
                else:
                    self.start(context, event)

            elif event.value == 'RELEASE':
                # if tool.flip:
                if self.pref.tool_on_release:
                    self.start(context, event)
                else:
                    return self.end(context)

        if event.type == 'MOUSEMOVE' and self.activated:  # Use
            # context.window.workspace.status_text_set(self.display_info)

            tool_from_zero = (event.mouse_x - self.init_mouse_x) / 100
            self.factor = tool_from_zero

            tool.factor = tool_from_zero
            tool.factor_overshoot = tool_from_zero

            self.execute(context)

        elif event.type in {'RIGHTMOUSE', 'ESC'}:  # Cancel
            support.reset_original()

            self.reset_tool_factor(context)

            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'factor', text='', slider=True)

    def invoke(self, context, event):
        self.pref = context.preferences.addons[preferences.addon_name].preferences
        animaide = context.scene.animretarget
        tool = animaide.tool

        # if tool.flip:
        if self.pref.tool_on_release:
            self.start(context, event)
        else:
            self.activated = False
            tool.show_factor = False
            self.init_mouse_x = 0

        self.warning = 'No keys selected or under the cursor. You need auto-key to add values'

        # The select operator(s) are bugged, and can fail to update selected keys, so
        # When you change the frame, then select keys, the previous keys will stay marked as selected
        utils.key.update_keyframe_points(context)

        if self.op_context == 'EXEC_DEFAULT':
            return self.execute(context)

        tool.factor = 0.0
        tool.factor_overshoot = 0.0
        # self.slope = tool.slope
        self.phase = tool.noise_phase

        # self.init_mouse_x = event.mouse_x

        tool.area = context.area.type

        if context.area.type == 'VIEW_3D':
            if self.tool_type in tool.selector_3d:
                tool.selector_3d = self.tool_type
            tool.unselected_fcurves = True
        else:
            tool.selector = self.tool_type
            tool.unselected_fcurves = False

        # left_frame, right_frame = support.set_ref_marker(context)

        support.get_globals(context)

        # if support.global_values['are_keys_selected']:
        #     animaide.tool.keys_under_cursor = False
        # else:
        #     animaide.tool.keys_under_cursor = True

        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}


class ANIMRETARGET_OT_ease_to_ease(Operator, ANIMRETARGET_OT):
    """Transition selected or current keys from the neighboring\n""" \
    """ones in a "S" shape manner (ease-in and ease-out simultaneously).\n""" \
    """It doesn't take into consideration the current key values.\n"""

    bl_idname = "anim.retarget_aide_ease_to_ease"
    bl_label = "Ease To Ease"

    tool_type = 'EASE_TO_EASE'

    def tool(self, context):

        if self.selected_keys:
            if self.op_context == 'INVOKE_DEFAULT':
                context.window.workspace.status_text_set(self.display_info)

            tool = context.scene.animretarget.tool
            local_y = self.right_neighbor['y'] - self.left_neighbor['y']
            local_x = self.right_neighbor['x'] - self.left_neighbor['x']

            if local_x == 0:
                return

            for index in self.selected_keys:
                k = self.fcurve.keyframe_points[index]
                x = k.co.x - self.left_neighbor['x']

                factor = utils.clamp(self.factor, self.min_value, self.max_value)
                frame_ratio = x / local_x
                transition = support.s_curve(frame_ratio, xshift=-factor)
                new_value = self.left_neighbor['y'] + local_y * transition
                if tool.sticky_handles and context.area.type == 'GRAPH_EDITOR':
                    k.co.y = new_value
                else:
                    k.co_ui.y = new_value

        elif context.scene.tool_settings.use_keyframe_insert_auto and not self.some_keys_selected:
            context.window.workspace.status_text_set(self.display_info)
            self.add_key(context, self.fcurve)
        # else:
        #     self.report({'INFO'}, self.warning)
        return

    def execute(self, context):
        return support.to_execute(self, context, self.tool, context)


class ANIMRETARGET_OT_ease(Operator, ANIMRETARGET_OT):
    """Transition selected or current keys from the neighboring\n""" \
    """ones in a "C" shape manner (ease-in or ease-out). It doesn't\n""" \
    """take into consideration the current key values."""

    bl_idname = "anim.retarget_aide_ease"
    bl_label = "Ease"

    tool_type = 'EASE'

    def tool(self, context):

        if self.selected_keys:
            if self.op_context == 'INVOKE_DEFAULT':
                context.window.workspace.status_text_set(self.display_info)

            tool = context.scene.animretarget.tool
            local_y = self.right_neighbor['y'] - self.left_neighbor['y']
            local_x = self.right_neighbor['x'] - self.left_neighbor['x']
            factor = utils.clamp(self.factor, self.min_value, self.max_value)
            flipflop = abs(factor)

            if local_x == 0:
                return

            for index in self.selected_keys:
                k = self.fcurve.keyframe_points[index]
                x = k.co.x - self.left_neighbor['x']

                frame_ratio = x / local_x
                if factor > 0:
                    shift = - 1
                else:
                    shift = 0
                slope = 1 + (5 * flipflop)
                ease_y = support.s_curve(frame_ratio, slope=slope, width=2, height=2, xshift=shift, yshift=shift)
                new_value = self.left_neighbor['y'] + local_y * ease_y
                if tool.sticky_handles and context.area.type == 'GRAPH_EDITOR':
                    k.co.y = new_value
                else:
                    k.co_ui.y = new_value

        elif context.scene.tool_settings.use_keyframe_insert_auto and not self.some_keys_selected:
            context.window.workspace.status_text_set(self.display_info)
            self.add_key(context, self.fcurve)
        # else:
        #     self.report({'INFO'}, self.warning)
        return

    def execute(self, context):
        return support.to_execute(self, context, self.tool, context)


class ANIMRETARGET_OT_blend_ease(Operator, ANIMRETARGET_OT):
    """Blend selected or current keys to the ease-in or ease-out\n""" \
    """curve using the neighboring keys."""

    bl_idname = "anim.retarget_aide_blend_ease"
    bl_label = "Blend Ease"

    tool_type = 'BLEND_EASE'

    def tool(self, context):

        if self.selected_keys:
            if self.op_context == 'INVOKE_DEFAULT':
                context.window.workspace.status_text_set(self.display_info)

            tool = context.scene.animretarget.tool
            local_x = self.right_neighbor['x'] - self.left_neighbor['x']
            factor = utils.clamp(self.factor, self.min_value, self.max_value)
            flipflop = abs(factor)

            if local_x == 0:
                return

            for index in self.selected_keys:
                k = self.fcurve.keyframe_points[index]
                x = k.co_ui.x - self.left_neighbor['x']

                frame_ratio = x / local_x
                if factor > 0:
                    shift = - 1
                else:
                    shift = 0
                source = self.original_keys[index]['y']
                if factor > 0:
                    delta = self.right_neighbor['y'] - source
                    base = source
                else:
                    delta = source - self.left_neighbor['y']
                    base = self.left_neighbor['y']
                slope = flipflop * 5
                ease_y = support.s_curve(frame_ratio, slope=slope, width=2, height=2, xshift=shift, yshift=shift)
                new_value = base + delta * ease_y
                if tool.sticky_handles and context.area.type == 'GRAPH_EDITOR':
                    k.co.y = new_value
                else:
                    k.co_ui.y = new_value

        elif context.scene.tool_settings.use_keyframe_insert_auto and not self.some_keys_selected:
            context.window.workspace.status_text_set(self.display_info)
            self.add_key(context, self.fcurve)
        # else:
        #     self.report({'INFO'}, self.warning)
        return

    def execute(self, context):
        return support.to_execute(self, context, self.tool, context)


class ANIMRETARGET_OT_blend_neighbor(Operator, ANIMRETARGET_OT):
    """Blend selected or current keys to the value of the neighboring\n""" \
    """left or right keys."""

    bl_idname = "anim.retarget_aide_blend_neighbor"
    bl_label = "Blend Neighbor"

    tool_type = 'BLEND_NEIGHBOR'

    def tool(self, context):

        if self.selected_keys:
            if self.op_context == 'INVOKE_DEFAULT':
                context.window.workspace.status_text_set(self.display_info)

            tool = context.scene.animretarget.tool
            factor = utils.clamp(abs(self.factor), 0, self.max_value)
            for index in self.selected_keys:
                if self.factor < 0:
                    delta = self.left_neighbor['y'] - self.original_keys[index]['y']
                else:
                    delta = self.right_neighbor['y'] - self.original_keys[index]['y']
                k = self.fcurve.keyframe_points[index]
                new_value = self.original_keys[index]['y'] + delta * factor
                if tool.sticky_handles and context.area.type == 'GRAPH_EDITOR':
                    k.co.y = new_value
                else:
                    k.co_ui.y = new_value

        elif context.scene.tool_settings.use_keyframe_insert_auto and not self.some_keys_selected:
            context.window.workspace.status_text_set(self.display_info)
            self.add_key(context, self.fcurve)
        # else:
        #     self.report({'INFO'}, self.warning)
        return

    def execute(self, context):
        return support.to_execute(self, context, self.tool, context)


class ANIMRETARGET_OT_blend_default(Operator, ANIMRETARGET_OT):
    """Blend selected or current keys to the default value"""

    bl_idname = "anim.retarget_aide_blend_default"
    bl_label = "Blend Default"

    tool_type = 'BLEND_DEFAULT'

    def tool(self, context):

        if self.selected_keys:
            if self.op_context == 'INVOKE_DEFAULT':
                context.window.workspace.status_text_set(self.display_info)
            tool = context.scene.animretarget.tool
            factor = utils.clamp(self.factor, self.min_value, self.max_value)
            for index in self.selected_keys:
                default = obj = None
                id = self.fcurve.id_data
                datap = self.fcurve.data_path
                objects = context.selected_objects
                if context.active_object and not objects:
                    objects = [context.active_object]
                for o in objects:
                    if o.animation_data and o.animation_data.action is id:
                        obj = o
                    elif hasattr(o.data, "shape_keys"):
                        if o.data.shape_keys.animation_data:
                            obj = o

                try:
                    prop = obj.path_resolve(self.fcurve.data_path) if obj else None
                except:
                    prop = None

                if prop != None:

                    if obj is not None:
                        if obj.type == "ARMATURE" and bpy.context.mode == "POSE":
                            names = datap.split('"')[1::2]
                            no_name = ''.join(datap.split('"')[0::2])
                            bone_data = no_name.replace('][', '].[').split('.')

                            for id, i in enumerate(bone_data):
                                if i.find('[]') > 0:
                                    bone_data[id] = i.replace('[]', '["' + names.pop(0) + '"]')
                            boneName = bone_data[1].split('"')[1::2]

                            if boneName:
                                if bone_data[2] != "[]":
                                    default = obj.pose.bones[boneName[0]].bl_rna.properties[bone_data[2]]
                            else: # Most likely a custom property
                                default = self.original_values[index]['y'] # Unsupported data, don't affect it
                                #TODO: Find a way to read/reset a custom property value to use in this
                        else:
                            if str(datap).startswith("key_blocks["): # Is a shape key
                                default = 0 # Every shape key should have a default of 0
                            elif obj.get(datap) == None and obj.type != "ARMATURE":
                                default = obj.bl_rna.properties[datap]

                if default != None:
                    if str(default).isdigit():
                        default = default
                    else:
                        if default.default_array:
                            default = default.default_array[self.fcurve.array_index]
                        else:
                            default = default.default
                else:
                    default = self.original_keys[index]['y'] # Unsupported object, don't affect it

                k = self.fcurve.keyframe_points[index]
                new_value = (default*factor)+(self.original_keys[index]['y']*(1-factor))
                if tool.sticky_handles and context.area.type == 'GRAPH_EDITOR':
                    k.co.y = new_value
                else:
                    k.co_ui.y = new_value

        elif context.scene.tool_settings.use_keyframe_insert_auto and not self.some_keys_selected:
            context.window.workspace.status_text_set(self.display_info)
            self.add_key(context, self.fcurve)
        # else:
        #     self.report({'INFO'}, self.warning)
        return

    def execute(self, context):
        return support.to_execute(self, context, self.tool, context)


class ANIMRETARGET_OT_blend_infinite(Operator, ANIMRETARGET_OT):
    """Blend selected or current keys to the slant of neighboring\n""" \
    """left or right keys."""

    bl_idname = "anim.retarget_aide_blend_infinite"
    bl_label = "Blend Infinite"

    tool_type = 'BLEND_INFINITE'

    def tool(self, context):

        if self.selected_keys:
            if self.op_context == 'INVOKE_DEFAULT':
                context.window.workspace.status_text_set(self.display_info)

            tool = context.scene.animretarget.tool
            factor = utils.clamp(abs(self.factor), self.min_value, self.max_value)
            left_far = self.global_fcurve.get('left_far')
            right_far = self.global_fcurve.get('right_far')

            if self.factor < 0 and left_far:
                o = left_far['y'] - self.left_neighbor['y']
                a = left_far['x'] - self.left_neighbor['x']
            elif self.factor >= 0 and right_far:
                o = right_far['y'] - self.right_neighbor['y']
                a = right_far['x'] - self.right_neighbor['x']
            else:
                a = 1
                o = 1

            for index in self.selected_keys:
                k = self.fcurve.keyframe_points[index]
                if self.factor < 0:
                    new_a = k.co_ui.x - self.left_neighbor['x']
                    refe = self.left_neighbor['y']
                else:
                    new_a = k.co_ui.x - self.right_neighbor['x']
                    refe = self.right_neighbor['y']

                if a == 0:
                    new_o = 0
                else:
                    new_o = new_a * o / a

                delta = refe + new_o - self.original_keys[index]['y']
                new_value = self.original_keys[index]['y'] + delta * factor
                if tool.sticky_handles and context.area.type == 'GRAPH_EDITOR':
                    k.co.y = new_value
                else:
                    k.co_ui.y = new_value

        elif context.scene.tool_settings.use_keyframe_insert_auto and not self.some_keys_selected:
            context.window.workspace.status_text_set(self.display_info)
            self.add_key(context, self.fcurve)
        # else:
        #     self.report({'INFO'}, self.warning)
        return

    def execute(self, context):
        return support.to_execute(self, context, self.tool, context)


class ANIMRETARGET_OT_blend_frame(Operator, ANIMRETARGET_OT):
    """Blend selected or current keys to the value of the chosen\n""" \
    """left or right frames."""

    bl_idname = "anim.retarget_aide_blend_frame"
    bl_label = "Blend Frame"

    tool_type = 'BLEND_FRAME'

    def tool(self, context):

        if self.selected_keys:
            if self.op_context == 'INVOKE_DEFAULT':
                context.window.workspace.status_text_set(self.display_info)

            tool = context.scene.animretarget.tool
            ref = self.global_fcurve['ref_frames']
            factor = utils.clamp(abs(self.factor), 0, self.max_value)
            for index in self.selected_keys:
                if self.factor < 0:
                    delta = ref['left_y'] - self.original_keys[index]['y']
                else:
                    delta = ref['right_y'] - self.original_keys[index]['y']
                k = self.fcurve.keyframe_points[index]
                new_value = self.original_keys[index]['y'] + delta * factor
                if tool.sticky_handles and context.area.type == 'GRAPH_EDITOR':
                    k.co.y = new_value
                else:
                    k.co_ui.y = new_value

        elif context.scene.tool_settings.use_keyframe_insert_auto and not self.some_keys_selected:
            context.window.workspace.status_text_set(self.display_info)
            self.add_key(context, self.fcurve)
        # else:
        #     self.report({'INFO'}, self.warning)
        return

    def execute(self, context):
        return support.to_execute(self, context, self.tool, context)


class ANIMRETARGET_OT_blend_offset(Operator, ANIMRETARGET_OT):
    """Shift selected or current keys to the\n""" \
    """value of the chosen left and right frames."""

    bl_idname = "anim.retarget_aide_blend_offset"
    bl_label = "Blend Offset"

    tool_type = 'BLEND_OFFSET'

    def tool(self, context):

        if self.selected_keys:
            if self.op_context == 'INVOKE_DEFAULT':
                context.window.workspace.status_text_set(self.display_info)

            tool = context.scene.animretarget.tool
            factor = utils.clamp(self.factor, self.min_value, self.max_value)
            first_key_index = self.selected_keys[0]
            last_key_index = self.selected_keys[-1]
            if first_key_index is None or last_key_index is None:
                return
            for index in self.selected_keys:
                if factor < 0:
                    delta = self.original_keys[first_key_index]['y'] - self.left_neighbor['y']
                else:
                    delta = self.right_neighbor['y'] - self.original_keys[last_key_index]['y']
                k = self.fcurve.keyframe_points[index]
                new_value = self.original_keys[index]['y'] + delta * factor
                if tool.sticky_handles and context.area.type == 'GRAPH_EDITOR':
                    k.co.y = new_value
                else:
                    k.co_ui.y = new_value

        elif context.scene.tool_settings.use_keyframe_insert_auto and not self.some_keys_selected:
            context.window.workspace.status_text_set(self.display_info)
            self.add_key(context, self.fcurve)
        # else:
        #     self.report({'INFO'}, self.warning)

        return

    def execute(self, context):
        return support.to_execute(self, context, self.tool, context)


class ANIMRETARGET_OT_tween(Operator, ANIMRETARGET_OT):
    """Set lineal relative value of the selected or current keys \n""" \
    """in relationship to the neighboring ones. It doesn't take into\n""" \
    """consideration the current key values."""

    bl_idname = "anim.retarget_aide_tween"
    bl_label = "Tween"

    tool_type = 'TWEEN'

    def tool(self, context):

        if self.selected_keys:
            if self.op_context == 'INVOKE_DEFAULT':
                context.window.workspace.status_text_set(self.display_info)

            tool = context.scene.animretarget.tool
            factor = utils.clamp(self.factor, self.min_value, self.max_value)
            factor_zero_one = (factor+1)/2
            local_y = self.right_neighbor['y'] - self.left_neighbor['y']
            new_value = self.left_neighbor['y'] + local_y * factor_zero_one
            for index in self.selected_keys:
                k = self.fcurve.keyframe_points[index]
                if tool.sticky_handles and context.area.type == 'GRAPH_EDITOR':
                    k.co.y = new_value
                else:
                    k.co_ui.y = new_value

        elif context.scene.tool_settings.use_keyframe_insert_auto:
            context.window.workspace.status_text_set(self.display_info)
            self.add_key(context, self.fcurve)
        # else:
        #     self.report({'INFO'}, self.warning)
        return

    def execute(self, context):
        return support.to_execute(self, context, self.tool, context)


class ANIMRETARGET_OT_push_pull(Operator, ANIMRETARGET_OT):
    """Exagerates or decreases the value of the selected or current keys"""

    bl_idname = "anim.retarget_aide_push_pull"
    bl_label = "Push Pull"

    tool_type = 'PUSH_PULL'

    def tool(self, context):

        if self.selected_keys:
            if self.op_context == 'INVOKE_DEFAULT':
                context.window.workspace.status_text_set(self.display_info)

            tool = context.scene.animretarget.tool
            factor = utils.clamp(self.factor, self.min_value, self.max_value)
            factor_zero_two = factor + 1
            local_y = self.right_neighbor['y'] - self.left_neighbor['y']
            local_x = self.right_neighbor['x'] - self.left_neighbor['x']
            for index in self.selected_keys:
                k = self.fcurve.keyframe_points[index]
                x = k.co_ui.x - self.left_neighbor['x']
                frame_ratio = x / local_x
                lineal = self.left_neighbor['y'] + local_y * frame_ratio
                delta = self.original_keys[index]['y'] - lineal
                new_value = lineal + delta * factor_zero_two
                if tool.sticky_handles and context.area.type == 'GRAPH_EDITOR':
                    k.co.y = new_value
                else:
                    k.co_ui.y = new_value

        elif context.scene.tool_settings.use_keyframe_insert_auto and not self.some_keys_selected:
            context.window.workspace.status_text_set(self.display_info)
            self.add_key(context, self.fcurve)
        # else:
        #     self.report({'INFO'}, self.warning)
        return

    def execute(self, context):
        return support.to_execute(self, context, self.tool, context)


class ANIMRETARGET_OT_smooth(Operator, ANIMRETARGET_OT):
    """Averages values of selected keys creating a smoother fcurve"""

    bl_idname = "anim.retarget_aide_smooth"
    bl_label = "Smooth"

    tool_type = 'SMOOTH'

    def tool(self, context):

        if self.selected_keys:
            if self.op_context == 'INVOKE_DEFAULT':
                context.window.workspace.status_text_set(self.display_info)

            factor = utils.clamp(self.factor, self.min_value, self.max_value)
            for index in self.selected_keys:
                k = self.fcurve.keyframe_points[index]
                book_end = self.original_keys[index]['book_end']

                # if 'sy' not in self.original_keys[index]:
                #     continue
                # if not book_end:
                #     continue

                if book_end:
                    delta = 0
                else:
                    # delta = smooth_y - self.original_keys[index]['y']
                    prek = self.original_keys[index-1]['y']
                    curk = self.original_keys[index]['y']
                    postk = self.original_keys[index+1]['y']
                    delta = (((prek + postk)/2) - curk)/1.8
                k.co_ui.y = self.original_keys[index]['y'] + delta * factor
        # else:
        #     self.report({'INFO'}, 'Some selected keys needed for this tool')

    def execute(self, context):
        return support.to_execute(self, context, self.tool, context)


class ANIMRETARGET_OT_time_offset(Operator, ANIMRETARGET_OT):
    """Shift the value in time of selected or current keys """

    bl_idname = "anim.retarget_aide_time_offset"
    bl_label = "Time Offset"

    tool_type = 'TIME_OFFSET'

    def tool(self, context):

        if self.selected_keys:
            if self.op_context == 'INVOKE_DEFAULT':
                context.window.workspace.status_text_set(self.display_info)

            cycle = self.animaide.clone.cycle

            clone_name = '%s.%d.clone' % (self.fcurve.data_path, self.fcurve.array_index)

            blends_action = utils.set_animaide_action()
            blends_curves = utils.curve.get_fcurves_for_action(blends_action, only_first_slot = True)
            clone = utils.curve.duplicate_from_data(blends_curves,
                                                    self.global_fcurve,
                                                    clone_name,
                                                    before=cycle,
                                                    after=cycle)

            factor = utils.clamp(self.factor, self.min_value, self.max_value)

            for index in self.selected_keys:
                k = self.fcurve.keyframe_points[index]

                k.co_ui.y = clone.evaluate(k.co.x - 20 * factor)

            if clone in self.fcurves:
                self.fcurves.remove(clone)
            blends_curves.remove(clone)

        # else:
        #     self.report({'INFO'}, 'Some selected keys needed for this tool')

    def execute(self, context):
        return support.to_execute(self, context, self.tool, context)


class ANIMRETARGET_OT_shear_right(Operator, ANIMRETARGET_OT):
    """Shift the value in time of selected or current keys """

    bl_idname = "anim.retarget_aide_shear_right"
    bl_label = "Shear Right"

    tool_type = 'SHEAR_RIGHT'

    def tool(self, context):

        if self.selected_keys:
            if self.op_context == 'INVOKE_DEFAULT':
                context.window.workspace.status_text_set(self.display_info)

            support.shear(self, 'right')

            # shear_action = utils.set_animaide_action()
            # shear_curve = support.add_shear_curve()
            # shear_curves = getattr(shear_action, 'fcurves', None)
            # local_y = self.right_neighbor['y'] - self.left_neighbor['y']
            # support.set_shear_values(self.left_neighbor['x'], self.right_neighbor['x'])
            #
            # factor = utils.clamp(self.factor, self.min_value, self.max_value)
            # shear_curve.keyframe_points[1].co_ui.y = local_y * factor
            #
            # for index in self.selected_keys:
            #     k = self.fcurve.keyframe_points[index]
            #     k.co_ui.y = self.original_keys[index]['y'] + shear_curve.evaluate(k.co.x)
            #
            # shear_curves.remove(shear_curve)

    def execute(self, context):
        return support.to_execute(self, context, self.tool, context)


class ANIMRETARGET_OT_shear_left(Operator, ANIMRETARGET_OT):
    """Shift the value in time of selected or current keys """

    bl_idname = "anim.retarget_aide_shear_left"
    bl_label = "Shear Left"

    tool_type = 'SHEAR_LEFT'

    def tool(self, context):

        if self.selected_keys:
            if self.op_context == 'INVOKE_DEFAULT':
                context.window.workspace.status_text_set(self.display_info)

            support.shear(self, 'left')

            # shear_action = utils.set_animaide_action()
            # shear_curve = support.add_shear_curve()
            # shear_curves = getattr(shear_action, 'fcurves', None)
            # local_y = self.right_neighbor['y'] - self.left_neighbor['y']
            # support.set_shear_values(self.left_neighbor['x'], self.right_neighbor['x'])
            #
            # factor = utils.clamp(self.factor, self.min_value, self.max_value)
            # shear_curve.keyframe_points[0].co_ui.y = local_y * factor
            #
            # for index in self.selected_keys:
            #     k = self.fcurve.keyframe_points[index]
            #     k.co_ui.y = self.original_keys[index]['y'] + shear_curve.evaluate(k.co.x)
            #
            # shear_curves.remove(shear_curve)

    def execute(self, context):
        return support.to_execute(self, context, self.tool, context)


class ANIMRETARGET_OT_wave_noise(Operator, ANIMRETARGET_OT):
    """Set random values to the selected or current key \n""" \
    """or set them in a wave pattern."""

    bl_idname = "anim.retarget_aide_wave_noise"
    bl_label = "Wave-Noise"

    tool_type = 'WAVE_NOISE'

    def tool(self, context):

        if self.selected_keys:
            if self.op_context == 'INVOKE_DEFAULT':
                context.window.workspace.status_text_set(self.display_info)

            tool = context.scene.animretarget.tool

            factor = utils.clamp(self.factor, self.min_value, self.max_value)

            if factor > 0:
                blends_action = utils.set_animaide_action()
                blends_curves = utils.curve.get_fcurves_for_action(blends_action, only_first_slot = True)
                clone = utils.curve.duplicate_from_data(blends_curves,
                                                        self.global_fcurve,
                                                        'animaide')

                phase = self.animaide.tool.noise_phase + self.noise_steps
                scale = self.animaide.tool.noise_scale

                support.add_noise(clone, strength=1, scale=scale, phase=phase)

                for index in self.selected_keys:
                    k = self.fcurve.keyframe_points[index]

                    delta = clone.evaluate(k.co.x) - self.original_keys[index]['y']
                    new_value = self.original_keys[index]['y'] + delta * factor
                    if tool.sticky_handles and context.area.type == 'GRAPH_EDITOR':
                        k.co.y = new_value
                    else:
                        k.co_ui.y = new_value

                if clone in self.fcurves:
                    self.fcurves.remove(clone)
                blends_curves.remove(clone)

            else:
                n = 0
                for index in self.selected_keys:
                    n += 1
                    if n == 1:
                        direction = 1
                    else:
                        direction = -1
                    k = self.fcurve.keyframe_points[index]
                    new_value = self.original_keys[index]['y'] + (factor * direction)/5
                    if tool.sticky_handles and context.area.type == 'GRAPH_EDITOR':
                        k.co.y = new_value
                    else:
                        k.co_ui.y = new_value
                    if n == 2:
                        n = 0

        # else:
        #     self.report({'INFO'}, 'Some selected keys needed for this tool')

    def execute(self, context):
        return support.to_execute(self, context, self.tool, context)


class ANIMRETARGET_OT_scale_left(Operator, ANIMRETARGET_OT):
    """Increase or decrease the value of selected or current keys \n""" \
    """in relationship to the left neighboring one."""

    bl_idname = "anim.retarget_aide_scale_left"
    bl_label = "Scale Left"

    tool_type = 'SCALE_LEFT'

    def tool(self, context):

        if self.selected_keys:
            if self.op_context == 'INVOKE_DEFAULT':
                context.window.workspace.status_text_set(self.display_info)

            tool = context.scene.animretarget.tool
            factor = utils.clamp(self.factor, self.min_value, self.max_value)
            for index in self.selected_keys:
                k = self.fcurve.keyframe_points[index]
                delta = self.original_keys[index]['y'] - self.left_neighbor['y']
                new_value = self.original_keys[index]['y'] + delta * factor
                if tool.sticky_handles and context.area.type == 'GRAPH_EDITOR':
                    k.co.y = new_value
                else:
                    k.co_ui.y = new_value

        elif context.scene.tool_settings.use_keyframe_insert_auto and not self.some_keys_selected:
            context.window.workspace.status_text_set(self.display_info)
            self.add_key(context, self.fcurve)
        # else:
        #     self.report({'INFO'}, self.warning)

    def execute(self, context):
        return support.to_execute(self, context, self.tool, context)


class ANIMRETARGET_OT_scale_right(Operator, ANIMRETARGET_OT):
    """Increase or decrease the value of selected or current keys \n""" \
    """in relationship to the right neighboring one."""

    bl_idname = "anim.retarget_aide_scale_right"
    bl_label = "Scale Right"

    tool_type = 'SCALE_RIGHT'

    def tool(self, context):

        if self.selected_keys:
            if self.op_context == 'INVOKE_DEFAULT':
                context.window.workspace.status_text_set(self.display_info)

            tool = context.scene.animretarget.tool
            factor = utils.clamp(self.factor, self.min_value, self.max_value)
            for index in self.selected_keys:
                k = self.fcurve.keyframe_points[index]
                delta = self.original_keys[index]['y'] - self.right_neighbor['y']
                new_value = self.original_keys[index]['y'] + delta * factor
                if tool.sticky_handles and context.area.type == 'GRAPH_EDITOR':
                    k.co.y = new_value
                else:
                    k.co_ui.y = new_value

        elif context.scene.tool_settings.use_keyframe_insert_auto and not self.some_keys_selected:
            context.window.workspace.status_text_set(self.display_info)
            self.add_key(context, self.fcurve)
        # else:
        #     self.report({'INFO'}, self.warning)

    def execute(self, context):
        return support.to_execute(self, context, self.tool, context)


class ANIMRETARGET_OT_scale_average(Operator, ANIMRETARGET_OT):
    """Increase or decrease the value of selected or current keys \n""" \
    """in relationship to the average point of those affected"""

    bl_idname = "anim.retarget_aide_scale_average"
    bl_label = "Scale Average"

    tool_type = 'SCALE_AVERAGE'

    def tool(self, context):

        if self.selected_keys:
            if self.op_context == 'INVOKE_DEFAULT':
                context.window.workspace.status_text_set(self.display_info)

            tool = context.scene.animretarget.tool
            factor = utils.clamp(self.factor, self.min_value, self.max_value)
            y = 0
            for index in self.selected_keys:
                y = y + self.original_keys[index]['y']
            y_average = y / len(self.selected_keys)

            for index in self.selected_keys:
                k = self.fcurve.keyframe_points[index]
                delta = self.original_keys[index]['y'] - y_average

                new_value = self.original_keys[index]['y'] + delta * factor
                if tool.sticky_handles and context.area.type == 'GRAPH_EDITOR':
                    k.co.y = new_value
                else:
                    k.co_ui.y = new_value
        # else:
        #     self.report({'INFO'}, 'Some selected keys needed for this tool')

    def execute(self, context):
        return support.to_execute(self, context, self.tool, context)


class ANIMRETARGET_OT_tools_settings(Operator):
    """Shows global options for Curve Tools"""

    bl_idname = "anim.retarget_aide_tools_settings"
    bl_label = "Tools Settings"

    @classmethod
    def poll(cls, context):
        return utils.general.poll(context)

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_popup(self, width=200)

    def draw(self, context):
        animaide = context.scene.animretarget
        tool = animaide.tool

        layout = self.layout

        layout.label(text='Settings')
        layout.separator()
        # layout.prop(tool, 'overshoot', text='overshoot', toggle=False)
        # layout.prop(tool, 'keys_under_cursor', text='Only keys under cursor', toggle=False)
        layout.prop(tool, 'flip', text='Activates on release', toggle=False)

        col = layout.column(align=False)
        if tool.selector == 'BLEND_FRAME':
            col.active = True
        else:
            col.active = False
        col.prop(tool, 'use_markers', text='Use markers', toggle=False)

        # col = layout.column(align=False)
        # if tool.selector == 'EASE_TO_EASE' or tool.selector == 'EASE':
        #     col.active = True
        # else:
        #     col.active = False
        # col.label(text='Ease slope')
        # col.prop(tool, 'slope', text='', slider=False)

        # if tool.selector == 'NOISE':
        #     layout.label(text='Noise settings')
        #     layout.prop(tool, 'noise_phase', text='Phase', slider=True)
        #     layout.prop(tool, 'noise_scale', text='Scale', slider=True)


class ANIMRETARGET_OT_add_bookmark(Operator):
    """Adds a frame to the list for latter use as reference"""

    bl_idname = 'anim.retarget_aide_add_bookmark'
    bl_label = "Add Bookmark"
    bl_options = {'UNDO_GROUPED'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        animaide = context.scene.animretarget
        tool = animaide.tool
        bookmarks = tool.frame_bookmarks
        current_frame = context.scene.frame_current
        name = 'frame %s' % current_frame

        frame = bookmarks.get(name)

        if frame is None:
            bookmark = bookmarks.add()
            tool.bookmark_index = len(bookmarks) - 1
            bookmark.frame = current_frame
            bookmark.name = name

        context.scene.frame_set(current_frame)

        return {'FINISHED'}


class ANIMRETARGET_OT_delete_bookmark(Operator):
    """Delete frame from the list """

    bl_idname = 'anim.retarget_aide_delete_bookmark'
    bl_label = "Delete Bookmark"
    bl_options = {'UNDO_GROUPED'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        animaide = context.scene.animretarget
        tool = animaide.tool
        bookmarks = tool.frame_bookmarks
        index = tool.bookmark_index
        bookmarks.remove(index)

        return {'FINISHED'}


class ANIMRETARGET_OT_push_bookmark(Operator):
    """Pushes the bookmarked frame to be used as reference frame"""

    bl_idname = 'anim.retarget_aide_push_bookmark'
    bl_label = "Push Bookmark"
    bl_options = {'UNDO_GROUPED'}

    side: StringProperty()

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        pref = context.preferences.addons[preferences.addon_name].preferences
        animaide = context.scene.animretarget
        tool = animaide.tool
        index = tool.bookmark_index
        if index < len(tool.frame_bookmarks):
            bookmark = tool.frame_bookmarks[index]
            frame = bookmark.frame
            context.scene.frame_current = int(frame)

            # if tool.use_markers:
            if pref.ct_use_markers:
                utils.add_marker(name='', side=self.side, frame=frame, del_in_same_frame= True)
            elif self.side == 'L':
                tool.left_ref_frame = frame
            else:
                tool.right_ref_frame = frame

        return {'FINISHED'}


class ANIMRETARGET_OT_get_ref_frame(Operator):
    """Sets a reference frame that will be use by the BLEND FRAME\n""" \
    """tool. The one at the left sets the left reference, and the\n""" \
    """one on the right sets the right reference"""

    bl_idname = 'anim.retarget_aide_get_ref_frame'
    bl_label = "Get Reference Frames"
    bl_options = {'UNDO_GROUPED'}

    side: StringProperty()

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):

        pref = context.preferences.addons[preferences.addon_name].preferences

        animaide = context.scene.animretarget

        tool = animaide.tool

        current_frame = bpy.context.scene.frame_current

        if self.side == 'L':
            tool.left_ref_frame = current_frame

        if self.side == 'R':
            tool.right_ref_frame = current_frame

        # if tool.use_markers:
        if pref.ct_use_markers:
            utils.add_marker(name='', side=self.side, frame=current_frame)

        return {'FINISHED'}


# class ANIMRETARGET_OT_modifier(Operator):
#     """Add noise to a curve using a modifier"""

#     bl_idname = 'anim.retarget_aide_fcurve_modifier'
#     bl_label = "Modifier"
#     bl_options = {'REGISTER'}

#     @classmethod
#     def poll(cls, context):
#         return True

#     def execute(self, context):

#         objects = context.selected_objects
#         if context.active_object and not objects:
#             objects = [context.active_object]
#         for obj in objects:
#             action = obj.animation_data.action

#             for curve in action.fcurves:
#                 if curve.select is not True:
#                     continue
#                 noise = curve.modifiers.new('NOISE')

#                 noise.strength = 5
#                 noise.scale_tools = 3
#                 curve.convert_to_samples(0, 100)
#                 curve.convert_to_keyframes(0, 100)
#                 curve.modifiers.remove(noise)
#         return {'FINISHED'}


# class ANIMRETARGET_OT_path(Operator):
#     bl_idname = 'anim.retarget_aide_path'
#     bl_label = "Path"
#     bl_options = {'REGISTER'}

#     @classmethod
#     def poll(cls, context):
#         return True

#     def execute(self, context):
#         obj = context.object
#         fcurves = obj.animation_data.action.fcurves
#         utils.curve.create_path(context, fcurves)


classes = (
    ANIMRETARGET_OT_tools_settings,
    ANIMRETARGET_OT_get_ref_frame,
    ANIMRETARGET_OT_push_bookmark,
    ANIMRETARGET_OT_add_bookmark,
    ANIMRETARGET_OT_delete_bookmark,
    ANIMRETARGET_OT_ease_to_ease,
    ANIMRETARGET_OT_ease,
    ANIMRETARGET_OT_blend_ease,
    ANIMRETARGET_OT_blend_neighbor,
    ANIMRETARGET_OT_blend_frame,
    ANIMRETARGET_OT_blend_default,
    ANIMRETARGET_OT_blend_offset,
    ANIMRETARGET_OT_push_pull,
    ANIMRETARGET_OT_scale_average,
    ANIMRETARGET_OT_scale_left,
    ANIMRETARGET_OT_scale_right,
    ANIMRETARGET_OT_smooth,
    ANIMRETARGET_OT_wave_noise,
    ANIMRETARGET_OT_time_offset,
    ANIMRETARGET_OT_shear_left,
    ANIMRETARGET_OT_shear_right,
    ANIMRETARGET_OT_tween,
    ANIMRETARGET_OT_blend_infinite,
)
