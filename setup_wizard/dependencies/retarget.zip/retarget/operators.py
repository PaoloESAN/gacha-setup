from math import pi, ceil, floor, radians
import os
import bpy
from bpy.props import BoolProperty
from bpy.props import EnumProperty
from bpy.props import FloatProperty
from bpy.props import IntProperty
from bpy.props import StringProperty
from bpy.props import FloatVectorProperty
from bpy.types import Operator
from bpy.props import CollectionProperty
from bpy_extras import anim_utils
from bpy_extras.io_utils import ImportHelper
from mathutils import Color

import mathutils

from itertools import chain

from .rig_mapping import bone_mapping
from .rig_mapping.bone_mapping import HumanSkeleton
from . import preset_handler
from . import bone_utils,fbx_helper
from .action import ops

from mathutils import Vector
from mathutils import Matrix


CONSTR_STATUS = (
    ('--', "--", "Do Nothing"),
    ('enable', "Enable", "Enable All Constraints"),
    ('apply', "Apply", "Apply All Constraints"),
    ('disable', "Disable", "Disable All Constraints"),
    ('remove', "Remove", "Remove All Constraints"),
    ('influence', "Influence", "Influence of All Constraints"),
    ('mix', "Mix Mode", ""),
    ('target_space', "Target Space", ""),
    ('owner_space', "Owner Space", ""),
    ('add_prefix', "Add Prefix", "Add Prefix to Constraint names"),
    ('add_suffix', "Add Suffix", "Add Suffix to Constraint names")
)


CONSTR_TYPES = bpy.types.PoseBoneConstraints.bl_rna.functions['new'].parameters['type'].enum_items.keys()
CONSTR_TYPES.append('--')

class ConstraintStatus(Operator):
    """Apply/Disable/Remove bone/object constraints."""
    bl_idname = "object.retarget_set_constraints_status"
    bl_label = "Apply/Disable/Remove Constraints"
    bl_options = {'REGISTER', 'PRESET', 'UNDO'}


    set_status: EnumProperty(items=CONSTR_STATUS,
                             name="Status",
                             default='--')
    custom_Frame: IntProperty(name="Frame", description="Select the Frame To Apply ", default=1)
    
    influence: FloatProperty(name="Influence", 
                              description="Influence of All Constraints",
                              min= 0, max= 1,
                              default=1)
    
    mix: EnumProperty(items=[
                            ("REPLACE","Replace","Replace the original rotation with copied"),
                            ("ADD","Add","Add euler component values together"),
                            ("BEFORE","Before Original","Apply copied rotation before original, as if the constraint target is a parent"),
                            ("AFTER","After Original","Apply copied rotation after original, as if the constraint target is a child"),
                            ("OFFSET","Offset (Legacy)"," Combine rotations like the original Offset checkbox. Does not work well for multiple axis rotations")
                             ],
                             name="Mix Mode", options={'SKIP_SAVE'},
                             default='REPLACE')
    
    target_space: EnumProperty(items=[
                            ("WORLD","World Space",""),
                            ("CUSTOM","Custom Space",""),
                            ("POSE","Pose Space",""),
                            ("LOCAL_WITH_PARENT","Local With Parent",""),
                            ("LOCAL","Local Space",""),
                            ("LOCAL_OWNER_ORIENT","Local Space (Owner Orientation)","")
                             ],
                             name="Target Space", options={'SKIP_SAVE'},
                             default='WORLD')
    
    owner_space: EnumProperty(items=[
                            ("WORLD","World Space",""),
                            ("CUSTOM","Custom Space",""),
                            ("POSE","Pose Space",""),
                            ("LOCAL_WITH_PARENT","Local With Parent",""),
                            ("LOCAL","Local Space","")
                             ],
                             name="Owner Space", options={'SKIP_SAVE'},
                             default='WORLD')

    new_prefix: StringProperty(name="prefix",
                                description= "Prefix",
                                default="")
    
    new_suffix: StringProperty(name="suffix",
                                 description= "Suffix",
                                default="")
   
    #parameter
    target_list:StringProperty(name="Target List", search=bone_utils.get_trg_iterate_all, options={'SKIP_SAVE'}, default="All",
                               description="The list of targets of Constraint")
    
    object_const: BoolProperty(name="Object Constraint",
                              description="include Object Constraint",
                               default=True)
        
    skip_deform: BoolProperty(name="Skip Deform Bones",
                              description="Bones that deform the mesh",
                               default=False)
    
    has_shape: BoolProperty(name="Only Control Shapes",
                            description="Bones that have a custom display",
                            default=False)
    
    visible: BoolProperty(name="Visible",
                            description="Only visible bone",
                            default=False)

    selected_only: BoolProperty(name="Only Selected",
                                description="Only on Selected Bones",
                                default=False)
    #bone influence

    bone_inf: BoolProperty(name="Bones",
                               description= "select between Bones",
                               default=False)
    
    include_bone: EnumProperty(items=[
        ('include', "Include", "Include Bones"),
        ('exclude', "Exclude", "Exclude Bones")
         ],
        name="",
        default='include')

    bone_sel: StringProperty(name = "",
                              description=" Bones List",
                              default="", options = {'SKIP_SAVE'})
    
    incl_child:  BoolProperty(name="",
                              description="Include All The Children",
                             default=True)

    clean_all_bone:  BoolProperty(name="",
                              description="Delete All",
                             default=False, options = {'SKIP_SAVE'})

    clean_last_bone:  BoolProperty(name="",
                              description="Delete the last one",
                              default=False, options = {'SKIP_SAVE'})

    bone_collection = dict()
    #-----
    
    by_name: BoolProperty(name="Only By Name",
                            description= "Only Look for Constraints with this Prefix/Suffix",
                            default=False)
    
    include: EnumProperty(items=[
        ('include', "Include", "Include Constraints with this Prefix/Suffix"),
        ('exclude', "Exclude", "Exclude Constraints with this Prefix/Suffix")
         ],
        name="",
        default='include')
    
    prefix: StringProperty(name="prefix",
                                description= "Prefix",
                                default="")
    
    contain: StringProperty(name="Contain",
                                  description= "Contain",
                                 default="")
    
    suffix: StringProperty(name="suffix",
                                 description= "Suffix",
                                default="")

    #Constr type

    all_type: BoolProperty(name="All Type",
                               description= "Constraint Type",
                               default=True)
    
    include_constr: EnumProperty(items=[
        ('include', "Include", "Include Bones"),
        ('exclude', "Exclude", "Exclude Bones")
         ],
        name="",
        default='include')

    constr_sel: EnumProperty(name = "",
                            items=[(ct, ct.replace('_', ' ').title(), ct) for ct in CONSTR_TYPES],
                              description=" Constraint Type",
                              default="--", options = {'SKIP_SAVE'})
    
    clean_all_constr:  BoolProperty(name="",
                              description="Delete All",
                             default=False, options = {'SKIP_SAVE'})

    clean_last_constr:  BoolProperty(name="",
                              description="Delete the last one",
                              default=False, options = {'SKIP_SAVE'})

    constr_collection = []
    
    play: BoolProperty(name= "PLAY", default=False)

    action_range: BoolProperty(name= "Action Range to Scene",
                               description="Set Playback range to current action Start/End",
                               default=True)

    number_constr = []

    def draw(self, context):

        layout = self.layout
        column = layout.column()

        o = ops.get_ob_or_armature(context, context.active_object)
        #test if its local
        if o.library is not None:
            column.label(text=f"make '{o.name}' local", icon='ERROR')
            column.separator()

        #number of constraint
        if len(self.number_constr) == 1:
            column.label(text=f"Constraint Detected: {self.number_constr[0][1]}")
            column.separator()
        else:
            for name, num in self.number_constr:
                column.label(text=f"{num} Constraint(s) in {name}")
                column.separator()
     
        row = column.row()
        row.prop(self, 'set_status', text = "Status")

        if self.set_status == 'apply':
            row = column.row()
            row.prop(self, "custom_Frame", text="Frame")
        
        if self.set_status == 'add_prefix':
            row = column.row()
            row.prop(self, "new_prefix")

        if self.set_status == 'add_suffix':
            row = column.row()
            row.prop(self, "new_suffix")

        if self.set_status == 'influence':
            row = column.row()
            row.prop(self, "influence")

        if self.set_status == 'mix':
            row = column.row()
            row.prop(self, "mix")

        if self.set_status == 'target_space':
            row = column.row()
            row.prop(self, "target_space")

        if self.set_status == 'owner_space':
            row = column.row()
            row.prop(self, "owner_space")


        column.separator()
        row = column.row()

        row = column.row()
        row.prop(self, "target_list")

        row = column.row()
        row.prop(self, "object_const")

        column.separator()
        row = column.row()
            
        row = column.row()
        row.prop(self, 'selected_only')

        #bone influence

        row = column.row()
        row.prop(self, 'bone_inf')

        if self.bone_inf:
            subcol = row.column()
            subcol.prop(self, 'include_bone')

            sr_ob = ops.get_ob_or_armature(context, context.active_object)
            if sr_ob:

                row = column.split(factor=0.80, align=True)

                row.prop_search(self, 'bone_sel',
                            sr_ob.data,
                            "bones")

                row.prop(self, 'incl_child', toggle=True, icon='OUTLINER_DATA_ARMATURE')
                row.prop(self, 'clean_all_bone', toggle=True, icon='PANEL_CLOSE')
                row.prop(self, 'clean_last_bone',toggle=True, icon='TRACKING_CLEAR_BACKWARDS')

                i = 0
                row = column.split(factor=0.33, align=True)

                for k, v in self.bone_collection.items():
                    if i == 3:
                        row = column.split(factor=0.33, align=True)
                        i = 0
                    if len(v) > 1:
                        row.label(text=k, icon='OUTLINER_DATA_ARMATURE')
                    else:
                        row.label(text=k, icon='BONE_DATA')

                    i += 1
                column.separator()

        row = column.row()
        row.prop(self, 'skip_deform')

        row = column.row()
        row.prop(self, 'has_shape')

        row = column.row()
        row.prop(self, 'visible')

        column.separator()
        row = column.row()

        row = column.row()
        row.prop(self, 'by_name', text="by Name")
        if self.by_name:
            subcol = row.column()
            subcol.prop(self, 'include')

            row = column.row()
            col = row.column()
            col.label(text="Prefix")
            col.prop(self, 'prefix', text="")

            col = row.column()
            col.label(text="Contain:")
            col.prop(self, 'contain', text="")

            col = row.column()
            col.label(text="Suffix:")
            col.prop(self, 'suffix', text="")

        #Constr type
        row = column.row()
        row.prop(self, 'all_type')

        if not self.all_type:
          
            subcol = row.column()
            subcol.prop(self, 'include_constr')

            row = column.split(factor=0.80, align=True)
            row.prop(self, 'constr_sel')
            row.prop(self, 'clean_all_constr', toggle=True, icon='PANEL_CLOSE')
            row.prop(self, 'clean_last_constr',toggle=True, icon='TRACKING_CLEAR_BACKWARDS')

            i = 0
            row = column.split(factor=0.33, align=True)

            for ik in self.constr_collection:
                if i == 3:
                    row = column.split(factor=0.33, align=True)
                    i = 0

                row.label(text=ik, icon='CONSTRAINT_BONE')

                i += 1

        row = column.split(factor=0.5, align=True)
        row.prop(self, "play", toggle=True, icon='PLAY')
        row.prop(self, "action_range", toggle=True, icon='PREVIEW_RANGE')

    

    @classmethod
    def poll(cls, context):
        ob = ops.get_ob_or_armature(context, context.active_object)
        if not ob:
            return False
        if not hasattr(ob, "constraints"):
            return False

        return True

    def invoke(self, context, event):
        #init the custom_Frame
        self.custom_Frame = context.scene.frame_current

        return self.execute(context)

    def condition(self, constr):

        if self.by_name:
            if self.include == 'include':
                if self.prefix:
                    if not constr.name.startswith(self.prefix):
                        return False

                if self.suffix:
                    if not constr.name.endswith(self.suffix):
                        return False

                if self.contain:
                    if not self.contain in constr.name:
                        return False
            
            else:
                if self.prefix:
                    if constr.name.startswith(self.prefix):
                        return False

                if self.suffix:
                    if constr.name.endswith(self.suffix):
                        return False

                if self.contain:
                    if self.contain in constr.name:
                        return False
        
        if not self.all_type and self.constr_collection and constr.type not in self.constr_collection and self.include_constr == 'include':
            return False
        
        if not self.all_type and self.constr_collection and constr.type in self.constr_collection and self.include_constr == 'exclude':
            return False
        
        if self.target_list != "All" and getattr(constr, "target", None) and constr.target.name != self.target_list:
            return False
        
        return True


    def execute(self, context):

        o = ops.get_ob_or_armature(context, context.active_object)
        if o.library is not None:
            return {'FINISHED'}

        bake_up = list(context.selected_objects)

        self.number_constr.clear()

        #bone influence
        if self.clean_all_bone:
            if len(self.bone_collection) > 0 :
                self.bone_collection.clear()
            self.clean_all_bone = False

        if self.clean_last_bone:
            if len(self.bone_collection) > 0 :
                self.bone_collection.popitem()
            self.clean_last_bone = False

        if self.bone_sel:

            if not self.bone_sel in self.bone_collection.keys():

                sr_ob = ops.get_ob_or_armature(context, context.active_object)
                if sr_ob:

                    list_bone = list()

                    bone = sr_ob.pose.bones[self.bone_sel]
                    list_bone.append(bone.name)

                    if self.incl_child:

                        for b in bone.bone.children_recursive:
                            list_bone.append(b.name)

                    self.bone_collection[self.bone_sel] = list_bone

            self.bone_sel = ""

        #----
        if not self.all_type:

            if self.clean_all_constr:
                if len(self.constr_collection) > 0 :
                    self.constr_collection.clear()
                self.clean_all_constr = False

            if self.clean_last_constr:
                if len(self.constr_collection) > 0 :
                    self.constr_collection.pop()
                self.clean_last_constr = False

            if self.constr_sel != "--":
                if not self.constr_sel in self.constr_collection:
                    self.constr_collection.append(self.constr_sel)
                self.constr_sel = "--"

        #constraint type
        ob = ops.get_ob_or_armature(context, context.active_object)

        if self.action_range and ob.animation_data and ob.animation_data.action:
            bpy.ops.object.retarget_action_to_range()
        
        current_m = context.mode

        if self.set_status == 'apply':
            context.scene.frame_set(self.custom_Frame)

        actif =  context.active_object
        armatures = ops.get_selected_obs(context)
        for armature in armatures:

            if not hasattr(armature, "constraints"):
                continue

            if armature.library is not None:
                continue

            if armature.type == 'ARMATURE':
                context.view_layer.objects.active = armature
                bpy.ops.object.mode_set(mode='POSE')
            else:
                bpy.ops.object.mode_set(mode='OBJECT')

            bones = list()
            ob_constr = list()

            if self.object_const:
                ob_constr = armature.constraints

            number_constr = 0
            
            if armature.type == 'ARMATURE':
                for bone in armature.pose.bones:

                    if self.selected_only and not bone.select:
                        continue
                    if self.has_shape and not bool(bone.custom_shape):
                        continue
                    if self.visible and not bone_utils.visible_bone(bone):
                        continue
                    if self.skip_deform and bone.bone.use_deform:
                        continue
                    bones.append(bone)
            
            #bone influence
            if bones and self.bone_inf:

                if self.bone_collection:

                    list_limb = []
                    for b_list in self.bone_collection.values():
                        list_limb.extend(b_list)

                    b_names = list()
                    for bone in bones:
                        b_names.append(bone.name)

                    for key in b_names:

                        if key in list_limb:
                            if self.include_bone == 'exclude':
                                bone = armature.pose.bones[key]
                                bones.remove(bone)
                        else:
                            if self.include_bone == 'include':
                                bone = armature.pose.bones[key]
                                bones.remove(bone)

            if self.set_status == '--':
                for bone in bones:
                    for constr in bone.constraints:

                        if not self.condition(constr):
                            continue 

                        number_constr += 1
                #object
                for constr in ob_constr:
                    if not self.condition(constr):
                        continue 

                    number_constr += 1

            elif self.set_status == 'remove':
                for bone in bones:
                    for constr in reversed(bone.constraints):

                        if not self.condition(constr):
                            continue 

                        number_constr += 1

                        bone.constraints.remove(constr)
                #object
                for constr in ob_constr:
                    if not self.condition(constr):
                        continue 

                    number_constr += 1

                    armature.constraints.remove(constr)

            elif self.set_status == 'enable' or self.set_status == 'disable' or self.set_status == 'influence':
                for bone in bones:
                    for constr in bone.constraints:

                        if not self.condition(constr):
                            continue

                        number_constr += 1

                        if self.set_status == 'influence':
                            constr.influence = self.influence
                        else:
                            constr.mute = self.set_status == 'disable'
                #object
                for constr in ob_constr:
                    if not self.condition(constr):
                        continue 

                    number_constr += 1

                    if self.set_status == 'influence':
                        constr.influence = self.influence
                    else:
                        constr.mute = self.set_status == 'disable'
                            
            elif self.set_status in ["mix", "target_space", "owner_space"]:
                for bone in bones:
                    for constr in bone.constraints:

                        if not self.condition(constr):
                            continue

                        number_constr += 1

                        if self.set_status == 'mix':
                            if getattr(constr, "mix_mode", None):
                                constr.mix_mode = self.mix
                       
                        elif self.set_status == 'target_space':
                            if getattr(constr, "target_space", None):
                                try:
                                    constr.target_space = self.target_space
                                except:
                                    pass
                       
                        elif self.set_status == 'owner_space':
                            if getattr(constr, "owner_space", None):
                                try:
                                    constr.owner_space = self.owner_space
                                except:
                                    pass
                #object
                for constr in ob_constr:
                    if not self.condition(constr):
                        continue 

                    number_constr += 1

                    if self.set_status == 'mix':
                        if getattr(constr, "mix_mode", None):
                            constr.mix_mode = self.mix
                    
                    elif self.set_status == 'target_space':
                        if getattr(constr, "target_space", None):
                            try:
                                constr.target_space = self.target_space
                            except:
                                pass
                    
                    elif self.set_status == 'owner_space':
                        if getattr(constr, "owner_space", None):
                            try:
                                constr.owner_space = self.owner_space
                            except:
                                pass

                       
            # apply Constraints
            elif self.set_status == 'apply':
                for bone in bones:

                    bmat = bone.matrix.copy()
                    for constr in reversed(bone.constraints):

                        if not self.condition(constr):
                            continue

                        number_constr += 1

                        bone.constraints.remove(constr)
                        #bpy.ops.constraint.apply(constraint = constr.name, owner = 'BONE')
                        
                    bone.matrix = bone_utils.get_bone_matrix(bone, bmat)
                #object
                if ob_constr:
                    omat = armature.matrix_world.copy()
                    for constr in reversed(ob_constr):

                        if not self.condition(constr):
                            continue 

                        number_constr += 1

                        armature.constraints.remove(constr)
                    armature.matrix_world = bone_utils.get_ob_matrix(armature, omat)

            elif self.set_status == 'add_prefix' or self.set_status == 'add_suffix':
                for bone in bones:
                    for constr in bone.constraints:

                        if not self.condition(constr):
                            continue

                        number_constr += 1
                        
                        if self.set_status == 'add_prefix':
                            constr.name = self.new_prefix + constr.name
                        else:
                            constr.name = constr.name + self.new_suffix
                #object
                for constr in ob_constr:
                    if not self.condition(constr):
                        continue 

                    number_constr += 1

                    if self.set_status == 'add_prefix':
                        constr.name = self.new_prefix + constr.name
                    else:
                        constr.name = constr.name + self.new_suffix

            self.number_constr.append((armature.name, number_constr))

        ob = ops.get_ob_or_armature(context, context.active_object)
        if ob.library is None:
            bpy.ops.object.mode_set(mode= current_m)

        if self.play and not context.screen.is_animation_playing:
            bpy.ops.screen.animation_play()
        for o in bake_up:
            o.select_set(True, view_layer = context.view_layer)
        context.view_layer.objects.active = actif
        return {'FINISHED'}


class SelectConstrainedControls(Operator):
    bl_idname = "armature.retarget_select_constrained_ctrls"
    bl_label = "Select constrained controls"
    bl_description = "Select bone controls with constraints or animations"
    bl_options = {'REGISTER', 'PRESET', 'UNDO'}

    select_type: EnumProperty(items=[
        ('constr', "Constrained", "Select constrained controls"),
        ('anim', "Animated", "Select animated controls"),
        ('all', "All", "Select All controls"),
    ],
        name="Select if",
        default='constr')
    
    expand: BoolProperty(name="Expand",
                              description="Expand the Selection",
                               default=False)

    by_preset: BoolProperty(name="Select by preset",
                              description="Select bones by preset",
                               default=False)
    
    rig_preset: EnumProperty(items=preset_handler.iterate_presets_with_current,
                             name="Preset",
                            )
    
    skip_deform: BoolProperty(name="Skip Deform Bones",
                              description="Bones that deform the mesh",
                               default=False)
    has_shape: BoolProperty(name="Only Control Shapes",
                            description="Bones that have a custom display",
                            default=False)
    
    visible: BoolProperty(name="Visible",
                            description="Only visible bone",
                            default=False)
    
    # constraint Name
    const_name: BoolProperty(name="Constraint Name",
                            description= "Only Look for Bone with this Constraints Prefix/Suffix",
                            default=False)
    
    const_include: EnumProperty(items=[
        ('include', "Include", "Include Constraints with this Prefix/Suffix"),
        ('exclude', "Exclude", "Exclude Constraints with this Prefix/Suffix")
         ],
        name="",
        default='include')
    
    const_prefix: StringProperty(name="prefix",
                                description= "Prefix",
                                default="")
    
    const_contain: StringProperty(name="Contain",
                                  description= "Contain",
                                 default="")
    
    const_suffix: StringProperty(name="suffix",
                                 description= "Suffix",
                                default="")
    
    # bone Name
    by_name: BoolProperty(name="Bone Name",
                            description= "Only Look for Bones with this Prefix/Suffix",
                            default=False)
    
    include: EnumProperty(items=[
        ('include', "Include", "Include Bones with this Prefix/Suffix"),
        ('exclude', "Exclude", "Exclude Bones with this Prefix/Suffix")
         ],
        name="",
        default='include')
    
    prefix: StringProperty(name="prefix",
                                description= "Prefix",
                                default="")
    
    contain: StringProperty(name="Contain",
                                  description= "Contain",
                                 default="")
    
    suffix: StringProperty(name="suffix",
                                 description= "Suffix",
                                default="")
    
    #bone influence

    bone_inf: BoolProperty(name="Bones",
                               description= "select between Bones",
                               default=False)
    
    include_bone: EnumProperty(items=[
        ('include', "Include", "Include Bones"),
        ('exclude', "Exclude", "Exclude Bones")
         ],
        name="",
        default='include')

    bone_sel: StringProperty(name = "",
                              description=" Bones List",
                              default="", options = {'SKIP_SAVE'})
    
    incl_child:  BoolProperty(name="",
                              description="Include All The Children",
                             default=True)

    clean_all_bone:  BoolProperty(name="",
                              description="Delete All",
                             default=False, options = {'SKIP_SAVE'})

    clean_last_bone:  BoolProperty(name="",
                              description="Delete the last one",
                              default=False, options = {'SKIP_SAVE'})

    bone_collection = dict()
    #-----

    #bone collection 

    all_co: BoolProperty(name="Bone Collection",
                               description= "Select between Bone Collection",
                               default=False,  options = {'SKIP_SAVE'})
    
    include_co: EnumProperty(items=[
        ('include', "Include", "Include Collection"),
        ('exclude', "Exclude", "Exclude Collection")
         ],
        name="",
        default='include')

    co_sel: StringProperty(name = "",
                              description="Collections",
                              default="", options = {'SKIP_SAVE'})
    
    clean_all_co:  BoolProperty(name="",
                              description="Delete All",
                             default=False, options = {'SKIP_SAVE'})

    clean_last_co:  BoolProperty(name="",
                              description="Delete the last one",
                              default=False, options = {'SKIP_SAVE'})

    co_collection = []
    

    number_constr = []
    
    def draw(self, context):

        layout = self.layout
        column = layout.column()

        o = ops.get_ob_or_armature(context, context.active_object)
        #test if its local
        if o.library is not None:
            column.label(text=f"make '{o.name}' local", icon='ERROR')
            column.separator()

        #number of constraint
        if len(self.number_constr) == 1:
            column.label(text=f"Number of Bones Selected: {self.number_constr[0][1]}")
            column.separator()
        else:
            for name, num in self.number_constr:
                column.label(text=f"{num} Bone(s) Selected in {name}")
                column.separator()

        row = column.row()
        row.prop(self, 'select_type')

        row = column.row()
        row.prop(self, 'expand')

        row = column.row()
        row.prop(self, 'by_preset')

        if self.by_preset:
            row = column.row()
            row.prop(self, 'rig_preset')
        
        row = column.row()
        row.prop(self, 'skip_deform')

        row = column.row()
        row.prop(self, 'has_shape')

        row = column.row()
        row.prop(self, 'visible')

        #constraint name 
        if self.select_type == 'constr':

            row = column.row()
            row.prop(self, 'const_name')

            if self.const_name:
                subcol = row.column()
                subcol.prop(self, 'const_include')

                row = column.row()
                col = row.column()
                col.label(text="Prefix")
                col.prop(self, 'const_prefix', text="")

                col = row.column()
                col.label(text="Contain:")
                col.prop(self, 'const_contain', text="")

                col = row.column()
                col.label(text="Suffix:")
                col.prop(self, 'const_suffix', text="")

        #bone name 
        row = column.row()
        row.prop(self, 'by_name')

        if self.by_name:
            subcol = row.column()
            subcol.prop(self, 'include')

            row = column.row()
            col = row.column()
            col.label(text="Prefix")
            col.prop(self, 'prefix', text="")

            col = row.column()
            col.label(text="Contain:")
            col.prop(self, 'contain', text="")

            col = row.column()
            col.label(text="Suffix:")
            col.prop(self, 'suffix', text="")

        #bone influence

        row = column.row()
        row.prop(self, 'bone_inf')

        if self.bone_inf:
            subcol = row.column()
            subcol.prop(self, 'include_bone')

            sr_ob = ops.get_ob_or_armature(context, context.active_object)
            if sr_ob:

                row = column.split(factor=0.80, align=True)

                row.prop_search(self, 'bone_sel',
                            sr_ob.data,
                            "bones")

                row.prop(self, 'incl_child', toggle=True, icon='OUTLINER_DATA_ARMATURE')
                row.prop(self, 'clean_all_bone', toggle=True, icon='PANEL_CLOSE')
                row.prop(self, 'clean_last_bone',toggle=True, icon='TRACKING_CLEAR_BACKWARDS')

                i = 0
                row = column.split(factor=0.33, align=True)

                for k, v in self.bone_collection.items():
                    if i == 3:
                        row = column.split(factor=0.33, align=True)
                        i = 0
                    if len(v) > 1:
                        row.label(text=k, icon='OUTLINER_DATA_ARMATURE')
                    else:
                        row.label(text=k, icon='BONE_DATA')

                    i += 1
                column.separator()
        
        #bone collection 
        ob = ops.get_ob_or_armature(context, context.active_object)
        if ob.data.collections_all:
            row = column.row()
            row.prop(self, 'all_co')

            if self.all_co:
            
                subcol = row.column()
                subcol.prop(self, 'include_co')

                row = column.split(factor=0.80, align=True)

                row.prop_search(self, 'co_sel',
                            ob.data,
                            "collections_all")
                
                row.prop(self, 'clean_all_co', toggle=True, icon='PANEL_CLOSE')
                row.prop(self, 'clean_last_co',toggle=True, icon='TRACKING_CLEAR_BACKWARDS')

                i = 0
                row = column.split(factor=0.33, align=True)

                for ik in self.co_collection:
                    if i == 3:
                        row = column.split(factor=0.33, align=True)
                        i = 0

                    row.label(text=ik, icon='ARMATURE_DATA')

                    i += 1

    @classmethod
    def poll(cls, context):
        ob = ops.get_ob_or_armature(context, context.active_object)
        if not ob:
            return False
        if ob.type != 'ARMATURE':
            return False

        return True
    
    def condition(self, bone):
        # constraint name
        if self.select_type == 'constr':
            if self.const_name:
                if self.const_include == 'include':

                    if self.const_prefix:
                        find = False
                        for const in bone.constraints:
                            if const.name.startswith(self.const_prefix):
                                find = True
                                break
                        if not find:
                            return False

                    if self.const_suffix:
                        find = False
                        for const in bone.constraints:
                            if const.name.endswith(self.const_suffix):
                                find = True
                                break
                        if not find:
                            return False

                    if self.const_contain:
                        find = False
                        for const in bone.constraints:
                            if not self.const_contain in const.name:
                                find = True
                                break
                        if not find:
                            return False
                
                else:
                    if self.const_prefix:
                        for const in bone.constraints:
                            if const.name.startswith(self.const_prefix):
                                return False

                    if self.const_suffix:
                        for const in bone.constraints:
                            if const.name.endswith(self.const_suffix):
                                return False

                    if self.const_contain:
                        for const in bone.constraints:
                            if not self.const_contain in const.name:
                                return False
                    
        # Bone Name
        if self.by_name:
            if self.include == 'include':
                if self.prefix:
                    if not bone.name.startswith(self.prefix):
                        return False

                if self.suffix:
                    if not bone.name.endswith(self.suffix):
                        return False

                if self.contain:
                    if not self.contain in bone.name:
                        return False
            
            else:
                if self.prefix:
                    if bone.name.startswith(self.prefix):
                        return False

                if self.suffix:
                    if bone.name.endswith(self.suffix):
                        return False

                if self.contain:
                    if self.contain in bone.name:
                        return False
           
        #bone influence
        if self.bone_inf:

            if self.bone_collection:

                list_limb = []
                for b_list in self.bone_collection.values():
                    list_limb.extend(b_list)

                if bone.name in list_limb:
                    if self.include_bone == 'exclude':
                        return False
                else:
                    if self.include_bone == 'include':
                       return False
                    
        #get all bone from collections
        co_collection = []
        if self.all_co and self.co_collection:
            for name in self.co_collection:
                data = bone.id_data.data
                if name in data.collections_all:
                    co = data.collections_all.get(name)
                    co_collection.extend(co.bones_recursive)

        if self.all_co and self.co_collection and bone.bone not in co_collection and self.include_co == 'include':
            return False
        
        if self.all_co and self.co_collection and bone.bone in co_collection and self.include_co == 'exclude':
            return False
        
        return True
    
    def invoke(self, context, event):
        o = ops.get_ob_or_armature(context, context.active_object)

        if o.data.retarget_retarget.has_settings():
            self.rig_preset = '--Current--'

        else:
            self.rig_preset = preset_handler.findPreset(o)

        return self.execute(context)

    def execute(self, context):

        o = ops.get_ob_or_armature(context, context.active_object)
        if o.library is not None:
            return {'FINISHED'}

        bake_up = list(context.selected_objects)

        self.number_constr.clear()

        #bone influence
        if self.clean_all_bone:
            if len(self.bone_collection) > 0 :
                self.bone_collection.clear()
            self.clean_all_bone = False

        if self.clean_last_bone:
            if len(self.bone_collection) > 0 :
                self.bone_collection.popitem()
            self.clean_last_bone = False

        if self.bone_sel:

            if not self.bone_sel in self.bone_collection.keys():

                sr_ob = ops.get_ob_or_armature(context, context.active_object)
                if sr_ob:

                    list_bone = list()

                    bone = sr_ob.pose.bones[self.bone_sel]
                    list_bone.append(bone.name)

                    if self.incl_child:

                        for b in bone.bone.children_recursive:
                            list_bone.append(b.name)

                    self.bone_collection[self.bone_sel] = list_bone

            self.bone_sel = ""

        #----
        #bone collection .
        if self.all_co:

            if self.clean_all_co:
                if len(self.co_collection) > 0 :
                    self.co_collection.clear()
                self.clean_all_co = False

            if self.clean_last_co:
                if len(self.co_collection) > 0 :
                    self.co_collection.pop()
                self.clean_last_co = False

            if self.co_sel:
                if not self.co_sel in self.co_collection:
                    self.co_collection.append(self.co_sel)
                self.co_sel = ""

        actif = context.active_object
        armatures = ops.get_selected_obs(context)
        for ob in armatures:

            if ob.type != 'ARMATURE':
                continue

            if ob.library is not None:
                continue

            context.view_layer.objects.active = ob
            bpy.ops.object.mode_set(mode='POSE')

            preset_bone_names = []

            if self.by_preset:

                rig_settings = ob.data.retarget_retarget
                if self.rig_preset != "--Current--":
                    skeleton = preset_handler.get_preset_skel(self.rig_preset, rig_settings)
                else:
                    skeleton = preset_handler.get_settings_skel(rig_settings)
                preset_bone_names = skeleton.bone_names()

            number_constr = 0

            if not self.expand:
                for bone in ob.pose.bones:
                    bone.select = False
            else:
                for bone in ob.pose.bones:
                    if bone.select:
                        number_constr += 1

            if self.select_type == 'constr':
                for pb in bone_utils.get_constrained_controls(ob, unselect= not self.expand, use_deform=not self.skip_deform):
                    if not self.condition(pb):
                        continue
                    if self.expand and pb.select:
                        continue
                    if self.visible and not bone_utils.visible_bone(pb):
                        continue
                    if self.by_preset and not pb.name in preset_bone_names:
                        continue
                    pb.select = bool(pb.custom_shape) if self.has_shape else True

                    if pb.select:
                        number_constr += 1

            elif self.select_type == 'anim':
                if not ob.animation_data:
                    self.number_constr.append((ob.name, number_constr))
                    continue
                if not ob.animation_data.action:
                    self.number_constr.append((ob.name, number_constr))
                    continue

                for slot in ob.animation_data.action.slots:

                    if slot.target_id_type != 'OBJECT':
                        continue

                    if not ob in slot.users():
                        continue

                    channelbag = anim_utils.action_get_channelbag_for_slot(ob.animation_data.action, slot)

                    for gp in channelbag.groups:

                        if gp.name in ob.pose.bones:

                            try:
                                bone = ob.pose.bones[gp.name]
                            except KeyError:
                                continue

                            if self.skip_deform and bone.bone.use_deform:
                                continue

                            if not self.condition(bone):
                                continue

                            if self.expand and bone.select:
                                continue

                            if self.visible and not bone_utils.visible_bone(bone):
                                continue
                            
                            if self.by_preset and not bone.name in preset_bone_names:
                                continue

                            bone.select = bool(bone.custom_shape) if self.has_shape else True

                            if bone.select:
                                number_constr += 1
                
            else:
                for bone in ob.pose.bones:
                    if self.skip_deform and bone.bone.use_deform:
                        continue

                    if not self.condition(bone):
                        continue

                    if self.expand and bone.select:
                        continue

                    if self.visible and not bone_utils.visible_bone(bone):
                        continue
                    
                    if self.by_preset and not bone.name in preset_bone_names:
                        continue

                    bone.select = bool(bone.custom_shape) if self.has_shape else True
                    if bone.select:
                        number_constr += 1
            
            self.number_constr.append((ob.name, number_constr))

        for o in bake_up:
            o.select_set(True, view_layer = context.view_layer)

        context.view_layer.objects.active = actif
        return {'FINISHED'}

class AlignBone(Operator):
    bl_idname = "armature.retarget_transfert_bone"
    bl_label = "Align Bones"
    bl_description = "Align the rest positions, it does not affect the mesh (select at least 2 armatures) (apply the scale in case of problem) (extremity bones will cause some issue) IT WILL BREACK THE ACTIONS OF THIS ARMATURE"
    bl_options = {'REGISTER', 'PRESET', 'UNDO'}

    same_bone_names: BoolProperty(name="Same Bone Names",
                                 description="When two armatures have the same bones names (set these Armature to the same position)",
                                 default=False)

    bind_by_name: BoolProperty(name="Bind bones by name",
                            description= "Look for bones present in both",
                            default=False)

    

    name_prefix: StringProperty(name="Add prefix to name",
                                description= "Add prefix to source bone name",
                                default="")
    name_replace: StringProperty(name="Replace in name",
                                 description= "Replace in source bone name",
                                 default="")
    name_replace_with: StringProperty(name="Replace in name with",
                                       description= "Replace with",
                                      default="")
    name_suffix: StringProperty(name="Add suffix to name",
                                 description= "Add suffix to source bone name",
                                default="")

    src_preset: EnumProperty(items=preset_handler.iterate_presets_with_current,
                             description="Source Armature",
                             name="Source Preset",
                             )

    trg_preset: EnumProperty(items=preset_handler.iterate_presets_with_current,
                             description="Target Armature (Active Armature)",
                             name="Target Preset",
                             )
    
    only_selected: BoolProperty(name="Only Selected", default=False,
                                description="Align only selected bones (From Source Armature)")
    
    #bone influence

    bone_inf: BoolProperty(name="Bones",
                               description= "select between Bones",
                               default=False)
    
    include_bone: EnumProperty(items=[
        ('include', "Include", "Include Bones"),
        ('exclude', "Exclude", "Exclude Bones")
         ],
        name="",
        default='include')

    bone_sel: StringProperty(name = "",
                              description=" Bones List",
                              default="", options = {'SKIP_SAVE'})
    
    incl_child:  BoolProperty(name="",
                              description="Include All The Children",
                             default=True)

    clean_all_bone:  BoolProperty(name="",
                              description="Delete All",
                             default=False, options = {'SKIP_SAVE'})

    clean_last_bone:  BoolProperty(name="",
                              description="Delete the last one",
                              default=False, options = {'SKIP_SAVE'})

    bone_collection = dict()

    #limb
    limb: BoolProperty(name="Limb",
                               description= "select between Limb Bones",
                               default=False)
    
    include: EnumProperty(items=[
        ('include', "Include", "Include Bones"),
        ('exclude', "Exclude", "Exclude Bones")
         ],
        name="",
        default='include')

    limb_bones:  StringProperty(search=bone_utils.get_all_limb,
        name="", default="--",
        options = {'SKIP_SAVE'})

    clean_all_limb:  BoolProperty(name="",
                              description="Delete All",
                             default=False, options = {'SKIP_SAVE'})

    clean_last_limb:  BoolProperty(name="",
                              description="Delete the last one",
                              default=False, options = {'SKIP_SAVE'})

    limb_collection: StringProperty()

    #------------

    apply_transforms: BoolProperty(name='Apply Transform', default=True,
                                   description='Apply Transform (Recommended)')

    center : BoolProperty(name="", description= "Reset The Position an rotation",
                                         default=True)
    
    only_rotate: BoolProperty(name="Only Rotation",
                              description="Align only the Rotation",
                              default=False)
    
    search_option: BoolProperty(name="Search",
                                description="Set The Head Bone Manually",
                                default=False)
    Preserve_Height: BoolProperty(name="Preserve Height",
                                  description="Preserve The Height Of The Armature",
                              default=True)
    head_bone: StringProperty(name = "Head Bone",
                              default="")

    Preserve_Width: BoolProperty(name="Preserve Width",
                                  description="Preserve The Width Of The Armature",
                              default=False)

    Preserve_Depth: BoolProperty(name="Preserve Depth",
                                  description="Preserve The Depth Of The Armature",
                              default=False)
    
    Preserve_Connection: BoolProperty(name="Preserve Connection",
                                  description="Preserve The Connection Of The Bone",
                              default=True)

    align: BoolProperty(name="Align Bones", default=True)

    def draw(self, context):

        layout = self.layout
        column = layout.column()

        o = ops.get_ob_or_armature(context, context.active_object)

        #test if its local
        if o.library is not None:
            column.label(text=f"make '{o.name}' local", icon='ERROR')
            column.separator()

        sr_ob = None
        for ob in ops.get_selected_obs(context):
            if ob.type == 'ARMATURE' and ob != ops.get_ob_or_armature(context, context.active_object):
                sr_ob = ob
                break

        #test if its local
        if sr_ob and (sr_ob.library is not None or sr_ob.data.library is not None):
            column.label(text=f"make '{sr_ob.name}' local", icon='ERROR')
            column.separator()

        row = column.split(factor=0.10, align=True)
        row.label(text="")
        row.prop(self, 'same_bone_names')

        if not self.same_bone_names:

            row = column.split(factor=0.10, align=True)
            row.label(text="")
            row.prop(self, 'src_preset', text="To Bind")

            row = column.split(factor=0.10, align=True)
            row.label(text="")
            row.prop(self, 'trg_preset', text="Bind To")



        row = column.split(factor=0.10, align=True)
        row.label(text="")
        row.prop(self, 'bind_by_name', text="Also by Name")
        if self.bind_by_name:
            row = column.row()
            col = row.column()
            col.label(text="Prefix")
            col.prop(self, 'name_prefix', text="")

            col = row.column()
            col.label(text="Replace:")
            col.prop(self, 'name_replace', text="")

            col = row.column()
            col.label(text="With:")
            col.prop(self, 'name_replace_with', text="")

            col = row.column()
            col.label(text="Suffix:")
            col.prop(self, 'name_suffix', text="")

        row = column.split(factor=0.10, align=True)
        row.label(text="")
        row.prop(self, 'only_selected', text="Only Selected")

        #bone influence

        row = column.split(factor=0.10, align=True)
        row.label(text="")
        row.prop(self, 'bone_inf')

        if self.bone_inf:
            subcol = row.column()
            subcol.prop(self, 'include_bone')

            # row = column.row()
            # row.label(text="")

            if sr_ob:

                row = column.split(factor=0.80, align=True)

                row.prop_search(self, 'bone_sel',
                            sr_ob.data,
                            "bones")

                row.prop(self, 'incl_child', toggle=True, icon='OUTLINER_DATA_ARMATURE')
                row.prop(self, 'clean_all_bone', toggle=True, icon='PANEL_CLOSE')
                row.prop(self, 'clean_last_bone',toggle=True, icon='TRACKING_CLEAR_BACKWARDS')

                i = 0
                row = column.split(factor=0.33, align=True)

                for k, v in self.bone_collection.items():
                    if i == 3:
                        row = column.split(factor=0.33, align=True)
                        i = 0
                    if len(v) > 1:
                        row.label(text=k, icon='OUTLINER_DATA_ARMATURE')
                    else:
                        row.label(text=k, icon='BONE_DATA')

                    i += 1
        
        #limb
        if not self.same_bone_names:
            row = column.split(factor=0.10, align=True)
            row.label(text="")
            row.prop(self, 'limb')

            if self.limb:
                subcol = row.column()
                subcol.prop(self, 'include')

                # row = column.row()
                # row.label(text="")

                row = column.split(factor=0.80, align=True)
                row.prop(self, 'limb_bones')
                row.prop(self, 'clean_all_limb', toggle=True, icon='PANEL_CLOSE')
                row.prop(self, 'clean_last_limb',toggle=True, icon='TRACKING_CLEAR_BACKWARDS')

                i = 0
                row = column.split(factor=0.33, align=True)

                limb_collection = self.limb_collection.split(":KBS:")

                for ik in limb_collection:
                    if not ik:
                        continue
                    if i == 3:
                        row = column.split(factor=0.33, align=True)
                        i = 0

                    row.label(text=ik, icon='OUTLINER_DATA_ARMATURE')

                    i += 1
            
        column.separator()
        row = column.row()
        row.label(text = "")

        row = column.split(factor=0.10, align=True)
        row.label(text="")
        subcol = row.split(factor=0.80, align=True)
        subcol.prop(self, 'apply_transforms')
        subcol.prop(self, 'center', toggle=True, icon='ORIENTATION_GLOBAL')

        row = column.split(factor=0.10, align=True)
        row.label(text="")
        row.prop(self, 'only_rotate')

        row = column.split(factor=0.10, align=True)
        row.label(text="")
        subrow = row.row()
        subrow.prop(self, "search_option", text="", icon="SYNTAX_ON")
        subrow.prop(self, 'Preserve_Height')

        if self.search_option and self.Preserve_Height:
            sr_ob = None
            for ob in ops.get_selected_obs(context):
                if ob != ops.get_ob_or_armature(context, context.active_object):
                    sr_ob = ob
                    break
            if sr_ob:
                if not self.head_bone:
                    row = column.row()
                    tex = "--Select a Head bone--".center(50)
                    row.label(text=tex, icon='ERROR')
                row = column.split(factor=0.10, align=True)
                row.label(text="")
                row.prop_search(self, 'head_bone',
                            sr_ob.data,
                            "bones", text="Head Bone")


        row = column.split(factor=0.10, align=True)
        row.label(text="")
        row.prop(self, 'Preserve_Width')


        row = column.split(factor=0.10, align=True)
        row.label(text="")
        row.prop(self, 'Preserve_Depth')

        row = column.split(factor=0.10, align=True)
        row.label(text="")
        row.prop(self, 'Preserve_Connection')

        row = column.split(factor=0.10, align=True)
        row.label(text="")
        row.prop(self, 'align', toggle = True)

    @classmethod
    def poll(cls, context):
        o = ops.get_ob_or_armature(context, context.active_object)
        if not o:
            return False
        if o.type != 'ARMATURE':
            return False
        if len(ops.get_selected_obs(context)) < 2:
            return False

        #At least 2 Armatures
        i = 0
        for ob in ops.get_selected_obs(context):
            if ob.type == 'ARMATURE':
                i = i + 1
            if i >= 2:
                return True

        return False
    
    def invoke(self, context, event):

        o = ops.get_ob_or_armature(context, context.active_object)

        to_bind = next(ob for ob in ops.get_selected_obs(context) if ob != o and ob.type == 'ARMATURE')

        if to_bind.data.retarget_retarget.has_settings():
            self.src_preset = '--Current--'

        else:
            self.src_preset = preset_handler.findPreset(to_bind)

        if o.data.retarget_retarget.has_settings():
            self.trg_preset = '--Current--'

        else:
            self.trg_preset = preset_handler.findPreset(o)

        if not self.head_bone in o.pose.bones:
            self.head_bone = ""

        # if self.Preserve_Height and not to_bind.data.retarget_retarget.spine.head:
        #     self.search_option = True

        return self.execute(context)

    def execute(self, context):

        o = ops.get_ob_or_armature(context, context.active_object)
        #test if its local
        if o.library is not None:
            return {'FINISHED'}

        o.select_set(True)

        bake_up = list(context.selected_objects)

        if not self.same_bone_names:
            #limb
            if self.clean_all_limb:
                if self.limb_collection:
                    self.limb_collection = ''
                self.clean_all_limb = False

            if self.clean_last_limb:
                if len(self.limb_collection) > 0 :
                    limb_collection = self.limb_collection.split(":KBS:")
                    limb_collection.pop()
                    self.limb_collection = ":KBS:".join(limb_collection)
                self.clean_last_limb = False

            if self.limb_bones != "--":
                limb_collection = self.limb_collection.split(":KBS:")
                if not self.limb_bones in limb_collection:
                    self.limb_collection +=":KBS:" + self.limb_bones
                self.limb_bones = "--"

        #bone influence
        if self.clean_all_bone:
            if len(self.bone_collection) > 0 :
                self.bone_collection.clear()
            self.clean_all_bone = False

        if self.clean_last_bone:
            if len(self.bone_collection) > 0 :
                self.bone_collection.popitem()
            self.clean_last_bone = False

        if self.bone_sel:

            if not self.bone_sel in self.bone_collection.keys():

                sr_ob = None
                for ob in ops.get_selected_obs(context):
                    if ob.type == 'ARMATURE' and ob != ops.get_ob_or_armature(context, context.active_object):
                        sr_ob = ob
                        break
                if sr_ob:

                    list_bone = list()

                    bone = sr_ob.pose.bones[self.bone_sel]
                    list_bone.append(bone.name)

                    if self.incl_child:

                        for b in bone.bone.children_recursive:
                            list_bone.append(b.name)

                    self.bone_collection[self.bone_sel] = list_bone

            self.bone_sel = ""

        #----

        current_m = context.mode

        trg_ob = ops.get_ob_or_armature(context, context.active_object)
        tmp_ob = trg_ob

        # action to range
        if trg_ob.animation_data and trg_ob.animation_data.action:
            bpy.ops.object.retarget_action_to_range()

        actif = context.active_object

        if trg_ob.type != 'ARMATURE':
            bpy.ops.object.mode_set(mode=current_m)
            return {'FINISHED'}
        
        trg_skeleton = HumanSkeleton()

        if not self.same_bone_names:
            if self.trg_preset == "--Current--" and trg_ob.data.retarget_retarget.has_settings():
                trg_settings = trg_ob.data.retarget_retarget
                trg_skeleton = preset_handler.get_settings_skel(trg_settings)
            else:
                trg_skeleton = preset_handler.set_preset_skel(self.trg_preset,  context)

            if not trg_skeleton:
                bpy.ops.object.mode_set(mode=current_m)
                return {'FINISHED'}
            
        if self.center:
            bpy.ops.object.mode_set(mode='OBJECT')
            trg_ob.location = [0,0,0]

            #no needed for trg_ob
            # if trg_ob.animation_data and trg_ob.animation_data.action:
            #     trg_ob.animation_data.action = None
            # for bone in trg_ob.pose.bones:
            #     bone.location = [0,0,0]
            #     bone.rotation_euler = [0,0,0]
            #     bone.rotation_quaternion = [1,0,0,0]
            #     bone.scale = [1,1,1]

        armatures = ops.get_selected_obs(context)
        for ob in armatures:
            if ob == trg_ob:
                continue

            if ob.type != 'ARMATURE':
                continue

            #test if its local
            if ob.library is not None or ob.data.library is not None:
                continue

            context.view_layer.objects.active = ob
            bpy.ops.object.mode_set(mode='POSE')

            bone_names_map = dict()

            src_skeleton = HumanSkeleton()
            src_settings = ob.data.retarget_retarget

            if not self.same_bone_names:

                if self.src_preset == '--Current--' and ob.data.retarget_retarget.has_settings():
                    if not src_settings.has_settings():
                        continue
                    src_skeleton = preset_handler.get_settings_skel(src_settings)
                else:
                    src_skeleton = preset_handler.get_preset_skel(self.src_preset, src_settings)

                if not src_skeleton:
                    continue

                bone_names_map = src_skeleton.conversion_map(trg_skeleton)

            else:

                
                def findBone(name, bones):

                    if name != "":

                        v = name
                        if ":" in name:
                            v = name.split(":")[-1]

                        for bone in bones:
                            if v in bone.name:
                                return bone.name
                    return ""

                for bone in ob.pose.bones:
                    name = ""
                    try:
                        pb = trg_ob.pose.bones[bone.name]
                        name = bone.name
                    except KeyError:
                        name = findBone(bone.name, trg_ob.pose.bones)
                        
                    if not name:
                        continue

                    # if bone_utils.is_pose_bone_all_locked(bone):
                    #     continue

                    bone_names_map[bone.name] = name
            
            if self.center:
                bpy.ops.object.mode_set(mode='OBJECT')
                ob.location = [0,0,0]
                bpy.ops.object.mode_set(mode='POSE')

                if ob.animation_data and ob.animation_data.action:
                    ob.animation_data.action = None
                for bone in ob.pose.bones:
                    bone.location = [0,0,0]
                    bone.rotation_euler = [0,0,0]
                    bone.rotation_quaternion = [1,0,0,0]
                    bone.scale = [1,1,1]

            if self.bind_by_name:
                # Look for bones present in both
                for bone in ob.pose.bones:
                    bone_name = bone.name
                    bone_look_up = self.name_prefix + bone_name.replace(self.name_replace, self.name_replace_with) + self.name_suffix

                    if bone_look_up in bone_names_map:
                        continue
                    # if bone_utils.is_pose_bone_all_locked(bone):
                    #     continue
                    if bone_look_up in trg_ob.pose.bones:
                        bone_names_map[bone_name] = bone_look_up

            if self.only_selected:
                b_names = list(bone_names_map.keys())
                for b_name in b_names:
                    if not b_name:
                        continue
                    try:
                        bone = ob.pose.bones[b_name]
                    except KeyError:
                        continue

                    if not bone.select:
                        del bone_names_map[b_name]

            #bone influence
            list_bone_list = []
            if self.bone_inf:

                if self.bone_collection:

                    #list_bone_list = []
                    for b_list in self.bone_collection.values():
                        list_bone_list.extend(b_list)

            #limb
            list_limb = []
            if not self.same_bone_names:
                
                if self.limb:
                    other_bone_limb = bone_utils.get_limb_other_bone(src_settings)
                    limb_collection = self.limb_collection.split(":KBS:")
                    for limb in limb_collection:
                        
                        if limb == "hips":
                            list_limb.append(src_skeleton.spine.hips)
                          
                        if limb in ('spine', 'left_arm', 'left_arm_ik', 'right_arm', 'right_arm_ik',
                                        'right_leg_ik', 'left_leg_ik'):
                            
                            setting = getattr(src_skeleton, limb)
                            for k in sorted(dir(setting)):
                                if k.startswith("__") or k in ["bl_rna", "type", "name"]:
                                    continue
                                try:
                                    if k not in ["super_copy", "shoulder", "hips", "head", "neck"]:
                                    #if not 'super_copy' in k and not "shoulder" in k and not "hips" in k:
                                        tmp = getattr(setting, k)
                                        
                                        list_limb.append(tmp)
                                except:
                                    continue
                                
                        if limb == "right_leg":
                            list_limb.append(src_skeleton.right_leg.upleg)
                            list_limb.append(src_skeleton.right_leg.leg)

                        if limb == "left_leg":
                            list_limb.append(src_skeleton.left_leg.upleg)
                            list_limb.append(src_skeleton.left_leg.leg)

                        if limb == "right_foot":
                            list_limb.append(src_skeleton.right_leg.foot)
                            list_limb.append(src_skeleton.right_leg.toe)

                        if limb == "left_foot":
                            list_limb.append(src_skeleton.left_leg.foot)
                            list_limb.append(src_skeleton.left_leg.toe)
                                
                        if limb == "head":
                            list_limb.append(src_skeleton.spine.neck)
                            list_limb.append(src_skeleton.spine.head)
                            setting = getattr(src_skeleton, "face")
                            for k in sorted(dir(setting)):
                                if k.startswith("__") or k in ["bl_rna", "type", "name"]:
                                    continue
                                try:
                                    #if not 'super_copy' in k and not "shoulder" in k and not "hips" in k:
                                    tmp = getattr(setting, k)
                                    list_limb.append(tmp)
                                except:
                                    continue

                        if limb == "RightShoulder":
                            list_limb.append(src_skeleton.right_arm.shoulder)
                            
                        if limb == "LeftShoulder":
                            list_limb.append(src_skeleton.left_arm.shoulder)

                        if limb == "left_fingers":
                            list_limb.extend(chain(*src_skeleton.left_fingers.values()))
                            
                        if limb == "right_fingers":
                            list_limb.extend(chain(*src_skeleton.right_fingers.values()))
                        
                        if limb in other_bone_limb:
                            if src_settings.other_bone:
                                for item in src_settings.other_bone:
                                    if limb == item.limb:
                                        list_limb.append(item.bone_name)
                                   
            # set between bone and limb options
            if list_bone_list or list_limb:

                b_names = list(bone_names_map.keys())
                for key in b_names:

                    if list_bone_list:

                        if key in list_bone_list:
                            if self.include_bone == 'exclude':
                                
                                # if list_limb and key in list_limb and self.include == 'include':
                                #     continue

                                # if list_limb and key not in list_limb and self.include == 'exclude':
                                #     continue

                                del bone_names_map[key]
                                continue
                        else:
                            if self.include_bone == 'include':

                                if list_limb and key in list_limb and self.include == 'include':
                                    continue

                                # if list_limb and key not in list_limb and self.include == 'exclude':
                                #     continue

                                del bone_names_map[key]
                                continue
                    
                    if list_limb:
                        
                        if key in list_limb:
                            if self.include == 'exclude':

                                # if list_bone_list and key in list_bone_list and self.include_bone == 'include':
                                #     continue

                                # if list_bone_list and key not in list_bone_list and self.include_bone == 'exclude':
                                #     continue

                                del bone_names_map[key]
                        else:
                            if self.include == 'include':

                                if list_bone_list and key in list_bone_list and self.include_bone == 'include':
                                    continue

                                # if list_bone_list and key not in list_bone_list and self.include_bone == 'exclude':
                                #     continue

                                del bone_names_map[key]
            #--------

            if self.apply_transforms:
                
                bpy.ops.object.mode_set(mode='OBJECT')
               
                ob.select_set(True)
                context.view_layer.objects.active = ob
                try:
                    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
                except:
                    pass

            if self.Preserve_Height:
                try:
                    bpy.ops.object.mode_set(mode='OBJECT')
                    # duplic Oject
                    #prevent the duplication of action
                    action = None
                    if trg_ob.animation_data and trg_ob.animation_data.action:
                        action = trg_ob.animation_data.action
                        trg_ob.animation_data.action = None
                    
                    tmp_ob = trg_ob.copy()
                    tmp_ob.data = trg_ob.data.copy()
                    context.collection.objects.link(tmp_ob)
                    
                    if trg_ob.animation_data and action:
                        trg_ob.animation_data.action = action

                    if self.search_option:
                        if self.head_bone:
                            trg_head = bone_names_map[self.head_bone]
                            trg_bone = tmp_ob.pose.bones[trg_head]
                        else:
                            break
                    else:
                        trg_bone = tmp_ob.pose.bones[getattr(trg_skeleton.spine, 'head')]

                    trg_height = (tmp_ob.matrix_world @ trg_bone.bone.head_local)

                    if self.search_option:
                        if self.head_bone:
                            ob_height = (ob.matrix_world @ ob.pose.bones[self.head_bone].bone.head_local)
                        else:
                            break
                    else:
                        ob_height = (ob.matrix_world @ ob.pose.bones[getattr(src_skeleton.spine, 'head')].bone.head_local)

                    height_ratio = ob_height[2] / trg_height[2]

                    tmp_ob.scale *= height_ratio
                    # Apply scale
                    context.view_layer.objects.active = tmp_ob
                    bpy.ops.object.select_pattern( pattern=tmp_ob.name, case_sensitive=True, extend=False)
                    try:
                        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
                    except:
                        pass

                    for o in armatures:
                        o.select_set(True, view_layer = context.view_layer)
                    context.view_layer.objects.active = ob
                except KeyError:
                    pass

            bpy.ops.object.mode_set(mode='EDIT')

            if self.align:

                bone_to_aligne = dict()
                bone_to_aligne2 = dict()
                if self.Preserve_Connection:
                    
                    #bone aligned
                    for bone in ob.data.edit_bones:
                        if not bone.parent or bone.use_connect:
                            continue
                        parent = bone.parent
                        if abs((parent.tail - bone.head).length) < 0.01:
                            bone_to_aligne[parent] = bone
                        elif  abs((parent.head - bone.head).length) < 0.01:
                            bone_to_aligne2[parent] = bone

                for src_name, trg_name in bone_names_map.items():

                    if not src_name:
                        continue
                    try:

                        sr_bone = ob.data.edit_bones[src_name]

                        if self.Preserve_Height:
                            tj_bone = tmp_ob.data.edit_bones[trg_name]
                        else:
                            tj_bone = trg_ob.data.edit_bones[trg_name]

                        matrix = tj_bone.matrix.copy()

                        if self.Preserve_Width:
                            matrix_sr = sr_bone.matrix

                            matrix[0][0] = matrix_sr[0][0]
                            matrix[0][1] = matrix_sr[0][1]
                            matrix[0][2] = matrix_sr[0][2]
                            matrix[0][3] = matrix_sr[0][3]

                        if self.Preserve_Depth:
                            matrix_sr = sr_bone.matrix

                            matrix[1][0] = matrix_sr[1][0]
                            matrix[1][1] = matrix_sr[1][1]
                            matrix[1][2] = matrix_sr[1][2]
                            matrix[1][3] = matrix_sr[1][3]

                        if self.only_rotate:
                            matrix_sr = sr_bone.matrix
                            #LOCATIiON
                            matrix[0][3] = matrix_sr[0][3]
                            matrix[1][3] = matrix_sr[1][3]
                            matrix[2][3] = matrix_sr[2][3]
                            matrix[3][3] = matrix_sr[3][3]

                        else:
                            sr_bone.head = tj_bone.head
                            sr_bone.tail = tj_bone.tail

                        sr_bone.matrix = matrix
                        sr_bone.roll = tj_bone.roll

                    except KeyError:
                        continue

                # realign bone
                for parent, child in bone_to_aligne.items():
                    parent.tail = child.head

                for parent, child in bone_to_aligne2.items():
                    parent.head = child.head

            #delete the tmp
        if self.Preserve_Height and tmp_ob != trg_ob:
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.data.objects.remove(tmp_ob, do_unlink=True)

            for o in armatures:
                o.select_set(True, view_layer = context.view_layer)

            context.view_layer.objects.active = trg_ob


        bpy.ops.object.mode_set(mode=current_m)
        for o in bake_up:
            o.select_set(True, view_layer = context.view_layer)
        context.view_layer.objects.active = actif
        return {'FINISHED'}


class AdjustAnimation(Operator):
    bl_idname = "armature.retarget_adjust_animation"
    bl_label = "Adjust Animation"
    bl_options = {'REGISTER', 'PRESET', 'UNDO'}

#Ajust
    adjust_animation: BoolProperty(name="Adjust Animation",
                               description="Create a Armature that will be used for the Adjustment, ( you'll need to bake to save the change)(select a armature)",
                               default=False)

    only_animated_Bone: BoolProperty(name="Only Animated Bone",
                               default=True)

    bind_floating: BoolProperty(name="Bind Floating",
                                description="Align unparented bones",
                                default=True)

    motion_bones:  StringProperty(name = "",
                              description="Motion Bones List (detect these bones to add the location constraint)",
                              default="", options = {'SKIP_SAVE'})

    clean_all:  BoolProperty(name="",
                              description="Delete All",
                             default=False, options = {'SKIP_SAVE'})

    clean_last:  BoolProperty(name="",
                              description="Delete the last one",
                              default=False, options = {'SKIP_SAVE'})

    motion_collection = []


    root_motion_a: StringProperty(name = "Root", default="")

    keep_offset: BoolProperty(name="Keep Offset", default=False)
    keep_offset_value: FloatProperty(name="value", description="Keep Offset value", default=0)

    root_cp_loc_x: BoolProperty(name="Root Copy Loc X", description="Copy Root X Location", default=True)
    root_cp_loc_y: BoolProperty(name="Root Copy Loc y", description="Copy Root Y Location", default=True)
    root_cp_loc_z: BoolProperty(name="Root Copy Loc Z", description="Copy Root Z Location", default=True)

    root_use_loc_min_x: BoolProperty(name="Use Root Min X", description="Use Minimum Root X Location", default=False)
    root_use_loc_min_y: BoolProperty(name="Use Root Min Y", description="Use Minimum Root Y Location", default=False)
    root_use_loc_min_z: BoolProperty(name="Use Root Min Z", description="Use Minimum Root Z Location", default=False)

    root_loc_min_x: FloatProperty(name="Root Min X", description="Minimum Root X Location", default=0.0)
    root_loc_min_y: FloatProperty(name="Root Min Y", description="Minimum Root Y Location", default=0.0)
    root_loc_min_z: FloatProperty(name="Root Min Z", description="Minimum Root Z Location", default=0.0)

    root_use_loc_max_x: BoolProperty(name="Use Root Max X", description="Use Maximum Root X Location", default=False)
    root_use_loc_max_y: BoolProperty(name="Use Root Max Y", description="Use Maximum Root Y Location", default=False)
    root_use_loc_max_z: BoolProperty(name="Use Root Max Z", description="Use Maximum Root Z Location", default=False)

    root_loc_max_x: FloatProperty(name="Root Max X", description="Maximum Root X Location", default=0.0)
    root_loc_max_y: FloatProperty(name="Root Max Y", description="Maximum Root Y Location", default=0.0)
    root_loc_max_z: FloatProperty(name="Root Max Z", description="Maximum Root Z Location", default=0.0)

    root_cp_rot_x: BoolProperty(name="Root Copy Rot X", description="Copy Root X Rotation", default=False)
    root_cp_rot_y: BoolProperty(name="Root Copy Rot y", description="Copy Root Y Rotation", default=False)
    root_cp_rot_z: BoolProperty(name="Root Copy Rot Z", description="Copy Root Z Rotation", default=False)

    root_cp_scal_x: BoolProperty(name="Root Copy Scal X", description="Copy Root X Scale", default=False)
    root_cp_scal_y: BoolProperty(name="Root Copy Scal y", description="Copy Root Y Scale", default=False)
    root_cp_scal_z: BoolProperty(name="Root Copy Scal Z", description="Copy Root Z Scale", default=False)


    root_cp_rot_x: BoolProperty(name="Root Copy Rot X", description="Copy Root X Rotation", default=False)
    root_cp_rot_y: BoolProperty(name="Root Copy Rot y", description="Copy Root Y Rotation", default=False)
    root_cp_rot_z: BoolProperty(name="Root Copy Rot Z", description="Copy Root Z Rotation", default=False)

    root_cp_scal_x: BoolProperty(name="Root Copy Scal X", description="Copy Root X Scale", default=False)
    root_cp_scal_y: BoolProperty(name="Root Copy Scal y", description="Copy Root Y Scale", default=False)
    root_cp_scal_z: BoolProperty(name="Root Copy Scal Z", description="Copy Root Z Scale", default=False)


    ret_bones_collection: StringProperty(name="Layer",
                                             default="Retarget Bones",
                                             description="Armature collection to use for connection bones (Usefull to ADD modification to the Animation)")

    apply:BoolProperty(name="APPLY",  description="APPLY", default=False , options = {'SKIP_SAVE'})
#-------------------------------------------------------------------------
    speed: FloatProperty(name="Speed", default=1)

#repeat 
    repeat: FloatProperty(name="Repeat", default=1, options={'SKIP_SAVE'})
    follow: StringProperty(name = "Continues", 
                            description=" root bone ",
                            default="")

    custom_start_end:BoolProperty(name="Custom Start and End", 
                                  description="Start/End of the Repetition",
                                  default=False)

    start:IntProperty(name="Start", default=0)

    end:IntProperty(name="End", default=32)

#-------------
    empty_f: BoolProperty(name="Delete Empty Fcurve",
                           default=False)
    
# in place ------------------------
    in_place: BoolProperty(name="In Place",
                           description="the animation don't move",
                           default=False)

    root_motion: StringProperty(name = "Root Motion", default="")

    position_x: BoolProperty(name="X",
                               description="Delete the Position X",
                               default=True)

    position_y: BoolProperty(name="Y",
                               description="Delete the Position Y",
                               default=True)

    position_z: BoolProperty(name="Z",
                               description="Delete the Position Z",
                               default=True)

    rotation_x: BoolProperty(name="X",
                               description="Delete the Rotation X",
                               default=False)

    rotation_y: BoolProperty(name="Y",
                               description="Delete the Rotation Y",
                               default=False)

    rotation_z: BoolProperty(name="Z",
                               description="Delete the Rotation Z",
                               default=False)

    scale_freeze: BoolProperty(name="Delete the scale",
                               description="Delete the Scale",
                               default=False)


    all_slots:BoolProperty(name="All Slots",
                               description="Apply these effects in all slots",
                               default=False)

    play: BoolProperty(name= "PLAY", default=True)

    action_range: BoolProperty(name= "Action Range to Scene",
                               description="Set Playback range to current action Start/End",
                               default=True)
    
    #similar

    show_10: BoolProperty(name="",
                          description="Show Those Action",
                                default=True)
    
    show_all: BoolProperty(name="",
                           description="SHow All Action",
                                default=False, options={'SKIP_SAVE'})

    bake_similar:BoolProperty(name="Include Others Actions",
                              description="convert other action",
                                default=False)
    
    apply_All:BoolProperty(name="Apply", options={'SKIP_SAVE'},
                              description="Apply in Actions (can take some time)",
                                default=False)
    #-----
    only_selected_action: BoolProperty(name="Only Selected Action(s)",
                                description= "Only selected Action(s) in Action Manager",
                                default=False)
    
    by_name: BoolProperty(name="by Name",
                            description= "Only Look for Action with this Prefix/Suffix",
                            default=False)
    
    include: EnumProperty(items=[
        ('include', "Include", "Include Action with this Prefix/Suffix"),
        ('exclude', "Exclude", "Exclude Action with this Prefix/Suffix")
         ],
        name="",
        default='include')
    
    prefix: StringProperty(name="prefix",
                                description= "Prefix (comma is the separator)",
                                default="")
    
    contain: StringProperty(name="Contain",
                                  description= "Contain (comma is the separator)",
                                 default="")
    
    suffix: StringProperty(name="suffix",
                                 description= "Suffix (comma is the separator)",
                                default="")
    
    #list 

    action_select: BoolProperty(name="Action",
                               description= "Select between Actions",
                               default=False)
    
    include_a: EnumProperty(items=[
        ('include', "Include", "Include Actions"),
        ('exclude', "Exclude", "Exclude Actions")
         ],
        name="",
        default='include')
    
    action_l: StringProperty(name = "",
                              description=" Actions List",
                              default="", options = {'SKIP_SAVE'})

    action_clean_all:  BoolProperty(name="",
                              description="Delete All",
                             default=False, options = {'SKIP_SAVE'})

    action_clean_last:  BoolProperty(name="",
                              description="Delete the last one",
                              default=False, options = {'SKIP_SAVE'})
    
    #only similar
    only_similar: BoolProperty(name="Only Similar Actions",
                               description= "Only Similar Actions",
                               default=True)

    action_collection = []

    number_trg = dict()

    def draw(self, context):
        layout = self.layout
        column = layout.column()

        #test if its local
        o = ops.get_ob_or_armature(context, context.active_object)
        if o.animation_data and o.animation_data.action and o.animation_data.action.library is not None:
            column.label(text=f"make the action local :'{o.animation_data.action.name}' ", icon='ERROR')
            column.separator()

        if self.bake_similar and self.number_trg:

            for ob_name, action_valid in self.number_trg.items():
                column.label(text=f"Ajust {len(action_valid)} Actions of {ob_name}")

                show_10 = 10

                if self.show_10 and not self.show_all and action_valid:

                    i = 1
                    for action in action_valid:
                        if i > show_10:
                            break
                        column.label(text=f"- {action.name} ")
                        i += 1

                if self.show_all and action_valid:

                    for action in action_valid:
                        column.label(text=f"- {action.name} ")

                if (not self.show_all and len(action_valid) >= 1) or (self.show_10 and len(action_valid) > show_10):
                    
                    row = column.split(factor=0.80, align=True)
                    row.label(text="")

                    if not self.show_all and len(action_valid) >= 1 :
                        row.prop(self, "show_10", toggle=True, icon='DOWNARROW_HLT')

                    if self.show_10 and len(action_valid) > show_10 :
                        row.prop(self, "show_all", toggle=True, icon='DOWNARROW_HLT')
            column.separator()
        else:
            #show number
            armatures = ops.get_selected_obs(context)
            num = 0
            for armature in armatures:

                if armature.type != 'ARMATURE':
                    continue
                num += 1
            if num > 1:
                row = column.split(factor=0.050, align=True)
                row.label(text="")
                row.label(text=f"{num} Armatures Selected")
                column.separator()

        row = column.split(factor=0.050, align=True)
        row.label(text="")
        row.prop(self, "adjust_animation")

        obs = ops.get_selected_obs(context)
        o = ops.get_ob_or_armature(context, context.active_object)

        if not o.animation_data or not o.animation_data.action:

            for ob in obs:
                if not ob:
                    continue
                if not ob.animation_data:
                    continue
                if not ob.animation_data.action:
                    continue
                o = ob
                break

        if self.adjust_animation and o.type == 'ARMATURE':

            #test if its local
            if o.library is not None or o.data.library is not None:
                column.label(text=f"make '{o.name}' local", icon='ERROR')
                column.separator()

            row = column.split(factor=0.20, align=True)
            row.label(text="")
            row.prop(self, 'bind_floating')

            row = column.split(factor=0.20, align=True)
            row.label(text="")
            row.prop(self, 'only_animated_Bone')

            #ik bone collection
            row = column.row()
            row.label(text="")

            row = column.split(factor=0.80, align=True)
            row.prop_search(self, 'motion_bones',
                        o.data,
                        "bones")
            row.prop(self, 'clean_all', toggle=True, icon='PANEL_CLOSE')
            row.prop(self, 'clean_last',toggle=True, icon='TRACKING_CLEAR_BACKWARDS')

            i = 0
            row = column.split(factor=0.33, align=True)

            for ik in self.motion_collection:
                if i == 3:
                    row = column.split(factor=0.33, align=True)
                    i = 0

                row.label(text=ik, icon='BONE_DATA')

                i += 1

            row = column.row()
            row.label(text="")


            row = column.split(factor=0.20, align=True)
            row.label(text="")
            row.prop_search(self, 'root_motion_a',
                            o.data,
                            "bones")

            if self.root_motion_a:
                row = column.row(align=True)
                row.label(text="Location")
                row.prop(self, "root_cp_loc_x", text="X", toggle=True)
                row.prop(self, "root_cp_loc_y", text="Y", toggle=True)
                row.prop(self, "root_cp_loc_z", text="Z", toggle=True)

                if any((self.root_cp_loc_x, self.root_cp_loc_y, self.root_cp_loc_z)):
                    column.separator()

                    #keep offset
                    if self.root_cp_loc_z:

                        row = column.row(align=False)
                        row.prop(self, "keep_offset")
                        subcol = row.column()
                        subcol.prop(self, "keep_offset_value", text="")
                        subcol.enabled = self.keep_offset
                        row.separator()

                    # Min/Max X
                    if self.root_cp_loc_x:
                        row = column.row(align=True)
                        row.prop(self, "root_use_loc_min_x", text="Min X")

                        subcol = row.column()
                        subcol.prop(self, "root_loc_min_x", text="")
                        subcol.enabled = self.root_use_loc_min_x

                        row.separator()
                        row.prop(self, "root_use_loc_max_x", text="Max X")
                        subcol = row.column()
                        subcol.prop(self, "root_loc_max_x", text="")
                        subcol.enabled = self.root_use_loc_max_x
                        row.enabled = self.root_cp_loc_x

                    # Min/Max Y
                    if self.root_cp_loc_y:
                        row = column.row(align=True)
                        row.prop(self, "root_use_loc_min_y", text="Min Y")

                        subcol = row.column()
                        subcol.prop(self, "root_loc_min_y", text="")
                        subcol.enabled = self.root_use_loc_min_y

                        row.separator()
                        row.prop(self, "root_use_loc_max_y", text="Max Y")
                        subcol = row.column()
                        subcol.prop(self, "root_loc_max_y", text="")
                        subcol.enabled = self.root_use_loc_max_y
                        row.enabled = self.root_cp_loc_y

                    # Min/Max Z
                    if self.root_cp_loc_z:
                        row = column.row(align=True)
                        row.prop(self, "root_use_loc_min_z", text="Min Z")

                        subcol = row.column()
                        subcol.prop(self, "root_loc_min_z", text="")
                        subcol.enabled = self.root_use_loc_min_z

                        row.separator()
                        row.prop(self, "root_use_loc_max_z", text="Max Z")
                        subcol = row.column()
                        subcol.prop(self, "root_loc_max_z", text="")
                        subcol.enabled = self.root_use_loc_max_z
                        row.enabled = self.root_cp_loc_z

                    column.separator()

                row = column.row(align=True)
                row.label(text="Rotation")
                row.prop(self, "root_cp_rot_x", text="X", toggle=True)
                row.prop(self, "root_cp_rot_y", text="Y", toggle=True)
                row.prop(self, "root_cp_rot_z", text="Z", toggle=True)

                row = column.row(align=True)
                row.label(text="Scale")
                row.prop(self, "root_cp_scal_x", text="X", toggle=True)
                row.prop(self, "root_cp_scal_y", text="Y", toggle=True)
                row.prop(self, "root_cp_scal_z", text="Z", toggle=True)

                row = column.row()
                row.label(text="")

            row = column.split(factor=0.20, align=True)
            row.label(text="")
            row.prop(self, "ret_bones_collection")

            row = column.row(align=True)
            row.prop(self, "apply",  toggle=True)

        column.separator()

        row = column.split(factor=0.05, align=True)
        row.label(text="")
        row.prop(self, "speed")

        column.separator()

        channelbag = None

        action = o.animation_data.action
        slot = o.animation_data.action_slot
        if slot:
            channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)


        row = column.split(factor=0.05, align=True)
        row.label(text="")
        row.prop(self, "repeat")
        if channelbag:
            row.prop_search(self, 'follow',
                                channelbag,
                                "groups", text="")
        row = column.split(factor=0.05, align=True)
        row.label(text="")
        row.prop(self, "custom_start_end")

        if self.custom_start_end:
            row = column.split(factor=0.05, align=True)
            row.label(text="")
            row.prop(self, "start")
            row.prop(self, "end")

        column.separator()

        row = column.split(factor=0.05, align=True)
        row.label(text="")
        row.prop(self, "empty_f")

        column.separator()
        
        row = column.split(factor=0.05, align=True)
        row.label(text="")
        row.prop(self, "in_place")

        if self.in_place:

           
            if channelbag:
                row = column.split(factor=0.20, align=True)
                row.label(text="Root Motion")
                row.prop_search(self, 'root_motion',
                            channelbag,
                            "groups", text="")

                row = column.row(align=True)
                row.label(text="Location")
                row.prop(self, "position_x", toggle=True)
                row.prop(self, "position_y", toggle=True)
                row.prop(self, "position_z", toggle=True)

                row = column.row(align=True)
                row.label(text="Rotation")
                row.prop(self, "rotation_x", text="X", toggle=True)
                row.prop(self, "rotation_y", text="Y", toggle=True)
                row.prop(self, "rotation_z", text="Z", toggle=True)

                row = column.split(factor=0.20, align=True)
                row.label(text="Scale")
                row.prop(self, "scale_freeze", text="Delete the Scale", toggle=True)

        if not self.bake_similar:
            row = column.split(factor=0.05, align=True)
            row.label(text="")
            row.prop(self, "all_slots", toggle = True)

        column.separator()

        row = column.split(factor=0.05, align=True)
        row.label(text="")
        row.prop(self, "bake_similar")

        if self.bake_similar:

            row = column.split(factor=0.05, align=True)
            row.label(text="")
            row.prop(self, "only_selected_action")

            row = column.split(factor=0.05, align=True)
            row.label(text="")
            row.prop(self, "by_name")

            if self.by_name:
                subcol = row.column()
                subcol.prop(self, 'include')

                row = column.row()
                col = row.column()
                col.label(text="Prefix")
                col.prop(self, 'prefix', text="")

                col = row.column()
                col.label(text="Contain:")
                col.prop(self, 'contain', text="")

                col = row.column()
                col.label(text="Suffix:")
                col.prop(self, 'suffix', text="")

            row = column.split(factor=0.05, align=True)
            row.label(text="")
            row.prop(self, "action_select")

            if self.action_select:

                subcol = row.column()
                subcol.prop(self, 'include_a')

                row = column.split(factor=0.80, align=True)
                row.prop_search(self, 'action_l',
                            bpy.data,
                            "actions")
                
                row.prop(self, 'action_l')
                row.prop(self, 'action_clean_all', toggle=True, icon='PANEL_CLOSE')
                row.prop(self, 'action_clean_last',toggle=True, icon='TRACKING_CLEAR_BACKWARDS')

                i = 0
                row = column.split(factor=0.33, align=True)

                for act in self.action_collection:
                    if i == 3:
                        row = column.split(factor=0.33, align=True)
                        i = 0

                    row.label(text=act, icon='ACTION')

                    i += 1

            row = column.split(factor=0.05, align=True)
            row.label(text="")
            row.prop(self, "only_similar")
            
        if self.bake_similar:
            row = column.split(factor=0.05, align=True)
            row.label(text="")
            row.prop(self, "apply_All", toggle=True, icon='ACTION')

        column.separator()

        row = column.split(factor=0.05, align=True)
        row.label(text="")
        row.prop(self, "play", toggle=True, icon='PLAY')
        row.prop(self, "action_range", toggle=True, icon='PREVIEW_RANGE')

    def correct_action(self, action, context):

        if not self.bake_similar:
            return True
        
        if self.only_selected_action:
            selected_act = selected_action(context)
            if not action in selected_act:
                return False

        incl = -1
        incls = -1
        inclc = -1

        
        if self.by_name:
            if self.include == 'include':
                if self.prefix:
                    list_ = self.prefix.split(",")
                    incl = 0
                    for li in list_:
                        if li and not action.name.startswith(li):
                            incl -= 1
                        if li and action.name.startswith(li):
                            incl += 1
                    if incl < 0:
                        return self.test_list_action(action)

                if self.suffix:
                    list_ = self.suffix.split(",")
                    incls = 0
                    for li in list_:
                        if li and not action.name.endswith(li):
                            incls -= 1
                        if li and action.name.endswith(li):
                            incls += 1
                    if incls < 0:
                        return self.test_list_action(action)
                    
                if self.contain:
                    list_ = self.contain.split(",")
                    inclc = 0
                    for li in list_:
                        if li and not li in action.name:
                            inclc -= 1
                        if li and li in action.name:
                            inclc += 1
                    if inclc < 0:
                        return self.test_list_action(action)
            
            else:
                if self.prefix:
                    list_ = self.prefix.split(",")
                    for li in list_:
                        if li and action.name.startswith(li):
                            return False

                if self.suffix:
                    list_ = self.suffix.split(",")
                    for li in list_:
                        if li and action.name.endswith(li):
                            return False

                if self.contain:
                    list_ = self.contain.split(",")
                    for li in list_:
                        if li and li in action.name:
                            return False
        
        if self.action_select:

            if self.include_a == 'include':

                if self.action_collection and action.name not in self.action_collection:
                    return False or (incl >= 0 or incls >= 0 or inclc >= 0)
            
            elif self.action_collection and action.name in self.action_collection:
                return False
        
        return True
    
    def test_list_action(self, action):
        if self.action_select:
            if self.include_a == 'include':

                if self.action_collection and action.name in self.action_collection:
                    return True
        return False
    @classmethod
    def poll(cls, context):
        obs = ops.get_selected_obs(context)
        for ob in obs:
            if not ob:
                continue
            if not ob.animation_data:
                continue
            if not ob.animation_data.action:
                continue
            return True
        return False

    def invoke(self, context, event):
        channelbag = None
        ob = ops.get_ob_or_armature(context, context.active_object)
        action = ob.animation_data.action
        slot = ob.animation_data.action_slot
        if slot:
            channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)

        if self.root_motion and channelbag and not self.root_motion in channelbag.groups:
            self.root_motion = ""
        if self.follow and channelbag and not self.follow in channelbag.groups:
            self.follow = ""
        if self.root_motion_a and not self.root_motion_a in ob.pose.bones:
            self.root_motion_a = ""
       
        return self.execute(context)

    def execute(self, context):

        bake_up = list(context.selected_objects)

        self.number_trg.clear()

        actif =  context.active_object

        armatures = ops.get_selected_obs(context)

        current_m = context.mode

        #similar action
        if self.action_clean_all:
            if len(self.action_collection) > 0 :
                self.action_collection.clear()
            self.action_clean_all = False

        if self.action_clean_last:
            if len(self.action_collection) > 0 :
                self.action_collection.pop()
            self.action_clean_last = False

        if self.action_l != "":
            if not self.action_l in self.action_collection:
                self.action_collection.append(self.action_l)
            self.action_l = ""

        #// update value ik bones
        if self.adjust_animation:

            if self.clean_all:
                if len(self.motion_collection) > 0 :
                    self.motion_collection.clear()
                self.clean_all = False

            if self.clean_last:
                if len(self.motion_collection) > 0 :
                    self.motion_collection.pop()
                self.clean_last = False

            if self.motion_bones:
                if not self.motion_bones in self.motion_collection:
                    self.motion_collection.append(self.motion_bones)
                self.motion_bones = ""

        for ob in armatures:

            actions = []

            if self.bake_similar:
                for action in bpy.data.actions:
                    if self.only_similar and not validate_actions(action, ob.path_resolve):
                        continue
                    if not self.correct_action(action, context):
                        continue
                    actions.append(action)
                #update ui
                self.number_trg[ob.name] = actions.copy()

            else:
                if ob.animation_data and ob.animation_data.action:
                     actions.append(ob.animation_data.action)

            if self.bake_similar and not self.apply_All:
                actions.clear()
                if ob.animation_data and ob.animation_data.action:
                    actions.append(ob.animation_data.action)

            if not ob.animation_data:
                continue
            if not ob.animation_data.action:
                continue

            context.view_layer.objects.active = ob

            if self.empty_f:
                
                if not self.all_slots and not self.bake_similar:
                    slot = ob.animation_data.action_slot
                    action = ob.animation_data.action
                    channelbag = anim_utils.action_get_channelbag_for_slot(action,slot)
                    if channelbag:
                        del_fc = []
                        for fcurve in channelbag.fcurves:
                            if not fcurve.keyframe_points:
                                del_fc.append(fcurve)

                        for fcurve in reversed(del_fc):
                            channelbag.fcurves.remove(fcurve)

                else:
                    for action in actions:
                        for slot in action.slots:
                            channelbag = anim_utils.action_get_channelbag_for_slot(action,slot)
                            if channelbag:
                                del_fc = []
                                for fcurve in channelbag.fcurves:
                                    if not fcurve.keyframe_points:
                                        del_fc.append(fcurve)

                                for fcurve in reversed(del_fc):
                                    channelbag.fcurves.remove(fcurve)

            #IN PLACE
            if self.in_place and self.root_motion:

                for action in actions:
                
                    for slot in action.slots:

                        if slot.target_id_type != 'OBJECT':
                            continue

                        #slot
                        if not self.all_slots and not self.bake_similar:
                            if not ob in slot.users():
                                continue

                        channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)

                        if channelbag and self.root_motion in channelbag.groups:
                            group = channelbag.groups[self.root_motion]

                            del_fc = []
                            axis_names = ["X", "Y", "Z"]
                            quat_names = ["W", "X", "Y", "Z"] # For quaternion rotations
                            
                            for fcurve in group.channels:
                                data_path = fcurve.data_path

                                if ob.type == 'ARMATURE' and self.root_motion in ob.pose.bones and not self.root_motion in data_path:
                                    continue

                                if 'location' in data_path:

                                    if axis_names[fcurve.array_index] =="X" and not self.position_x:
                                        continue

                                    if axis_names[fcurve.array_index] =="Y" and not self.position_y:
                                        continue

                                    if axis_names[fcurve.array_index] =="Z" and not self.position_z:
                                        continue

                                if 'rotation' in data_path:

                                    if data_path.endswith('rotation_quaternion') or data_path.endswith('rotation_axis_angle'):

                                        if quat_names[fcurve.array_index] =="W" and (not self.rotation_x or not self.rotation_y or not self.rotation_z):
                                            continue

                                        if quat_names[fcurve.array_index] =="X" and not self.rotation_x:
                                            continue

                                        if quat_names[fcurve.array_index] =="Y" and not self.rotation_y:
                                            continue

                                        if quat_names[fcurve.array_index] =="Z" and not self.rotation_z:
                                            continue
                                    else:
                                        if axis_names[fcurve.array_index] =="X" and not self.rotation_x:
                                            continue

                                        if axis_names[fcurve.array_index] =="Y" and not self.rotation_y:
                                            continue

                                        if axis_names[fcurve.array_index] =="Z" and not self.rotation_z:
                                            continue

                                if 'scale' in data_path and not self.scale_freeze:
                                    continue

                                del_fc.append(fcurve)

                            for fc in reversed(del_fc):
                                channelbag.fcurves.remove(fc)

                            if ob.type == 'ARMATURE' and self.root_motion in ob.pose.bones:
                                bone = ob.pose.bones[self.root_motion]
                            else:
                                bone = ob

                            bone.location[0] = 0
                            bone.location[1] = 0
                            bone.location[2] = 0

            #ajust_animation
            if self.apply and ob.type == 'ARMATURE' and self.adjust_animation:

                #test if its local
                if ob.library is not None or ob.data.library is not None:
                    continue

                #Duplique object
               
                action = ob.animation_data.action
                slot = ob.animation_data.action_slot
                ob.animation_data.action = None

                new_ob = ob.copy()
                new_ob.data = ob.data.copy()
                new_ob.name = ob.name + "_TEMP"

                context.collection.objects.link(new_ob)

                new_ob.animation_data.action = action
                new_ob.animation_data.action_slot = slot

                #select
                new_ob.select_set(True, view_layer = context.view_layer)

                #retargeting -----
                bpy.ops.object.mode_set(mode='POSE')
                bone_names_map = []

                channelbag = None
                channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)

                for bone in new_ob.pose.bones:

                    if bone_utils.is_pose_bone_all_locked(bone):
                        continue
                    
                    if self.only_animated_Bone and channelbag and bone.name in channelbag.groups:
                        bone_names_map.append(bone.name)

                    elif not self.only_animated_Bone:
                        bone_names_map.append(bone.name)
               
                try:
                    ret_collection = new_ob.data.collections[self.ret_bones_collection]
                except KeyError:
                    ret_collection = new_ob.data.collections.new(self.ret_bones_collection)
                    ret_collection.is_visible = False

                # create Retarget bones collection
                prefix = ""

                bpy.ops.object.mode_set(mode='EDIT')
                
                for name in bone_names_map:
                    trg_name = str(prefix) + str(name)
                    new_bone_name = bone_utils.copy_bone_to_arm(ob, new_ob, name, suffix=bone_utils.cp_suffix)

                    if not new_bone_name:
                        continue
                    try:
                        new_parent = new_ob.data.edit_bones[trg_name]
                    except KeyError:
                        self.report({'WARNING'}, f"{trg_name} not found in target")
                        continue

                    new_bone = new_ob.data.edit_bones[new_bone_name]
                    new_bone.parent = new_parent
                    new_bone.roll = new_ob.data.edit_bones[trg_name].roll
                    #unassign the new bone to all collection
                    for coll in new_bone.collections:
                        coll.unassign(new_bone)
                    ret_collection.assign(new_bone)

                #-----
                bpy.ops.object.mode_set(mode='POSE')

                #add constrain / shape
                #find hips bone
                hip_bone = None
                for bone in ob.pose.bones:
                    hip_bone = bone
                    break

                for name in bone_names_map:

                    try:
                        src_pbone = ob.pose.bones[name]

                    except KeyError:
                        continue

                    constr_types = []


                    if name == self.root_motion_a or (name in self.motion_collection) or (self.bind_floating and hip_bone and is_bone_floating(src_pbone, hip_bone.name, new_ob)):
                        constr_types.append('COPY_LOCATION')

                    constr_types.append('COPY_ROTATION')
                    constr_types.append('COPY_SCALE')

                    subtarget_name = f'{name}{bone_utils.cp_suffix}'

                    if subtarget_name in new_ob.data.bones:

                        for constr_type in constr_types:
                            constr = src_pbone.constraints.new(type=constr_type)
                            constr.target = new_ob

                            constr.subtarget = subtarget_name
                            constr.name = f'{constr.name}{bone_utils.cp_suffix}'

                        #//shape
                        new_ob_bone = new_ob.pose.bones[subtarget_name]
                        new_ob_bone.custom_shape = src_pbone.custom_shape
                        new_ob_bone.custom_shape_transform = src_pbone.custom_shape_transform
                        new_ob_bone.custom_shape_rotation_euler = src_pbone.custom_shape_rotation_euler
                        new_ob_bone.custom_shape_scale_xyz = src_pbone.custom_shape_scale_xyz
                        new_ob_bone.custom_shape_translation = src_pbone.custom_shape_translation
                        new_ob_bone.custom_shape_wire_width = src_pbone.custom_shape_wire_width
                        new_ob_bone.color.palette = src_pbone.color.palette
                        new_ob_bone.color.custom.normal = src_pbone.color.custom.normal
                        new_ob_bone.color.custom.select = src_pbone.color.custom.select
                        new_ob_bone.color.custom.active = src_pbone.color.custom.active

                #root transform

                _constrained_root = ob.pose.bones[self.root_motion_a] if self.root_motion_a else None
                if self.root_motion_a and _constrained_root:
                    #position
                    constr = None
                    loc_constr = None
                    offset_constr = None
                    subtarget = ""
                    for cons in _constrained_root.constraints:
                        if cons.type == 'LIMIT_LOCATION':
                            constr = cons
                            if not bone_utils.cp_suffix in constr.name:
                                constr.name = f'{constr.name}{bone_utils.cp_suffix}'
                        
                        if cons.type == 'FLOOR' and cons.target and cons.target == trg_ob:
                            offset_constr = cons
                            offset_constr.target = new_ob
                            offset_constr.subtarget = self.root_motion_a
                            if not bone_utils.cp_suffix in offset_constr.name:
                                offset_constr.name = f'{offset_constr.name}{bone_utils.cp_suffix}'

                        if cons.type == 'COPY_LOCATION':
                            loc_constr = cons
                            subtarget = loc_constr.subtarget
                            loc_constr.target = new_ob
                            loc_constr.subtarget = self.root_motion_a
                            if not bone_utils.cp_suffix in loc_constr.name:
                                loc_constr.name = f'{loc_constr.name}{bone_utils.cp_suffix}'

                    #create a contraint if not found
                    if not loc_constr:
                        loc_constr = _constrained_root.constraints.new('COPY_LOCATION')
                        loc_constr.target = new_ob
                        loc_constr.subtarget = self.root_motion_a
                        loc_constr.name = f'{loc_constr.name}{bone_utils.cp_suffix}'

                    loc_constr.use_x = self.root_cp_loc_x
                    loc_constr.use_y = self.root_cp_loc_y
                    loc_constr.use_z = self.root_cp_loc_z

                    if self.keep_offset and self.root_cp_loc_z:
                        if not offset_constr:
                            offset_constr = _constrained_root.constraints.new('FLOOR')

                        offset_constr.target = new_ob
                        offset_constr.subtarget = self.root_motion_a
                        if self.keep_offset_value < 0:
                            offset_constr.floor_location = 'FLOOR_NEGATIVE_Z'
                        else:
                            offset_constr.floor_location = 'FLOOR_Z'

                        offset_constr.offset = self.keep_offset_value
                        offset_constr.name = f'{offset_constr.name}{bone_utils.cp_suffix}'

                    if not constr:
                        constr = _constrained_root.constraints.new('LIMIT_LOCATION')
                        constr.name = f'{constr.name}{bone_utils.cp_suffix}'

                    constr.use_min_x = self.root_use_loc_min_x or not self.root_cp_loc_x
                    constr.use_min_y = self.root_use_loc_min_y or not self.root_cp_loc_y
                    constr.use_min_z = self.root_use_loc_min_z or not self.root_cp_loc_z

                    constr.use_max_x = self.root_use_loc_max_x or not self.root_cp_loc_x
                    constr.use_max_y = self.root_use_loc_max_y or not self.root_cp_loc_y
                    constr.use_max_z = self.root_use_loc_max_z or not self.root_cp_loc_z

                    constr.min_x = self.root_loc_min_x if self.root_cp_loc_x and self.root_use_loc_min_x else 0.0
                    constr.min_y = self.root_loc_min_y if self.root_cp_loc_y and self.root_use_loc_min_y else 0.0
                    constr.min_z = self.root_loc_min_z if self.root_cp_loc_z and self.root_use_loc_min_z else 0.0

                    constr.max_x = self.root_loc_max_x if self.root_cp_loc_x and self.root_use_loc_max_x else 0.0
                    constr.max_y = self.root_loc_max_y if self.root_cp_loc_y and self.root_use_loc_max_y else 0.0
                    constr.max_z = self.root_loc_max_z if self.root_cp_loc_z and self.root_use_loc_max_z else 0.0

                    #rotation
                    constr = None
                    for cons in _constrained_root.constraints:
                        if cons.type == 'COPY_ROTATION':
                            constr = cons
                            subtarget = constr.subtarget
                            constr.target = new_ob
                            constr.subtarget = self.root_motion_a
                            if not bone_utils.cp_suffix in constr.name:
                                constr.name = f'{constr.name}{bone_utils.cp_suffix}'
                            break
                    if not constr:
                        constr = _constrained_root.constraints.new('COPY_ROTATION')
                        constr.target = new_ob
                        constr.subtarget = self.root_motion_a
                        constr.name = f'{constr.name}{bone_utils.cp_suffix}'

                    constr.use_x = self.root_cp_rot_x
                    constr.use_y = self.root_cp_rot_y
                    constr.use_z = self.root_cp_rot_z

                    #Scale
                    constr = None
                    for cons in _constrained_root.constraints:
                        if cons.type == 'COPY_SCALE':
                            constr = cons
                            constr.target = new_ob
                            constr.subtarget = self.root_motion_a
                            if not bone_utils.cp_suffix in constr.name:
                                constr.name = f'{constr.name}{bone_utils.cp_suffix}'
                            break
                    if not constr:
                        constr = _constrained_root.constraints.new('COPY_SCALE')
                        constr.target = new_ob
                        if subtarget:
                            constr.subtarget = subtarget
                        else:
                            constr.subtarget = self.root_motion_a
                        constr.name = f'{constr.name}{bone_utils.cp_suffix}'

                    constr.use_x = self.root_cp_scal_x
                    constr.use_y = self.root_cp_scal_y
                    constr.use_z = self.root_cp_scal_z

                #Show retarget bone
                for bone in new_ob.pose.bones:
                    if not ret_collection.name in bone.bone.collections:
                        bone.hide = True
                ret_collection.is_visible = True

                ob = new_ob
                bpy.ops.object.mode_set(mode='POSE')

            #repeat
            self.repeat = abs(self.repeat)
            if self.repeat != 1:

                for action in actions:

                    #int current frame

                    frame_start, frame_end = action.frame_range

                    if self.custom_start_end:
                        if self.start < self.end and self.start >= frame_start and frame_end >= self.end:
                            frame_start, frame_end = self.start, self.end

                    lenght = int(abs(abs(frame_start) - abs(frame_end)))

                    # %1 partie decimal
                    new_leght = lenght * floor(self.repeat) + lenght * (self.repeat % 1)

                    n_repeat = ceil(new_leght / lenght)

                    axis_names = ["X", "Y", "Z"]

                    for slot in action.slots:

                        if not self.all_slots and not self.bake_similar:
                            if not ob in slot.users():
                                continue

                        channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)

                        repeat = 1
                        #offset = 1

                        while repeat <= n_repeat:

                            for fc in channelbag.fcurves:

                                    prev_kp = 0
                                    prev_kp1 = 0
                                    #curent_legth = lenght * repeat
                                    curent_legth = 0
                                    curent_legth1 = 0



                                    key_x = []
                                    key_y = []

                                    Start = True

                                    for kp in fc.keyframe_points:

                                        # if not prev_kp:
                                        #     curent_legth += offset

                                        # elif (kp.co[0] - frame_start) % lenght == 0:
                                        #     curent_legth += offset

                                        # else:
                                        #     kp_dif = kp.co[0] - prev_kp
                                        #     curent_legth += kp_dif

                                        #key_x.append(curent_legth)

                                        if self.custom_start_end:
                                            if kp.co[0] < frame_start or kp.co[0] > frame_end:
                                                if prev_kp == 0:
                                                    prev_kp = kp.co[0] + fc.keyframe_points[-1].co[0]

                                                if prev_kp1 == 0:
                                                    prev_kp1 = kp.co[1] + fc.keyframe_points[-1].co[1]
                                                continue

                                        if self.custom_start_end and Start:
                                            curent_legth = prev_kp

                                        elif prev_kp == 0:
                                            curent_legth = kp.co[0] + fc.keyframe_points[-1].co[0]
                                        else:
                                            curent_legth += kp.co[0] - prev_kp

                                        if curent_legth > new_leght:
                                            break

                                        if self.custom_start_end:
                                            key_x.append(curent_legth)
                                        else:
                                            key_x.append(kp.co[0] + fc.keyframe_points[-1].co[0])

                                        if self.follow and fc.group and self.follow == fc.group.name and fc.data_path.endswith('location'):

                                            if  self.custom_start_end:
                                                if Start:
                                                    curent_legth1 = prev_kp1
                                                else:
                                                    curent_legth1 += (kp.co[1] - prev_kp1)
                                                
                                                key_y.append(curent_legth1)
                                            else:
                                                key_y.append(kp.co[1] + fc.keyframe_points[-1].co[1])

                                        else:
                                            key_y.append(kp.co[1])

                                        Start = False
                                        prev_kp1 = kp.co[1]
                                        prev_kp = kp.co[0]

                                    #add keyframe point
                                    i = 0
                                    while i < len(key_x):
                                        fc.keyframe_points.insert(key_x[i], key_y[i])
                                        i += 1

                                    fc.keyframe_points.deduplicate()

                                    fc.update()

                            repeat += 1
            #speed
            if self.speed == 0:
                self.speed = 1
            if self.speed != 1:
                    
                for action in actions:

                    #int current frame

                    frame_start, frame_end = action.frame_range

                    lenght = abs(frame_start) - abs(frame_end)

                    for slot in action.slots:

                        if not self.all_slots and not self.bake_similar:
                            if not ob in slot.users():
                                continue

                        channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)

                        if channelbag:
                            if self.speed >= 0:

                                for fc in channelbag.fcurves:
                                    for keyframe_point in fc.keyframe_points:
                                        new_time = frame_start + (keyframe_point.co[0] - frame_start) * self.speed
                                        keyframe_point.co[0] = new_time
                                    fc.keyframe_points.deduplicate()
                                    fc.update()

                            else:
                                for fc in channelbag.fcurves:
                                    for kp in fc.keyframe_points:
                                        kp.co.x = frame_start + (kp.co.x - frame_start) * self.speed

                                    # Ensure the f-curve handles are updated after keyframe modification
                                    fc.update()

                                #translation
                                pivot_frame = abs(int(lenght * self.speed))
                                for fc in channelbag.fcurves:
                                    for kp in fc.keyframe_points:
                                        kp.co.x += pivot_frame
                                        if kp.handle_left_type != 'FREE': # Only adjust if not auto/vector
                                            kp.handle_left.x += pivot_frame
                                        if kp.handle_right_type != 'FREE':
                                            kp.handle_right.x += pivot_frame
                                    fc.keyframe_points.deduplicate()
                                    fc.update()

            #action range
            if self.action_range:
                context.view_layer.objects.active = ob
                bpy.ops.object.retarget_action_to_range()

        ob = ops.get_ob_or_armature(context, context.active_object)
        if ob.library is None:
            bpy.ops.object.mode_set(mode= current_m)
        if self.play and not context.screen.is_animation_playing:
            bpy.ops.screen.animation_play()
        for o in bake_up:
            o.select_set(True, view_layer = context.view_layer)
        context.view_layer.objects.active = actif
        return {'FINISHED'}

class ConvertBoneNaming(Operator):
    """Convert Bone Names between Naming Convention"""
    bl_idname = "object.retarget_convert_bone_names"
    bl_label = "Rename Bones"
    bl_options = {'REGISTER', 'UNDO'}

    src_preset: EnumProperty(items=preset_handler.iterate_presets_with_current,
                             name="Source",
                             description="Source Preset",
                             )

    trg_preset: EnumProperty(items=preset_handler.iterate_presets,
                             name="Target",
                             description="Target Preset",
                             )
    
    prefix_separator: StringProperty(
        name="Prefix ",
        description="Prefix of the bone name , i.e: MyCharacter:head",
        default=""
    )

    replace_existing: BoolProperty(
        name="Take Over Existing Names",
        description='Bones already named after Target Preset will get ".1" suffix',
        default=True
    )

    #similar

    show_10: BoolProperty(name="",
                          description="Show Those Action",
                                default=True)
    
    show_all: BoolProperty(name="",
                           description="SHow All Action",
                                default=False, options={'SKIP_SAVE'})

    bake_similar:BoolProperty(name="Include Similar Action",
                              description="convert other action",
                                default=False)
    #-----
    only_selected_action: BoolProperty(name="Only Selected Action(s)",
                                description= "Only selected Action(s) in Action Manager",
                                default=False)
    
    by_name: BoolProperty(name="by Name",
                            description= "Only Look for Action with this Prefix/Suffix",
                            default=False)
    
    include: EnumProperty(items=[
        ('include', "Include", "Include Action with this Prefix/Suffix"),
        ('exclude', "Exclude", "Exclude Action with this Prefix/Suffix")
         ],
        name="",
        default='include')
    
    prefix: StringProperty(name="prefix",
                                description= "Prefix (comma is the separator)",
                                default="")
    
    contain: StringProperty(name="Contain",
                                  description= "Contain (comma is the separator)",
                                 default="")
    
    suffix: StringProperty(name="suffix",
                                 description= "Suffix (comma is the separator)",
                                default="")
    
    #list 

    action_select: BoolProperty(name="Action",
                               description= "Select between Actions",
                               default=False)
    
    include_a: EnumProperty(items=[
        ('include', "Include", "Include Actions"),
        ('exclude', "Exclude", "Exclude Actions")
         ],
        name="",
        default='include')
    
    action_l: StringProperty(name = "",
                              description=" Actions List",
                              default="", options = {'SKIP_SAVE'})

    clean_all:  BoolProperty(name="",
                              description="Delete All",
                             default=False, options = {'SKIP_SAVE'})

    clean_last:  BoolProperty(name="",
                              description="Delete the last one",
                              default=False, options = {'SKIP_SAVE'})

    action_collection = []

    number_trg = dict()

    def draw(self, context):
        layout = self.layout
        column = layout.column()

        o = ops.get_ob_or_armature(context, context.active_object)
        #test if its local
        if o.library is not None or o.data.library is not None:
            column.label(text=f"make '{o.name}' local", icon='ERROR')
            column.separator()

        if self.bake_similar and self.number_trg:

            for ob_name, action_valid in self.number_trg.items():
                column.label(text=f"Rename {len(action_valid)} Actions of {ob_name}")

                show_10 = 10

                if self.show_10 and not self.show_all and action_valid:

                    i = 1
                    for action in action_valid:
                        if i > show_10:
                            break
                        column.label(text=f"- {action.name} ")
                        i += 1

                if self.show_all and action_valid:

                    for action in action_valid:
                        column.label(text=f"- {action.name} ")

                if (not self.show_all and len(action_valid) >= 1) or (self.show_10 and len(action_valid) > show_10):
                    
                    row = column.split(factor=0.80, align=True)
                    row.label(text="")

                    if not self.show_all and len(action_valid) >= 1 :
                        row.prop(self, "show_10", toggle=True, icon='DOWNARROW_HLT')

                    if self.show_10 and len(action_valid) > show_10 :
                        row.prop(self, "show_all", toggle=True, icon='DOWNARROW_HLT')
            column.separator()
        else:
            #show number
            armatures = ops.get_selected_obs(context)
            num = 0
            for armature in armatures:

                if armature.type != 'ARMATURE':
                    continue
                num += 1
            if num > 1:
                column.label(text=f"{num} Armatures Selected")
                column.separator()


        row = column.row()
        row.prop(self, "src_preset")

        row = column.row()
        row.prop(self, "trg_preset")

        row = column.row()
        row.prop(self, "prefix_separator")

        row = column.row()
        row.prop(self, "replace_existing")

        column.separator()
        row = column.row()
        tex = "-- Actions/Slots Influence --".center(50)
        row.label(text=tex, icon='ACTION')

        row = column.row()
        row.prop(self, "bake_similar")

        if self.bake_similar:

            row = column.row()
            row.prop(self, "only_selected_action")

            row = column.row()
            row.prop(self, "by_name")

            if self.by_name:
                subcol = row.column()
                subcol.prop(self, 'include')

                row = column.row()
                col = row.column()
                col.label(text="Prefix")
                col.prop(self, 'prefix', text="")

                col = row.column()
                col.label(text="Contain:")
                col.prop(self, 'contain', text="")

                col = row.column()
                col.label(text="Suffix:")
                col.prop(self, 'suffix', text="")

            row = column.row()
            row.prop(self, "action_select")

            if self.action_select:

                subcol = row.column()
                subcol.prop(self, 'include_a')

                row = column.split(factor=0.80, align=True)
                row.prop_search(self, 'action_l',
                            bpy.data,
                            "actions")
                
                row.prop(self, 'action_l')
                row.prop(self, 'clean_all', toggle=True, icon='PANEL_CLOSE')
                row.prop(self, 'clean_last',toggle=True, icon='TRACKING_CLEAR_BACKWARDS')

                i = 0
                row = column.split(factor=0.33, align=True)

                for act in self.action_collection:
                    if i == 3:
                        row = column.split(factor=0.33, align=True)
                        i = 0

                    row.label(text=act, icon='ACTION')

                    i += 1

    def correct_action(self, action, context):

        if not self.bake_similar:
            return True
        
        if self.only_selected_action:
            selected_act = selected_action(context)
            if not action in selected_act:
                return False

        incl = -1
        incls = -1
        inclc = -1

        
        if self.by_name:
            if self.include == 'include':
                if self.prefix:
                    list_ = self.prefix.split(",")
                    incl = 0
                    for li in list_:
                        if li and not action.name.startswith(li):
                            incl -= 1
                        if li and action.name.startswith(li):
                            incl += 1
                    if incl < 0:
                        return self.test_list_action(action)

                if self.suffix:
                    list_ = self.suffix.split(",")
                    incls = 0
                    for li in list_:
                        if li and not action.name.endswith(li):
                            incls -= 1
                        if li and action.name.endswith(li):
                            incls += 1
                    if incls < 0:
                        return self.test_list_action(action)
                    
                if self.contain:
                    list_ = self.contain.split(",")
                    inclc = 0
                    for li in list_:
                        if li and not li in action.name:
                            inclc -= 1
                        if li and li in action.name:
                            inclc += 1
                    if inclc < 0:
                        return self.test_list_action(action)
            
            else:
                if self.prefix:
                    list_ = self.prefix.split(",")
                    for li in list_:
                        if li and action.name.startswith(li):
                            return False

                if self.suffix:
                    list_ = self.suffix.split(",")
                    for li in list_:
                        if li and action.name.endswith(li):
                            return False

                if self.contain:
                    list_ = self.contain.split(",")
                    for li in list_:
                        if li and li in action.name:
                            return False
        
        if self.action_select:

            if self.include_a == 'include':

                if self.action_collection and action.name not in self.action_collection:
                    return False or (incl >= 0 or incls >= 0 or inclc >= 0)
            
            elif self.action_collection and action.name in self.action_collection:
                return False
        
        return True
    
    def test_list_action(self, action):
        if self.action_select:
            if self.include_a == 'include':

                if self.action_collection and action.name in self.action_collection:
                    return True
        return False

    @classmethod
    def poll(cls, context):
        ob = ops.get_ob_or_armature(context, context.active_object)
        if not ob:
            return False
        if ob.type != 'ARMATURE':
            return False

        return True

    @staticmethod
    def convert_presets(src_settings, target_settings):
        src_skeleton = preset_handler.get_preset_skel(src_settings)
        trg_skeleton = preset_handler.get_preset_skel(target_settings)

        return src_skeleton, trg_skeleton

    @staticmethod
    def convert_settings(current_settings, target_settings, context, validate=True):
        src_settings = preset_handler.PresetSkeleton()
        src_settings.copy(current_settings)

        src_skeleton = preset_handler.get_settings_skel(src_settings)
        trg_skeleton = preset_handler.set_preset_skel(target_settings, context, validate)

        return src_skeleton, trg_skeleton

    @staticmethod
    def rename_bones(obj, src_skeleton, trg_skeleton, separator="", replace_existing = True, skip_ik=False):

        bone_names_map = src_skeleton.conversion_map(trg_skeleton, skip_ik=skip_ik)

        bone_map = dict()
        
        for src_name, trg_name in bone_names_map.items():

            if not trg_name:
                continue
            if not src_name:
                continue

            if not src_name in obj.data.bones:
                src_name = preset_handler.findBone(src_name, obj.data.bones)

            if not src_name:
                continue
            try:
                src_bone = obj.data.bones.get(src_name, None)
            except SystemError:
                continue

            if not src_bone:
                continue

            if not separator:
                trg_wp = trg_name.split(":")[-1]
                bone_name = trg_wp

            elif(separator != ":"):
                trg_wp = trg_name.split(":")[-1]
                bone_name = separator + ":" + trg_wp
            else:
                bone_name = trg_name
                
            if replace_existing:
                name_f = bone_name
                if name_f in obj.data.bones:
                    i = 1
                    name =  name_f + "."+ str(i)
                    while True:
                        find = False
                        name =  name_f + "."+ str(i)
                        if name in obj.data.bones:
                            i += 1
                            find = True
                        if not find:
                            break
                    bone = obj.data.bones[name_f]
                    bone.name = name
                
            src_bone.name = bone_name

            #update the map
            bone_map[src_name] = src_bone.name

        return bone_map
    
    def invoke(self, context, event):

        o = ops.get_ob_or_armature(context, context.active_object)

        if o.data.retarget_retarget.has_settings():
            self.src_preset = '--Current--'

        else:
            self.src_preset = preset_handler.findPreset(o)
        
        return self.execute(context)

    def execute(self, context):
        self.number_trg.clear()

        bake_up = list(context.selected_objects)

        actif =  context.active_object
        current_m = context.mode

        #ini animation value

        #similar action
        if self.clean_all:
            if len(self.action_collection) > 0 :
                self.action_collection.clear()
            self.clean_all = False

        if self.clean_last:
            if len(self.action_collection) > 0 :
                self.action_collection.pop()
            self.clean_last = False

        if self.action_l != "":
            if not self.action_l in self.action_collection:
                self.action_collection.append(self.action_l)
            self.action_l = ""

        o = ops.get_ob_or_armature(context, context.active_object)
        if o.library is not None or o.data.library is not None:
            return {'FINISHED'}

        armatures = ops.get_selected_obs(context)
        for armature in armatures:

            if armature.type != 'ARMATURE':
                continue

            if armature.library is not None or armature.data.library is not None:
                continue

            context.view_layer.objects.active = armature

            bpy.ops.object.mode_set(mode='POSE')

            actions = []

            if self.bake_similar:
                actions = [action for action in bpy.data.actions if action and validate_actions(action, armature.path_resolve) and self.correct_action(action, context)]
                self.number_trg[armature.name] = actions

            #I remove this because blender rename the current slot by default
            # else:
            #     if armature.animation_data and armature.animation_data.action:
            #         actions.append(armature.animation_data.action)

            if self.src_preset == "--Current--":
                current_settings = armature.data.retarget_retarget
               
                src_skeleton, trg_skeleton = self.convert_settings(current_settings, self.trg_preset, context, validate=False)

                set_preset = False
            else:
                src_skeleton, trg_skeleton = self.convert_presets(self.src_preset, self.trg_preset)

                set_preset = True

            if all((src_skeleton, trg_skeleton, src_skeleton != trg_skeleton)):
                
                bone_names_map = self.rename_bones(armature, src_skeleton, trg_skeleton,
                                                self.prefix_separator, replace_existing = self.replace_existing)
                
                if armature.animation_data and armature.data.animation_data:
                    for driver in chain(armature.animation_data.drivers, armature.data.animation_data.drivers):
                        try:
                            driver_bone = driver.data_path.split('"')[1]
                        except IndexError:
                            continue

                        try:
                            trg_name = bone_names_map[driver_bone]
                        except KeyError:
                            continue

                        driver.data_path = driver.data_path.replace('bones["{0}"'.format(driver_bone),
                                                                    'bones["{0}"'.format(trg_name))

                for action in actions:

                    if not action:
                        continue

                    for slot in action.slots:

                        if slot.target_id_type != 'OBJECT':
                            continue

                        channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)

                        for group in channelbag.groups:
                            try:
                                # Update group data paths
                                gr_name = group.name
                                
                                new_name = bone_names_map[group.name]
                                group.name = new_name

                                # Update F-Curve data paths
                                for fcurve in group.channels:
                                    fcurve.data_path = fcurve.data_path.replace(gr_name, new_name)
                            except KeyError:
                                pass

                if set_preset:
                    preset_handler.set_preset_skel(self.trg_preset, context)
                else:
                    preset_handler.validate_preset(armature.data, separator=":")

        bpy.ops.object.mode_set(mode= current_m)
        for o in bake_up:
            o.select_set(True, view_layer = context.view_layer)
        context.view_layer.objects.active = actif
        return {'FINISHED'}

class ApplyAsRestPose(Operator):
    """Apply the pose as a rest pose and align the mesh to this new rest pose"""
    bl_idname = "object.retarget_apply_as_rest_pose"
    bl_label = "Apply As Rest Pose"
    bl_options = {'REGISTER', 'UNDO'}

    only_selected: BoolProperty(name="Only Selected Bone",
                               description="Apply the pose as a rest pose only on selected bone",
                               default=False)
    apply_shape_key: BoolProperty(name="Apply All Shape Keys",
                                   description="The shape keys will prevent this operation",
                                  default=False)

    apply: BoolProperty(name="Apply", default=True)

    @classmethod
    def poll(cls, context):
        ob = ops.get_ob_or_armature(context, context.active_object)
        if not ob:
            return False
        if ob.type != 'ARMATURE':
            return False
        return True

    def draw(self, context):
        layout = self.layout
        column = layout.column()

        o = ops.get_ob_or_armature(context, context.active_object)

        #test if its local
        if o.library is not None or o.data.library is not None:
            column.label(text=f"make '{o.name}' local", icon='ERROR')
            column.separator()

        #show number
        armatures = ops.get_selected_obs(context)
        num = 0
        for armature in armatures:

            if armature.type != 'ARMATURE':
                continue
            num += 1
        if num > 1:
            row = column.split(factor=0.05, align=True)
            row.label(text="")
            row.label(text=f"{num} Armatures Selected")
            column.separator()


        for ob in ops.get_selected_obs(context):
            if ob.animation_data and ob.animation_data.action:
                row = column.row()
                t = "--It will break the Action--".center(50)
                row.label(text= t, icon='ERROR')
                break

        row = column.split(factor=0.05, align=True)
        row.label(text="")
        row.prop(self, "only_selected")

        row = column.split(factor=0.05, align=True)
        row.label(text="")
        row.prop(self, "apply_shape_key")

        row = column.split(factor=0.05, align=True)
        row.label(text="")
        row.prop(self, "apply", toggle=True)

    def execute(self, context):

        bake_up = list(context.selected_objects)

        if not self.apply:
            return {'FINISHED'}
        
        #test if its local
        o = ops.get_ob_or_armature(context, context.active_object)

        if o.library is not None or o.data.library is not None:
            return {'FINISHED'}

        actif =  context.active_object
        current_m = context.mode

        armatures = ops.get_selected_obs(context)
        for ob in armatures:

            if ob.type != 'ARMATURE':
                continue

            #test if its local
            if ob.library is not None or ob.data.library is not None:
                continue

            context.view_layer.objects.active = ob
            bpy.ops.object.mode_set(mode='POSE')

            exit = False
            #can't apply the armature with sape key
            for mesh in ob.children_recursive:
                if not mesh or not mesh.data:
                    continue
                if getattr(mesh.data, "shape_keys", None) and len(mesh.data.shape_keys.key_blocks) > 1:
                    if self.apply_shape_key:
                        bpy.ops.object.mode_set(mode='OBJECT')
                        mesh.select_set(True)
                        context.view_layer.objects.active = mesh
                        # select shape key
                        mesh.active_shape_key_index = 0
                        bpy.ops.object.shape_key_remove(all=True, apply_mix=True)
                        mesh.select_set(False)
                        context.view_layer.objects.active = ob
                        bpy.ops.object.mode_set(mode='POSE')
                    else:
                        self.report({'WARNING'}, f"Apply the shape key in {mesh.name} or select 'Apply All Shape Keys'")
                        exit = True


            if exit:
                continue

            #duplic mod and apply
            if self.only_selected:
                for bone in ob.pose.bones:
                    if bone.select == True:
                        continue
                    bone.matrix_basis = Matrix()

            for mesh in ob.children_recursive:

                for mod in mesh.modifiers:
                    if mod.type == 'ARMATURE' and mod.object == ob:
                        new_modifier_name = mod.name + "_copy"
                        new_mod = mesh.modifiers.new(name=new_modifier_name, type=mod.type)
                        bone_utils.copy_modifier_properties(mod, new_mod)
                        with context.temp_override(object=mesh):
                            try:
                                bpy.ops.object.modifier_apply( modifier=new_mod.name)
                            except RuntimeError:
                                self.report({'WARNING'}, f"Error applying {new_modifier_name} to {mesh.name}")

                        break

            bpy.ops.pose.armature_apply(selected= self.only_selected)

        bpy.ops.object.mode_set(mode=current_m)
        for o in bake_up:
            o.select_set(True, view_layer = context.view_layer)
        context.view_layer.objects.active = actif
        return {'FINISHED'}


class ApplyRotation(Operator):
    """Apply Rotation (This also the delete keyframe of the rotation of the object)"""
    bl_idname = "object.retarget_apply_rotation"
    bl_label = "Apply Rotation"
    bl_options = {'REGISTER', 'UNDO'}

    #similar

    show_10: BoolProperty(name="",
                          description="Show Those Action",
                                default=True)
    
    show_all: BoolProperty(name="",
                           description="SHow All Action",
                                default=False, options={'SKIP_SAVE'})

    bake_similar:BoolProperty(name="Include Others Actions",
                              description="convert other action",
                                default=False)
    
    apply_All:BoolProperty(name="Apply", options={'SKIP_SAVE'},
                              description="Apply in Actions (can take some time)",
                                default=False)
    #-----
    only_selected_action: BoolProperty(name="Only Selected Action(s)",
                                description= "Only selected Action(s) in Action Manager",
                                default=False)
    
    by_name: BoolProperty(name="by Name",
                            description= "Only Look for Action with this Prefix/Suffix",
                            default=False)
    
    include: EnumProperty(items=[
        ('include', "Include", "Include Action with this Prefix/Suffix"),
        ('exclude', "Exclude", "Exclude Action with this Prefix/Suffix")
         ],
        name="",
        default='include')
    
    prefix: StringProperty(name="prefix",
                                description= "Prefix (comma is the separator)",
                                default="")
    
    contain: StringProperty(name="Contain",
                                  description= "Contain (comma is the separator)",
                                 default="")
    
    suffix: StringProperty(name="suffix",
                                 description= "Suffix (comma is the separator)",
                                default="")
    
    #list 

    action_select: BoolProperty(name="Action",
                               description= "Select between Actions",
                               default=False)
    
    include_a: EnumProperty(items=[
        ('include', "Include", "Include Actions"),
        ('exclude', "Exclude", "Exclude Actions")
         ],
        name="",
        default='include')
    
    action_l: StringProperty(name = "",
                              description=" Actions List",
                              default="", options = {'SKIP_SAVE'})

    action_clean_all:  BoolProperty(name="",
                              description="Delete All",
                             default=False, options = {'SKIP_SAVE'})

    action_clean_last:  BoolProperty(name="",
                              description="Delete the last one",
                              default=False, options = {'SKIP_SAVE'})
    
    #only similar
    only_similar: BoolProperty(name="Only Similar Actions",
                               description= "Only Similar Actions",
                               default=True)

    action_collection = []

    number_trg = dict()

    def draw(self, context):
        layout = self.layout
        column = layout.column()

        o = ops.get_ob_or_armature(context, context.active_object)
        #test if its local
        if not o.data or not hasattr(o, "library") or o.library is not None or o.data.library is not None:
            column.label(text=f"make '{o.name}' local", icon='ERROR')
            column.separator()

        if self.bake_similar and self.number_trg:

            for ob_name, action_valid in self.number_trg.items():
                column.label(text=f"Include {len(action_valid)} Actions of {ob_name}")

                show_10 = 10

                if self.show_10 and not self.show_all and action_valid:

                    i = 1
                    for action in action_valid:
                        if i > show_10:
                            break
                        column.label(text=f"- {action.name} ")
                        i += 1

                if self.show_all and action_valid:

                    for action in action_valid:
                        column.label(text=f"- {action.name} ")

                if (not self.show_all and len(action_valid) >= 1) or (self.show_10 and len(action_valid) > show_10):
                    
                    row = column.split(factor=0.80, align=True)
                    row.label(text="")

                    if not self.show_all and len(action_valid) >= 1 :
                        row.prop(self, "show_10", toggle=True, icon='DOWNARROW_HLT')

                    if self.show_10 and len(action_valid) > show_10 :
                        row.prop(self, "show_all", toggle=True, icon='DOWNARROW_HLT')
            column.separator()
        else:
            #show number
            armatures = ops.get_selected_obs(context)
            num = 0
            for armature in armatures:

                if armature.type != 'ARMATURE':
                    continue
                num += 1
            if num > 1:
                row = column.split(factor=0.050, align=True)
                row.label(text="")
                row.label(text=f"{num} Armatures Selected")
                column.separator()

        
        row = column.split(factor=0.05, align=True)
        row.label(text="")
        row.label(text="Apply Rotation")
        column.separator()

        row = column.split(factor=0.05, align=True)
        row.label(text="")
        row.prop(self, "bake_similar")

        if self.bake_similar:

            row = column.split(factor=0.05, align=True)
            row.label(text="")
            row.prop(self, "only_selected_action")

            row = column.split(factor=0.05, align=True)
            row.label(text="")
            row.prop(self, "by_name")

            if self.by_name:
                subcol = row.column()
                subcol.prop(self, 'include')

                row = column.row()
                col = row.column()
                col.label(text="Prefix")
                col.prop(self, 'prefix', text="")

                col = row.column()
                col.label(text="Contain:")
                col.prop(self, 'contain', text="")

                col = row.column()
                col.label(text="Suffix:")
                col.prop(self, 'suffix', text="")

            row = column.split(factor=0.05, align=True)
            row.label(text="")
            row.prop(self, "action_select")

            if self.action_select:

                subcol = row.column()
                subcol.prop(self, 'include_a')

                row = column.split(factor=0.80, align=True)
                row.prop_search(self, 'action_l',
                            bpy.data,
                            "actions")
                
                row.prop(self, 'action_l')
                row.prop(self, 'action_clean_all', toggle=True, icon='PANEL_CLOSE')
                row.prop(self, 'action_clean_last',toggle=True, icon='TRACKING_CLEAR_BACKWARDS')

                i = 0
                row = column.split(factor=0.33, align=True)

                for act in self.action_collection:
                    if i == 3:
                        row = column.split(factor=0.33, align=True)
                        i = 0

                    row.label(text=act, icon='ACTION')

                    i += 1

            row = column.split(factor=0.05, align=True)
            row.label(text="")
            row.prop(self, "only_similar")
    
    def correct_action(self, action, context):

        if not self.bake_similar:
            return True
        
        if self.only_selected_action:
            selected_act = selected_action(context)
            if not action in selected_act:
                return False

        incl = -1
        incls = -1
        inclc = -1

        
        if self.by_name:
            if self.include == 'include':
                if self.prefix:
                    list_ = self.prefix.split(",")
                    incl = 0
                    for li in list_:
                        if li and not action.name.startswith(li):
                            incl -= 1
                        if li and action.name.startswith(li):
                            incl += 1
                    if incl < 0:
                        return self.test_list_action(action)

                if self.suffix:
                    list_ = self.suffix.split(",")
                    incls = 0
                    for li in list_:
                        if li and not action.name.endswith(li):
                            incls -= 1
                        if li and action.name.endswith(li):
                            incls += 1
                    if incls < 0:
                        return self.test_list_action(action)
                    
                if self.contain:
                    list_ = self.contain.split(",")
                    inclc = 0
                    for li in list_:
                        if li and not li in action.name:
                            inclc -= 1
                        if li and li in action.name:
                            inclc += 1
                    if inclc < 0:
                        return self.test_list_action(action)
            
            else:
                if self.prefix:
                    list_ = self.prefix.split(",")
                    for li in list_:
                        if li and action.name.startswith(li):
                            return False

                if self.suffix:
                    list_ = self.suffix.split(",")
                    for li in list_:
                        if li and action.name.endswith(li):
                            return False

                if self.contain:
                    list_ = self.contain.split(",")
                    for li in list_:
                        if li and li in action.name:
                            return False
        
        if self.action_select:

            if self.include_a == 'include':

                if self.action_collection and action.name not in self.action_collection:
                    return False or (incl >= 0 or incls >= 0 or inclc >= 0)
            
            elif self.action_collection and action.name in self.action_collection:
                return False
        
        return True
    
    def test_list_action(self, action):
        if self.action_select:
            if self.include_a == 'include':

                if self.action_collection and action.name in self.action_collection:
                    return True
        return False
    @classmethod
    def poll(cls, context):
        o = ops.get_ob_or_armature(context, context.active_object)
        if not o:
            return False
        return True
    
    def execute(self, context):

        self.number_trg.clear()

        armatures = ops.get_selected_obs(context)

        for ob in armatures:

            if not ob:
                continue

            if not hasattr(ob, "library"):
                continue

            if not ob.data:
                continue

            if ob.library is not None or ob.data.library is not None:
                continue

            actions = []

            if self.bake_similar:
                for action in bpy.data.actions:
                    if self.only_similar and not validate_actions(action, ob.path_resolve):
                        continue
                    if not self.correct_action(action, context):
                        continue
                    actions.append(action)
                #update ui
                self.number_trg[ob.name] = actions.copy()

            else:
                if ob.animation_data and ob.animation_data.action:
                     actions.append(ob.animation_data.action)


            for action in actions:
                if action and ops.action_armature(action):
                    for slot in action.slots:

                        if slot.target_id_type != 'OBJECT' or not ops.slot_armature(action, slot):
                            continue

                        del_fc = []
                        channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)
                        
                        if channelbag:
                            for fcurve in channelbag.fcurves:
                                if fcurve.data_path in ["rotation_axis_angle", "rotation_quaternion", "rotation_euler"]:
                                    del_fc.append(fcurve)

                            for fc in reversed(del_fc):
                                channelbag.fcurves.remove(fc)

            bpy.ops.object.mode_set(mode='OBJECT')
            ob.select_set(True)
            
            try:
                bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
            except:
                pass

        return {'FINISHED'}

class CreateTransformOffset(Operator):
    """Apply the scale ( without breaking the animation) / Scale the Character and setup an Empty to preserve final transform"""
    bl_idname = "object.retarget_create_offset"
    bl_label = "Apply Scale / Create Scale Offset"
    bl_options = {'REGISTER', 'UNDO'}

    container_name: StringProperty(name="Name", description="Name of the transform container", default="EMP-Offset")
    container_scale: FloatProperty(name="Scale", description="Scale of the transform container", default=1)
    apply_scale: BoolProperty(name="Apply Scale", default=True)
    fix_constraints: BoolProperty(name="Fix Constraints", description="Apply Offset to character constraints", default=True)
    
    #similar

    show_10: BoolProperty(name="",
                          description="Show Those Action",
                                default=True)
    
    show_all: BoolProperty(name="",
                           description="Show All Action",
                                default=False, options={'SKIP_SAVE'})

    bake_similar:BoolProperty(name="Include Similar Action",
                              description="convert other action",
                                default=False)
    #-----
    only_selected_action: BoolProperty(name="Only Selected Action(s)",
                                description= "Only selected Action(s) in Action Manager",
                                default=False)
    
    by_name: BoolProperty(name="by Name",
                            description= "Only Look for Action with this Prefix/Suffix",
                            default=False)
    
    include: EnumProperty(items=[
        ('include', "Include", "Include Action with this Prefix/Suffix"),
        ('exclude', "Exclude", "Exclude Action with this Prefix/Suffix")
         ],
        name="",
        default='include')
    
    prefix: StringProperty(name="prefix",
                                description= "Prefix (comma is the separator)",
                                default="")
    
    contain: StringProperty(name="Contain",
                                  description= "Contain (comma is the separator)",
                                 default="")
    
    suffix: StringProperty(name="suffix",
                                 description= "Suffix (comma is the separator)",
                                default="")
    
    #list 

    action_select: BoolProperty(name="Action",
                               description= "Select between Actions",
                               default=False)
    
    include_a: EnumProperty(items=[
        ('include', "Include", "Include Actions"),
        ('exclude', "Exclude", "Exclude Actions")
         ],
        name="",
        default='include')
    
    action_l: StringProperty(name = "",
                              description=" Actions List",
                              default="", options = {'SKIP_SAVE'})

    clean_all:  BoolProperty(name="",
                              description="Delete All",
                             default=False, options = {'SKIP_SAVE'})

    clean_last:  BoolProperty(name="",
                              description="Delete the last one",
                              default=False, options = {'SKIP_SAVE'})

    action_collection = []

    #---------------------
    
    do_parent: BoolProperty(name="Parent to the a Offset", description="Parent to the new offset to preserve final transform",
                            default=False, options={'SKIP_SAVE'})

    _allowed_modes = ['OBJECT', 'POSE']

    @classmethod
    def poll(cls, context):

        ob = ops.get_ob_or_armature(context, context.active_object)

        if not ob:
            return False

        if ob.type != 'ARMATURE':
            return False
        if context.mode not in cls._allowed_modes:
            return False

        return True

    def draw(self, context):
        layout = self.layout
        column = layout.column()

        o = ops.get_ob_or_armature(context, context.active_object)
        #test if its local
        if o.library is not None or o.data.library is not None:
            column.label(text=f"make '{o.name}' local", icon='ERROR')
            column.separator()

        if self.bake_similar:

            armatures = ops.get_selected_obs(context)

            for arm_ob in armatures:

                if arm_ob.type != 'ARMATURE':
                    continue

                action_valid = [action for action in bpy.data.actions if action and validate_actions(action, arm_ob.path_resolve) and self.correct_action(action, context)]

                column.label(text=f"Apply Scale to {len(action_valid)} Actions of {arm_ob.name}")

                show_10 = 10

                if self.show_10 and not self.show_all and action_valid:

                    i = 1
                    for action in action_valid:
                        if i > show_10:
                            break
                        column.label(text=f"- {action.name} ")
                        i += 1

                if self.show_all and action_valid:

                    for action in action_valid:
                        column.label(text=f"- {action.name} ")

                if (not self.show_all and len(action_valid) >= 1) or (self.show_10 and len(action_valid) > show_10):
                        
                    row = column.split(factor=0.80, align=True)
                    row.label(text="")

                    if not self.show_all and len(action_valid) >= 1 :
                        row.prop(self, "show_10", toggle=True, icon='DOWNARROW_HLT')

                    if self.show_10 and len(action_valid) > show_10 :
                        row.prop(self, "show_all", toggle=True, icon='DOWNARROW_HLT')
            column.separator()
        else:
            #show number
            armatures = ops.get_selected_obs(context)
            num = 0
            for armature in armatures:

                if armature.type != 'ARMATURE':
                    continue
                num += 1
            if num > 1:
                column.label(text=f"{num} Armatures Selected")
                column.separator()

        row = column.split(factor=0.2, align=True)
        row.label(text="Name")
        row.prop(self, 'container_name', text="")

        row = column.split(factor=0.2, align=True)
        row.label(text="Scale")
        row.prop(self, "container_scale", text="")

        row = column.row()
        row.prop(self, "apply_scale")

        row = column.row()
        row.prop(self, "fix_constraints")

        column.separator()
        row = column.row()
        tex = "-- Actions/Slots Influence --".center(50)
        row.label(text=tex, icon='ACTION')

        row = column.row()
        row.prop(self, "bake_similar")

        if self.bake_similar:

            row = column.row()
            row.prop(self, "only_selected_action")

            row = column.row()
            row.prop(self, "by_name")

            if self.by_name:
                subcol = row.column()
                subcol.prop(self, 'include')

                row = column.row()
                col = row.column()
                col.label(text="Prefix")
                col.prop(self, 'prefix', text="")

                col = row.column()
                col.label(text="Contain:")
                col.prop(self, 'contain', text="")

                col = row.column()
                col.label(text="Suffix:")
                col.prop(self, 'suffix', text="")

            row = column.row()
            row.prop(self, "action_select")

            if self.action_select:

                subcol = row.column()
                subcol.prop(self, 'include_a')

                row = column.split(factor=0.80, align=True)
                row.prop_search(self, 'action_l',
                            bpy.data,
                            "actions")
                
                row.prop(self, 'action_l')
                row.prop(self, 'clean_all', toggle=True, icon='PANEL_CLOSE')
                row.prop(self, 'clean_last',toggle=True, icon='TRACKING_CLEAR_BACKWARDS')

                i = 0
                row = column.split(factor=0.33, align=True)

                for act in self.action_collection:
                    if i == 3:
                        row = column.split(factor=0.33, align=True)
                        i = 0

                    row.label(text=act, icon='ACTION')

                    i += 1
       
        row = column.row()
        row.prop(self, "do_parent", toggle=True)

    def correct_action(self, action, context):

        if not self.bake_similar:
            return True
        
        if self.only_selected_action:
            selected_act = selected_action(context)
            if not action in selected_act:
                return False

        incl = -1
        incls = -1
        inclc = -1

        
        if self.by_name:
            if self.include == 'include':
                if self.prefix:
                    list_ = self.prefix.split(",")
                    incl = 0
                    for li in list_:
                        if li and not action.name.startswith(li):
                            incl -= 1
                        if li and action.name.startswith(li):
                            incl += 1
                    if incl < 0:
                        return self.test_list_action(action)

                if self.suffix:
                    list_ = self.suffix.split(",")
                    incls = 0
                    for li in list_:
                        if li and not action.name.endswith(li):
                            incls -= 1
                        if li and action.name.endswith(li):
                            incls += 1
                    if incls < 0:
                        return self.test_list_action(action)
                    
                if self.contain:
                    list_ = self.contain.split(",")
                    inclc = 0
                    for li in list_:
                        if li and not li in action.name:
                            inclc -= 1
                        if li and li in action.name:
                            inclc += 1
                    if inclc < 0:
                        return self.test_list_action(action)
            
            else:
                if self.prefix:
                    list_ = self.prefix.split(",")
                    for li in list_:
                        if li and action.name.startswith(li):
                            return False

                if self.suffix:
                    list_ = self.suffix.split(",")
                    for li in list_:
                        if li and action.name.endswith(li):
                            return False

                if self.contain:
                    list_ = self.contain.split(",")
                    for li in list_:
                        if li and li in action.name:
                            return False
        
        if self.action_select:

            if self.include_a == 'include':

                if self.action_collection and action.name not in self.action_collection:
                    return False or (incl >= 0 or incls >= 0 or inclc >= 0)
            
            elif self.action_collection and action.name in self.action_collection:
                return False
        
        return True
    
    def test_list_action(self, action):
        if self.action_select:
            if self.include_a == 'include':

                if self.action_collection and action.name in self.action_collection:
                    return True
        return False

    def execute(self, context):


        o = ops.get_ob_or_armature(context, context.active_object)
        #test if its local
        if o.library is not None or o.data.library is not None:
            return {'FINISHED'}
        
        bake_up = list(context.selected_objects)

        actif =  context.active_object

        #ini animation value

        #similar action
        if self.clean_all:
            if len(self.action_collection) > 0 :
                self.action_collection.clear()
            self.clean_all = False

        if self.clean_last:
            if len(self.action_collection) > 0 :
                self.action_collection.pop()
            self.clean_last = False

        if self.action_l != "":
            if not self.action_l in self.action_collection:
                self.action_collection.append(self.action_l)
            self.action_l = ""

        armatures = ops.get_selected_obs(context)

        for arm_ob in armatures:

            if arm_ob.type != 'ARMATURE':
                continue

            #test if its local
            if arm_ob.library is not None or arm_ob.data.library is not None:
                continue
            
            #apply the scale on children 
            rigged = []
            for ob in arm_ob.children_recursive:
                if ob and ob not in rigged:
                    rigged.append(ob)

            current_m = context.mode
            bpy.ops.object.mode_set(mode='OBJECT')
            for ob in rigged:
                bpy.ops.object.select_all(action='DESELECT')
                ob.select_set(True)
                context.view_layer.objects.active = ob
                try:
                    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
                except:
                    pass
                bpy.ops.object.select_all(action='DESELECT')
            for ob in armatures:
                ob.select_set(True)
            context.view_layer.objects.active = arm_ob

            bpy.ops.object.mode_set(mode=current_m)
            #------

            emp_ob = bpy.data.objects.new(self.container_name, None)
            context.collection.objects.link(emp_ob)

            container_scal = self.container_scale

            if self.apply_scale:
                current_m = context.mode
                bpy.ops.object.mode_set(mode='OBJECT')
                prev = arm_ob.scale[0]

                arm_ob.scale[0] = 1
                arm_ob.scale[1] = 1
                arm_ob.scale[2] = 1

                container_scal = self.container_scale / prev

                context.view_layer.objects.active = arm_ob
                bpy.ops.object.select_pattern( pattern=arm_ob.name, case_sensitive=True, extend=False)
                try:
                    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
                except:
                    pass
                bpy.ops.object.mode_set(mode= current_m)


            transform = Matrix().to_3x3() * container_scal

            emp_ob.matrix_world = transform.to_4x4()

            if self.do_parent:
                arm_ob.parent = emp_ob
                arm_ob.matrix_parent_inverse = emp_ob.matrix_world.inverted()

            inverted = emp_ob.matrix_world.inverted()
            arm_ob.data.transform(inverted)
            arm_ob.update_tag()

            # bring in metarig if found
            try:
                metarig = next(ob for ob in bpy.data.objects if ob.type == 'ARMATURE' and ob.data.rigify_target_rig == arm_ob)

            except (StopIteration, AttributeError):  # Attribute Error if Rigify is not loaded
                pass
            else:
                if self.do_parent:
                    metarig.parent = emp_ob
                metarig.data.transform(inverted)
                metarig.update_tag()

            if self.fix_constraints:
                # fix constraints rest lenghts
                for pbone in arm_ob.pose.bones:
                    for constr in pbone.constraints:
                        if constr.type == 'STRETCH_TO':
                            constr.rest_length /= container_scal
                        elif constr.type == 'LIMIT_DISTANCE':
                            constr.distance /= container_scal
                        elif constr.type == 'ACTION':
                            if constr.target == arm_ob and constr.transform_channel.startswith('LOCATION'):
                                if constr.target_space != 'WORLD':
                                    constr.min /= container_scal
                                    constr.max /= container_scal
                        elif constr.type == 'LIMIT_LOCATION' and constr.owner_space != 'WORLD':
                            constr.min_x /= container_scal
                            constr.min_y /= container_scal
                            constr.min_z /= container_scal

                            constr.max_x /= container_scal
                            constr.max_y /= container_scal
                            constr.max_z /= container_scal

            # scale rigged meshes as well
            for ob in rigged:
                if not ob:
                    continue

                if getattr(ob.data, "shape_keys", None):
                    # cannot transform objects with shape keys
                    ob.scale /= container_scal
                elif ob.data:
                    ob.data.transform(inverted)
                # fix scale dependent attrs in modifiers
                for mod in ob.modifiers:
                    if mod.type == 'DISPLACE':
                        mod.strength /= container_scal
                    elif mod.type == 'SOLIDIFY':
                        mod.thickness /= container_scal

            # apply transform again
            current_m = context.mode
            bpy.ops.object.mode_set(mode='OBJECT')
            for ob in rigged:
                if not ob:
                    continue
                bpy.ops.object.select_all(action='DESELECT')
                ob.select_set(True)
                context.view_layer.objects.active = ob
                try:
                    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
                except:
                    pass
                bpy.ops.object.select_all(action='DESELECT')

            for ob in armatures:
                ob.select_set(True)
            context.view_layer.objects.active = arm_ob
            bpy.ops.object.mode_set(mode=current_m)

            actions = []

            if self.bake_similar:
                actions = [action for action in bpy.data.actions if action and validate_actions(action, arm_ob.path_resolve) and self.correct_action(action, context)]
                
            else:
                if arm_ob.animation_data and arm_ob.animation_data.action:
                    actions.append(arm_ob.animation_data.action)

            for action in actions:

                if not action:
                    continue

                for slot in action.slots:
                    # del ob scale fcurve to prevent error
                    del_fc = []

                    if slot.target_id_type != 'OBJECT':
                        continue
                    
                    if not self.bake_similar and not (arm_ob in slot.users() ):
                        continue

                    channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)

                    for fc in channelbag.fcurves:
                        data_path = fc.data_path

                        if self.apply_scale and data_path == "scale":
                            del_fc.append(fc)

                        if not data_path.endswith('location') or data_path == "location":
                            continue

                        for kf in fc.keyframe_points:
                            kf.co[1] /= container_scal

                    for fc in reversed(del_fc):
                        channelbag.fcurves.remove(fc)
            #delete the empty
            if not self.do_parent:
                bpy.data.objects.remove(emp_ob, do_unlink=True)

        for o in bake_up:
            o.select_set(True, view_layer = context.view_layer)
        context.view_layer.objects.active = actif
        return {'FINISHED'}


class ExtractMetarig(Operator):
    """Create Metarig from current object"""
    bl_idname = "object.retarget_extract_metarig"
    bl_label = "Extract Metarig"
    bl_description = "Create Metarig from current Armature (Rigify addon must be activated)"
    bl_options = {'REGISTER', 'PRESET', 'UNDO'}

    rig_preset: EnumProperty(items=preset_handler.iterate_presets_with_current,
                             name="Rig Type",
                             options = {'SKIP_SAVE'}
                             )

    offset_knee: FloatProperty(name='Offset Knee',
                               default=-0.03)

    offset_elbow: FloatProperty(name='Offset Elbow',
                                default=0.03)

    offset_fingers: FloatVectorProperty(name='Offset Fingers')
    
    fit_target: BoolProperty(name="Fit height",
                              default=True)
    head_bone: StringProperty(name = "Head Bone",
                              default="")

    no_face: BoolProperty(name='No face bones',
                          default=True)

    no_eye: BoolProperty(name='No Eye bones',
                          description='Remove the eye bones from the face skeleton (this prevents the error in face skeleton).',
                          default=True)

    no_breast: BoolProperty(name='No breast bones',
                          default=True)

    rigify_names: BoolProperty(name='Use rigify names',
                               default=True)

    other_bone: BoolProperty(name='Add Other Bone',
                             description='Include additional bones (such as clothing bone)',
                               default=True)
    BONE_TYPE = (
        ('bone', "Bone", ""),
        ('circle', "Circle", ""),
        ('cube', "Cube", ""),
        ('cube_truncated', "Cube Truncated", ""),
        ('cuboctahedron', "Cuboctahedron", ""),
        ('diamond', "Diamond", ""),
        ('gear', "Gear", ""),
        ('jaw', "Jaw", ""),
        ('limb', "Limb", ""),
        ('line', "Line", ""),
        ('palm', "Palm", ""),
        ('palm_z', "Palm_z", ""),
        ('pivot', "Pivot", ""),
        ('pivot_cross', "Pivot_cross", ""),
        ('shoulder', "Shoulder", ""),
        ('sphere', "Sphere", ""),
        ('teeth', "teeth", "")
    )
    bone_shape: EnumProperty(items= BONE_TYPE,
        name="Bone Shape",
        description='Shape of Other Bone',
        default='bone')

    bone_shape_eye: EnumProperty(items= BONE_TYPE,
        name="Bone Shape For Eye",
        description='Shape of The Eye',
        default='sphere')
    
    color: EnumProperty(items= [
        ('white', "White", ""),
        ('Root', "Purple", ""),
        ('IK', "Red", ""),
        ('Special', "Yellow", ""),
        ('Tweak', "Blue", ""),
        ('FK', "Green", ""),
        ('Extra', "Orange", "")
    ],
        name="Color",
        description='Color of Other Bone',
        default='FK')


    only_deform: BoolProperty(name='Only Deform Bones',
                             description='Try not to include unnecessary bones.',
                               default=True)

    assign_metarig: BoolProperty(name='Assign metarig',
                                 default=True,
                                 description='Rigify will generate to the active object')

    forward_spine_roll: BoolProperty(name='Align spine frontally', default=True,
                                     description='Spine Z will face the Y axis')

    apply_transforms: BoolProperty(name='Apply Transform', default=True,
                                   description='Apply current transforms before extraction')

    num = 0

    def draw(self, context):
        layout = self.layout
        column = layout.column()

        o = ops.get_ob_or_armature(context, context.active_object)
        #test if its local
        if o.library is not None or o.data.library is not None:
            column.label(text=f"make '{ops.get_ob_or_armature(context, context.active_object).name}' local", icon='ERROR')
            column.separator()

        #show number
        if self.num > 1:
            column.label(text=f"{self.num} Armatures Selected")
            column.separator()

        # if not context.active_object.data.retarget_retarget.has_settings():
        row = column.row()
        row.prop(self, 'rig_preset', text="Rig Type")

        row = column.split(factor=0.10, align=True)
        row.label(text="")

        row = column.split(factor=0.5, align=True)
        row.label(text="Offset Knee")
        row.prop(self, 'offset_knee', text='')

        row = column.split(factor=0.5, align=True)
        row.label(text="Offset Elbow")
        row.prop(self, 'offset_elbow', text='')

        row = column.split(factor=0.5, align=True)
        row.label(text="Offset Fingers")
        row.prop(self, 'offset_fingers', text='')

        row = column.split(factor=0.5, align=True)
        row.label(text="Fit Head")
        row.prop(self, 'fit_target', text='')

        row = column.split(factor=0.5, align=True)
        row.label(text="No Face Bones")
        row.prop(self, 'no_face', text='')

        if not self.no_face:
            row = column.split(factor=0.5, align=True)
            row.label(text="No Eye Bones")
            row.prop(self, 'no_eye', text='')


        row = column.split(factor=0.5, align=True)
        row.label(text="No Breast Bones")
        row.prop(self, 'no_breast', text='')

        row = column.split(factor=0.5, align=True)
        row.label(text="Use Rigify Names")
        row.prop(self, 'rigify_names', text='')

        if self.rigify_names:
            row = column.split(factor=0.5, align=True)
            row.label(text="Add Other Bone")
            row.prop(self, 'other_bone', text='')

            if self.other_bone:
                row = column.split(factor=0.5, align=True)
                row.label(text="Only Deform Bones")
                row.prop(self, 'only_deform', text='')

                row = column.split(factor=0.5, align=True)
                row.label(text="Bone Shape")
                row.prop(self, 'bone_shape', text='')

                row = column.split(factor=0.5, align=True)
                row.label(text="Bone Shape For Eye")
                row.prop(self, 'bone_shape_eye', text='')

                row = column.split(factor=0.5, align=True)
                row.label(text="Color")
                row.prop(self, 'color', text='')

        row = column.split(factor=0.5, align=True)
        row.label(text="Assign Metarig")
        row.prop(self, 'assign_metarig', text='')

        row = column.split(factor=0.5, align=True)
        row.label(text="Align spine frontally")
        row.prop(self, 'forward_spine_roll', text='')

        row = column.split(factor=0.5, align=True)
        row.label(text="Apply Transform")
        row.prop(self, 'apply_transforms', text='')

    @classmethod
    def poll(cls, context):
        ob = ops.get_ob_or_armature(context, context.active_object)
        if not ob:
            return False
        if 'rigify' not in context.preferences.addons:
            return False
        if ob.type != 'ARMATURE':
            return False

        return True
    
    def invoke(self, context, event):

        o = ops.get_ob_or_armature(context, context.active_object)

        if o.data.retarget_retarget.has_settings():
            self.rig_preset = '--Current--'

        else:
            self.rig_preset = preset_handler.findPreset(o)
        
        return self.execute(context)

    def execute(self, context):

        o = ops.get_ob_or_armature(context, context.active_object)
        #test if its local
        if o.library is not None or o.data.library is not None:
            return {'FINISHED'}
        
        self.num = 0

        current_m = context.mode

        armatures = ops.get_selected_obs(context)
        for src_object in armatures:

            if src_object.type != 'ARMATURE':
                continue

            #test if its local
            if src_object.library is not None or src_object.data.library is not None:
                continue

            if not src_object.data.bones:
                continue

            self.num += 1
            
            context.view_layer.objects.active = src_object
            bpy.ops.object.mode_set(mode='POSE')

            src_armature = src_object.data

            current_settings = src_object.data.retarget_retarget

            if self.rig_preset == "--Current--":
                if not current_settings.has_settings():
                    continue

                if current_settings.deform_preset and current_settings.deform_preset != '--':

                    backup_settings = preset_handler.PresetSkeleton()
                    backup_settings.copy(current_settings)
                    
                    deform_preset = current_settings.deform_preset

                    src_skeleton = preset_handler.set_preset_skel(deform_preset, context)

                    if not src_skeleton or not src_skeleton.has_settings():
                       
                        src_skeleton = preset_handler.get_settings_skel(backup_settings)

                    current_settings = src_skeleton

                else:
                    src_settings = preset_handler.PresetSkeleton()
                    src_settings.copy(current_settings)
                    src_skeleton = preset_handler.get_settings_skel(src_settings)
            else:
                src_skeleton = preset_handler.set_preset_skel(self.rig_preset, context)
                
                if src_skeleton and src_skeleton.deform_preset and src_skeleton.deform_preset != '--':
                    def_skeleton = preset_handler.set_preset_skel(src_skeleton.deform_preset, context)
                    
                    if def_skeleton and def_skeleton.has_settings():
                        src_skeleton = def_skeleton

            if not src_skeleton:
                continue

            #preparation of the model
            if src_object.animation_data and src_object.animation_data.action:
                src_object.animation_data.action = None

            if src_object.animation_data:
                src_object.animation_data_clear()

            bpy.ops.object.mode_set(mode='OBJECT')
            src_object.location = [0,0,0]
            bpy.ops.object.mode_set(mode='POSE')

            for bone in src_object.pose.bones:
                bone.matrix_basis = Matrix()

            if self.apply_transforms:
               
                bpy.ops.object.mode_set(mode='OBJECT')
                src_object.select_set(True)

                for ob in src_object.children_recursive:
                    ob.select_set(True)
                for ob in bone_utils.iterate_rigged_obs(src_object, context):
                    ob.select_set(True)

                context.view_layer.objects.active = src_object
                try:
                    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
                except:
                    pass

                # rigged = (ob for ob in src_object.children_recursive)

                # for ob in rigged:
                #     if ob and ob.data:
                #         ob.data.transform(src_object.matrix_local)

                # src_armature.transform(src_object.matrix_local)
                # src_object.matrix_local = Matrix()
            
            met_skeleton = bone_mapping.RigifyMeta()

            bone_names_map = dict()


            if self.rigify_names:
                # check if doesn't contain rigify deform bones already (NOT)

                # bones_needed = met_skeleton.spine.hips, met_skeleton.spine.spine
                # if not [b for b in bones_needed if b in src_object.pose.bones]:
                # Converted settings should not be validated yet, as bones have not been renamed
                
                src_skeleton, trg_skeleton = ConvertBoneNaming.convert_settings(current_settings, 'Rigify_Deform.py', context, validate=False)
                #resetname = len(armatures) > 1
                #TODO check it
                bone_names_map = src_skeleton.conversion_map(trg_skeleton, skip_ik= True,other_bone=False)


                ConvertBoneNaming.rename_bones(src_object, src_skeleton, trg_skeleton, skip_ik=True)
                src_skeleton = bone_mapping.RigifySkeleton()

                for name_attr in ('left_eye', 'right_eye'):
                    bone_name = getattr(src_skeleton.face, name_attr)

                    if bone_name not in src_armature.bones and bone_name[4:] in src_armature.bones:
                        # fix eye bones lacking "DEF-" prefix on b3.2
                        setattr(src_skeleton.face, name_attr, bone_name[4:])

                    if src_skeleton.face.super_copy:
                        # supercopy def bones start with DEF-
                        bone_name = getattr(src_skeleton.face, name_attr)

                        if not bone_name.startswith('DEF-'):
                            new_name = f"DEF-{bone_name}"
                            try:
                                src_object.data.bones[bone_name].name = new_name
                            except KeyError:
                                pass
                            else:
                                setattr(src_skeleton.face, name_attr, new_name)


            otherbone = self.other_bone and self.rigify_names
            additional_bones = []
            if otherbone:

                # def is_bone_affect(armature, mesh, bone_name):

                #     #check if it in vertex group of the mesh
                #     if bone_name not in mesh.vertex_groups:
                #         return False
                    
                #     #get the vertex group
                #     bone_group = mesh.vertex_groups[bone_name]
                #     group_index = bone_group.index

                #     mesh_data = mesh.data
                #     for vertex in mesh_data.vertices:
                #         for group in vertex.groups:
                #             if group.group == group_index and group.weight > 0:
                #                 return True
                #     return False

                list_deform = []
                if self.only_deform:
                    #bpy.ops.object.mode_set(mode='OBJECT')

                    # for bone in src_object.pose.bones:

                    #     for child in src_object.children_recursive:
                    #         if child.type == "MESH":
                    #             if is_bone_affect(src_object, child, bone.name):
                    #                 if not bone.name in list_deform:
                    #                     list_deform.append(bone.name)
                    # bpy.ops.object.mode_set(mode='POSE')

                    for child in src_object.children_recursive:
                        if child.type == "MESH":
                            for vert in child.vertex_groups:
                                if not vert.name in list_deform:
                                    list_deform.append(vert.name)

                root = src_object.pose.bones[0]
                for bone in src_object.pose.bones:

                    if root.name == bone.name:
                        continue
                    
                    if self.only_deform:
                        if not bone.name in list_deform:
                            continue

                    if bone.name not in bone_names_map.values() and bone.name != "Root":
                        bone.rigify_type = "basic.super_copy"


            # if otherbone:

            #     for bone in src_object.pose.bones:
            #         if bone.name not in bone_names_map.values() and bone.name != "Root":

            #             if bone.child and bone.parent and bone.parent in bone_names_map.values():
            #                 bone.rigify_type = "limbs.simple_tentacle"

            #             elif not bone.child and bone.parent and bone.parent in bone_names_map.values():
            #                 bone.rigify_type = "basic.super_copy"

            #             additional_bones.append((bone.name, bone.rigify_type))

             # bones that have rigify attr will be copied when the metarig is in edit mode
            additional_bones = [(b.name, b.rigify_type) for b in src_object.pose.bones if b.rigify_type]


            try:
                metarig = next(ob for ob in context.scene.objects if ob.type == 'ARMATURE' and ob.data.rigify_target_rig == src_object)
                #check visibility
            except AttributeError:
                self.report({'WARNING'}, 'Rigify Add-On not enabled')
                return {'CANCELLED'}
            except StopIteration:
                create_metarig = True
                met_armature = bpy.data.armatures.new('metarig')
                metarig = bpy.data.objects.new("metarig", met_armature)
                try:
                    metarig.data.rigify_rig_basename = src_object.name
                except AttributeError:
                    # removed in rigify 0.6.4
                    pass

                context.collection.objects.link(metarig)
            else:
                met_armature = metarig.data
                create_metarig = False

            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')

            if not metarig.name in context.collection.objects:
                context.collection.objects.link(metarig)

            metarig.select_set(True)
            context.view_layer.objects.active = metarig
            bpy.ops.object.mode_set(mode='EDIT')

            if create_metarig:
                from rigify.metarigs import human
                human.create(metarig)

            if self.fit_target:
                head = ''
                if src_skeleton.spine.head and src_skeleton.spine.head in src_armature.bones:
                    head = src_skeleton.spine.head

                if head:
                    trg_head = "spine.006"
                    trg_bone = metarig.pose.bones[trg_head]
                    trg_height = (metarig.matrix_world @ trg_bone.bone.head_local)

                    ob_height = (src_object.matrix_world @ src_object.pose.bones[head].bone.head_local)
                    height_ratio = ob_height[2] / trg_height[2]
                    metarig.scale *= height_ratio

                    # Apply scale
                    bpy.ops.object.mode_set(mode='OBJECT')
                    context.view_layer.objects.active = metarig
                    bpy.ops.object.select_pattern( pattern=metarig.name, case_sensitive=True, extend=False)
                    try:
                        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
                    except:
                        pass
                    for o in armatures:
                        o.select_set(True, view_layer = context.view_layer)
                    bpy.ops.object.mode_set(mode='EDIT')

            def match_meta_bone(met_bone_group, src_bone_group, bone_attr, axis=None):
                try:
                    met_bone = met_armature.edit_bones[getattr(met_bone_group, bone_attr)]
                    src_bone_name = getattr(src_bone_group, bone_attr)
                    src_bone = src_armature.bones.get(src_bone_name, None)

                except KeyError:
                    return

                if not src_bone:
                    self.report({'WARNING'}, f"{bone_attr}, {src_bone_name} not found in {src_armature}")
                    return

                met_bone.head = src_bone.head_local
                met_bone.tail = src_bone.tail_local

                if met_bone.parent and met_bone.use_connect:
                    bone_dir = met_bone.vector.normalized()
                    parent_dir = met_bone.parent.vector.normalized()

                    if bone_dir.dot(parent_dir) < -0.6:
                        self.report({'WARNING'}, f"{met_bone.name} is not aligned with its parent")
                        # TODO

                if axis:
                    met_bone.roll = bone_utils.ebone_roll_to_vector(met_bone, axis)
                else:
                    src_x_axis = Vector((0.0, 0.0, 1.0)) @ src_bone.matrix_local.inverted().to_3x3()
                    src_x_axis.normalize()
                    met_bone.roll = bone_utils.ebone_roll_to_vector(met_bone, src_x_axis)

                return met_bone

            for bone_attr in ['hips', 'spine', 'spine1', 'spine2', 'neck', 'head']:
                if self.forward_spine_roll:
                    align = Vector((0.0, -1.0, 0.0))
                else:
                    align = None
                match_meta_bone(met_skeleton.spine, src_skeleton.spine, bone_attr, axis=align)

            for bone_attr in ['shoulder', 'arm', 'forearm', 'hand']:
                match_meta_bone(met_skeleton.right_arm, src_skeleton.right_arm, bone_attr)
                match_meta_bone(met_skeleton.left_arm, src_skeleton.left_arm, bone_attr)

            for bone_attr in ['upleg', 'leg', 'foot', 'toe']:
                match_meta_bone(met_skeleton.right_leg, src_skeleton.right_leg, bone_attr)
                match_meta_bone(met_skeleton.left_leg, src_skeleton.left_leg, bone_attr)

            rigify_face_bones = bone_mapping.rigify_face_bones
            if self.no_face or (not self.no_face and not self.no_eye):

                for bone_attr in ['left_eye', 'right_eye', 'jaw']:
                    met_bone = match_meta_bone(met_skeleton.face, src_skeleton.face, bone_attr)
                    if met_bone:
                        try:
                            rigify_face_bones.remove(met_skeleton.face[bone_attr])
                        except ValueError:
                            pass

                        if src_skeleton.face.super_copy:
                            metarig.pose.bones[met_bone.name].rigify_type = "basic.super_copy"
            
                            # FIXME: sometimes eye bone group is not renamed accordingly
                            # TODO: then maybe change jaw shape to box

            try:
                right_leg = met_armature.edit_bones[met_skeleton.right_leg.leg]
                left_leg = met_armature.edit_bones[met_skeleton.left_leg.leg]
            except KeyError:
                pass
            else:
                offset = Vector((0.0, self.offset_knee, 0.0))
                for bone in right_leg, left_leg:
                    bone.head += offset

                try:
                    right_knee = met_armature.edit_bones[met_skeleton.right_arm.forearm]
                    left_knee = met_armature.edit_bones[met_skeleton.left_arm.forearm]
                except KeyError:
                    pass
                else:
                    offset = Vector((0.0, self.offset_elbow, 0.0))

                    for bone in right_knee, left_knee:
                        bone.head += offset

            def match_meta_fingers(met_bone_group, src_bone_group, bone_attr):
                met_bone_names = getattr(met_bone_group, bone_attr)
                src_bone_names = getattr(src_bone_group, bone_attr)

                if not src_bone_names:
                    print(bone_attr, "not found in", src_armature)
                    return
                if not met_bone_names:
                    print(bone_attr, "not found in", src_armature)
                    return

                if 'thumb' not in bone_attr:
                    try:
                        met_bone = met_armature.edit_bones[met_bone_names[0]]
                        src_bone = src_armature.bones.get(src_bone_names[0], None)
                    except KeyError:
                        pass
                    else:
                        if src_bone:
                            palm_bone = met_bone.parent

                            palm_bone.tail = src_bone.head_local
                            hand_bone = palm_bone.parent
                            palm_bone.head = hand_bone.head * 0.75 + src_bone.head_local * 0.25
                            palm_bone.roll = 0

                for met_bone_name, src_bone_name in zip(met_bone_names, src_bone_names):
                    try:
                        met_bone = met_armature.edit_bones[met_bone_name]
                        src_bone = src_armature.bones[src_bone_name]
                      
                    except KeyError:
                        print("source bone not found", src_bone_name)
                        continue

                    met_bone.head = src_bone.head_local
                    try:
                        met_bone.tail = src_bone.children[0].head_local
                    except IndexError:
                        bone_utils.align_to_closer_axis(src_bone, met_bone)

                    met_bone.roll = 0.0
                    

                    src_z_axis = Vector((0.0, 0.0, 1.0)) @ src_bone.matrix_local.to_3x3()

                    inv_rot = met_bone.matrix.to_3x3().inverted()
                    trg_z_axis = src_z_axis @ inv_rot
                    dot_z = (met_bone.z_axis @ met_bone.matrix.inverted()).dot(trg_z_axis)
                    met_bone.roll = dot_z * pi


                    offset_fingers = Vector(self.offset_fingers) @ src_bone.matrix_local.to_3x3()
                    if met_bone.head.x < 0:  # Right side
                        offset_fingers /= -100
                    else:
                        offset_fingers /= 100

                    if met_bone.parent.name in met_bone_names and met_bone.children:
                        met_bone.head += offset_fingers
                        met_bone.tail += offset_fingers

            for bone_attr in ['thumb', 'index', 'middle', 'ring', 'pinky']:
                match_meta_fingers(met_skeleton.right_fingers, src_skeleton.right_fingers, bone_attr)
                match_meta_fingers(met_skeleton.left_fingers, src_skeleton.left_fingers, bone_attr)

            try:
                met_armature.edit_bones['spine.003'].tail = met_armature.edit_bones['spine.004'].head
                met_armature.edit_bones['spine.005'].head = (met_armature.edit_bones['spine.004'].head + met_armature.edit_bones['spine.006'].head) / 2
            except KeyError:
                pass

            # find foot vertices
            foot_verts = {}
            foot_ob = None
            # pick object with most foot verts
            for ob in bone_utils.iterate_rigged_obs(src_object, context):
                if src_skeleton.left_leg.foot not in ob.vertex_groups:
                    continue
                grouped_verts = bone_utils.get_group_verts(ob, src_skeleton.left_leg.foot, threshold=0.8)
                if len(grouped_verts) > len(foot_verts):
                    foot_verts = grouped_verts
                    foot_ob = ob
            if foot_verts:
                # find rear verts (heel)
                rearest_y = max([foot_ob.data.vertices[v].co[1] for v in foot_verts])
                leftmost_x = max([foot_ob.data.vertices[v].co[0] for v in foot_verts])  # FIXME: we should counter rotate verts for more accuracy
                rightmost_x = min([foot_ob.data.vertices[v].co[0] for v in foot_verts])

                for side in 'L', 'R':
                    # invert left/right vertices when we switch sides
                    leftmost_x, rightmost_x = rightmost_x, leftmost_x

                    heel_bone = met_armature.edit_bones['heel.02.' + side]

                    heel_bone.head.y = rearest_y
                    heel_bone.tail.y = rearest_y

                    if heel_bone.head.x > 0:
                        heel_head = leftmost_x
                        heel_tail = rightmost_x
                    else:
                        heel_head = rightmost_x * -1
                        heel_tail = leftmost_x * -1
                    heel_bone.head.x = heel_head
                    heel_bone.tail.x = heel_tail

                    try:
                        spine_bone = met_armature.edit_bones['spine']
                        pelvis_bone = met_armature.edit_bones['pelvis.' + side]
                    except KeyError:
                        pass
                    else:
                        pelvis_bone.head = spine_bone.head
                        pelvis_bone.tail.z = spine_bone.tail.z

                    try:
                        spine_bone = met_armature.edit_bones['spine.003']
                        breast_bone = met_armature.edit_bones['breast.' + side]
                    except KeyError:
                        pass
                    else:
                        breast_bone.head.z = spine_bone.head.z
                        breast_bone.tail.z = spine_bone.head.z

            if self.no_face:
                for bone_name in rigify_face_bones:
                    try:
                        face_bone = met_armature.edit_bones[bone_name]
                    except KeyError:
                        continue

                    met_armature.edit_bones.remove(face_bone)

            if self.no_breast:
                try:
                    breastl = met_armature.edit_bones["breast.L"]
                    breastr = met_armature.edit_bones["breast.R"]
                    met_armature.edit_bones.remove(breastl)
                    met_armature.edit_bones.remove(breastr)
                except KeyError:
                    pass

            name_collect = "Other Bone"
            try:
                ob_collection = met_armature.collections[name_collect]
            except KeyError:
                ob_collection = met_armature.collections.new(name_collect)
                ob_collection.is_visible = True
            other_bone_found = False

            for src_name, src_attr in additional_bones:

                new_bone_name = bone_utils.copy_bone_to_arm(src_object, metarig, src_name, suffix="")
                new_b = met_armature.edit_bones[new_bone_name]
                for coll in new_b.collections:
                    coll.unassign(new_b)
                other_bone_found = True
                ob_collection.assign(new_b)

                if 'chain' in src_attr:  # TODO: also fingers
                    # working around weird bug: sometimes src_armature.bones causes KeyError even if the bone is there
                    bone = next((b for b in src_armature.bones if b.name == src_name), None)

                    new_parent_name = new_bone_name
                    while bone:
                        # optional: use connect
                        try:
                            bone = bone.children[0]
                        except IndexError:
                            break

                        child_bone_name = bone_utils.copy_bone_to_arm(src_object, metarig, bone.name, suffix="")
                        child_bone = met_armature.edit_bones[child_bone_name]
                        child_bone.parent = met_armature.edit_bones[new_parent_name]
                        child_bone.use_connect = True

                        bone.name = f"DEF-{bone.name}"
                        new_parent_name = child_bone_name

                try:
                    bone = next((b for b in src_armature.bones if b.name == src_name), None)

                    if bone:
                        if bone.parent:
                            # FIXME: should use mapping to get parent bone name
                            parent_name = bone.parent.name.replace('DEF-', '')
                            met_armature.edit_bones[new_bone_name].parent = met_armature.edit_bones[parent_name]
                        if ".raw_" in src_attr:
                            met_armature.edit_bones[new_bone_name].use_deform = bone.use_deform
                        elif bone.name.startswith('DEF-'):
                            # already a DEF, need to strip that from metarig bone instead
                            met_armature.edit_bones[new_bone_name].name = new_bone_name.replace("DEF-", '')
                        else:
                            bone.name = f'DEF-{bone.name}'
                except KeyError:
                    self.report({'WARNING'}, "bones not found in target, perhaps wrong preset?")
                    continue

            bpy.ops.object.mode_set(mode='POSE')

            if otherbone:
                #add other bone in interface
                if other_bone_found:
                    bpy.ops.armature.rigify_collection_add_ui_row(row=1, add=True)
                    bpy.ops.armature.rigify_collection_set_ui_row(index= ob_collection.index, row=1)

                    #set the color
                    if self.color != "white":
                        metarig.data.collections_all["Other Bone"].rigify_color_set_name = self.color
            # now we can copy the stored rigify attrs
            for src_name, src_attr in additional_bones:
                src_meta = src_name[4:] if src_name.startswith('DEF-') else src_name
                if src_meta in metarig.pose.bones:
                    metarig.pose.bones[src_meta].rigify_type = src_attr
                # TODO: should copy rigify options of specific types as well

            #set the shape 
            for bone in metarig.pose.bones:

                if "shoulder.L" == bone.name or  "shoulder.R" == bone.name:
                    continue

                if bone.rigify_type == "basic.super_copy":
                    rig_params = bone.rigify_parameters

                    if bone.name in ['eye.L', 'eye.R']:
                        rig_params.super_copy_widget_type = self.bone_shape_eye
                    else:
                        rig_params.super_copy_widget_type = self.bone_shape

            if current_settings.left_leg.upleg_twist_02 or current_settings.left_leg.leg_twist_02:
                metarig.pose.bones['thigh.L']['RigifyParameters.segments'] = 3

            if current_settings.right_leg.upleg_twist_02 or current_settings.right_leg.leg_twist_02:
                metarig.pose.bones['thigh.R']['RigifyParameters.segments'] = 3

            if current_settings.left_arm.arm_twist_02 or current_settings.left_arm.forearm_twist_02:
                metarig.pose.bones['upper_arm.L']['RigifyParameters.segments'] = 3

            if current_settings.right_arm.arm_twist_02 or current_settings.right_arm.forearm_twist_02:
                metarig.pose.bones['upper_arm.R']['RigifyParameters.segments'] = 3

            if self.assign_metarig:
                met_armature.rigify_target_rig = src_object

            metarig.parent = src_object.parent

            #set preset
            preset_handler.get_preset_skel("Rigify_Controls.py", src_object.data.retarget_retarget, validate=False)

        bpy.ops.object.mode_set(mode= current_m)
        return {'FINISHED'}

class BindToMetarig(Operator):
    bl_idname = "armature.retarget_bind_to_metarig"
    bl_label = "Bind to Active Metarig"
    bl_description = "(select at least 2 armatures) (Rigify addon must be activated)"
    bl_options = {'REGISTER', 'PRESET', 'UNDO'}

    src_preset: EnumProperty(items=preset_handler.iterate_presets_with_current,
                             name="To Bind",
                             description="Source Armature"
                             )

    trg_preset: EnumProperty(items=preset_handler.iterate_presets_with_current,
                             name="Metarig",
                             description="Metarig Armature (Active Armature)"
                             )
    
    search_option: BoolProperty(name="Search",
                                description="Set The Head Bone Manually",
                                default=False)
    fit_target: BoolProperty(name="Fit height",
                              default=True)
    head_bone: StringProperty(name = "Head Bone",
                              default="")
    
    offset_bone: FloatProperty(name='Offset Bone',
                                default=0.005)
    
    no_face: BoolProperty(name='No face bones',
                          default=True)
    
    dont_aligne_eye: BoolProperty(name="Don't Align The Eye",
                               default=True)
    
    rigify_names: BoolProperty(name='Use rigify names',
                               default=True)
    
    other_bone: BoolProperty(name='Add Other Bone',
                             description='Include additional bones (such as clothing bone)',
                               default=True)
    
    only_deform: BoolProperty(name='Only Deform Bones',
                             description='Try not to include unnecessary bones.',
                               default=True)
    
    BONE_TYPE = (
        ('bone', "Bone", ""),
        ('circle', "Circle", ""),
        ('cube', "Cube", ""),
        ('cube_truncated', "Cube Truncated", ""),
        ('cuboctahedron', "Cuboctahedron", ""),
        ('diamond', "Diamond", ""),
        ('gear', "Gear", ""),
        ('jaw', "Jaw", ""),
        ('limb', "Limb", ""),
        ('line', "Line", ""),
        ('palm', "Palm", ""),
        ('palm_z', "Palm_z", ""),
        ('pivot', "Pivot", ""),
        ('pivot_cross', "Pivot_cross", ""),
        ('shoulder', "Shoulder", ""),
        ('sphere', "Sphere", ""),
        ('teeth', "teeth", "")
    )

    bone_shape: EnumProperty(items= BONE_TYPE,
        name="Bone Shape",
        description='Shape of Other Bone',
        default='bone')
    
    bone_shape_eye: EnumProperty(items= BONE_TYPE,
        name="Bone Shape For Eye",
        description='Shape of The Eye',
        default='sphere')
    
    color: EnumProperty(items= [
        ('white', "White", ""),
        ('Root', "Purple", ""),
        ('IK', "Red", ""),
        ('Special', "Yellow", ""),
        ('Tweak', "Blue", ""),
        ('FK', "Green", ""),
        ('Extra', "Orange", "")
    ],
        name="Color",
        description='Color of Other Bone',
        default='FK')

    apply_transforms: BoolProperty(name='Apply Transform', default=True,
                                   description='Apply current transforms before extraction')
    
    def draw(self, context):
        layout = self.layout
        column = layout.column()
        
        #test if its local
        o = ops.get_ob_or_armature(context, context.active_object)

        if o.library is not None or o.data.library is not None:
            column.label(text=f"make '{o.name}' local", icon='ERROR')
            column.separator()

        row = column.row()
        row.prop(self, 'src_preset')

        row = column.row()
        row.prop(self, 'trg_preset')

        sr_ob = None
        for ob in ops.get_selected_obs(context):
            if ob.type == 'ARMATURE' and ob != o:
                sr_ob = ob
                break

        row = column.split(factor=0.10, align=True)
        row.label(text="")
        subrow = row.row()
        subrow.prop(self, "search_option", text="", icon="SYNTAX_ON")
        subrow.label(text="Fit Head")
        subrow.prop(self, 'fit_target')
        if self.search_option and self.fit_target and sr_ob:
            row = column.split(factor=0.10, align=True)
            row.label(text="")
            row.prop_search(self, 'head_bone',
                        sr_ob.data,
                        "bones", text="Head Bone")
        
        row = column.split(factor=0.5, align=True)
        row.label(text="Offset Bone")
        row.prop(self, 'offset_bone', text='')

        row = column.split(factor=0.5, align=True)
        row.label(text="No Face Bones")
        row.prop(self, 'no_face', text='')
        
        row = column.split(factor=0.5, align=True)
        row.label(text="Use Rigify Names")
        row.prop(self, 'rigify_names', text='')

        if self.rigify_names:
            row = column.split(factor=0.5, align=True)
            row.label(text="Add Other Bone")
            row.prop(self, 'other_bone', text='')

            if self.other_bone:
                row = column.split(factor=0.5, align=True)
                row.label(text="Only Deform Bones")
                row.prop(self, 'only_deform', text='')

                row = column.split(factor=0.5, align=True)
                row.label(text="Bone Shape")
                row.prop(self, 'bone_shape', text='')
                
                row = column.split(factor=0.5, align=True)
                row.label(text="Bone Shape For Eye")
                row.prop(self, 'bone_shape_eye', text='')

                row = column.split(factor=0.5, align=True)
                row.label(text="Color")
                row.prop(self, 'color', text='')

        row = column.split(factor=0.5, align=True)
        row.label(text="Don't Align The Eye")
        row.prop(self, 'dont_aligne_eye', text='')

        row = column.split(factor=0.5, align=True)
        row.label(text="Apply Transform")
        row.prop(self, 'apply_transforms', text='')

    @classmethod
    def poll(cls, context):
        o = ops.get_ob_or_armature(context, context.active_object)
        if not o:
            return False
        if 'rigify' not in context.preferences.addons:
            return False
        
        if len(ops.get_selected_obs(context)) < 2:
            return False
        #At least 2 Armatures
        i = 0
        for ob in ops.get_selected_obs(context):
            if ob.type == 'ARMATURE':
                i = i + 1
            if i >= 2:
                return True
        return False


    def invoke(self, context, event):
        o = ops.get_ob_or_armature(context, context.active_object)
        to_bind = next(ob for ob in ops.get_selected_obs(context) if ob != o and ob.type == 'ARMATURE')

        if to_bind.data.retarget_retarget.has_settings():
            self.src_preset = '--Current--'

        else:
            self.src_preset = preset_handler.findPreset(to_bind)

        if o.data.retarget_retarget.has_settings():
            self.trg_preset = '--Current--'

        else:
            self.trg_preset = preset_handler.findPreset(o)

        if not self.head_bone in to_bind.pose.bones:
            self.head_bone = ""

        return self.execute(context)

    def execute(self, context):
        
        metarig = ops.get_ob_or_armature(context, context.active_object)

        if not metarig or metarig.type != "ARMATURE":
            return {'FINISHED'}
        
        metarig.select_set(True)
        
        met_armature = metarig.data

        #test if its local
        if metarig.library is not None or metarig.data.library is not None:            
            return {'FINISHED'}

        #test if its a metarig
        find_type = False
        for bone in metarig.pose.bones:
            if bone.rigify_type:
                find_type = True
                break
        if not find_type:
            self.report({'WARNING'}, 'Select a Metarig')
            return {'FINISHED'}

        trg_skeleton = HumanSkeleton()

        if self.trg_preset == '--':
            return {'FINISHED'}

        if self.src_preset == '--':
            return {'FINISHED'}
        
        if self.trg_preset == '--Current--' and metarig.data.retarget_retarget.has_settings():
            trg_settings = metarig.data.retarget_retarget
            trg_skeleton = preset_handler.get_settings_skel(trg_settings)
            
        else:
            trg_skeleton = preset_handler.set_preset_skel(self.trg_preset, context)

            if not trg_skeleton:
                return {'FINISHED'}
            

        current_m = context.mode

        if metarig.animation_data and metarig.animation_data.action:
            metarig.animation_data.action = None

        if metarig.animation_data:
            metarig.animation_data_clear()

        bpy.ops.object.mode_set(mode='OBJECT')
        metarig.location = [0,0,0]
        for bone in metarig.pose.bones:
            bone.matrix_basis = Matrix()

        #find color
        if self.color != "white":
            color = ["Root", "IK", "Special", "Tweak", "FK", "Extra"]

            for co in color:
                find = False
                for c in met_armature.rigify_colors:
                    if co == c.name:
                        find = True
                        break
                if not find:
                    if co == "root":
                        color_arm = met_armature.rigify_colors.add()
                        color_arm.name = "Root"
                        color_arm.active = Color((0.5490, 1.0000, 1.0000))
                        color_arm.normal = Color((0.4353, 0.1843, 0.4157))
                        color_arm.select = Color((0.3140, 0.7840, 1.0000))
                        color_arm.standard_colors_lock = True
                    if co == "IK":
                        color_arm = met_armature.rigify_colors.add()
                        color_arm.name = "IK"
                        color_arm.active = Color((0.5490, 1.0000, 1.0000))
                        color_arm.normal = Color((0.6039, 0.0000, 0.0000))
                        color_arm.select = Color((0.3140, 0.7840, 1.0000))
                        color_arm.standard_colors_lock = True
                    if co == "Special":
                        color_arm = met_armature.rigify_colors.add()
                        color_arm.name = "Special"
                        color_arm.active = Color((0.5490, 1.0000, 1.0000))
                        color_arm.normal = Color((0.9569, 0.7882, 0.0471))
                        color_arm.select = Color((0.3140, 0.7840, 1.0000))
                        color_arm.standard_colors_lock = True
                    if co == "Tweak":
                        color_arm = met_armature.rigify_colors.add()
                        color_arm.name = "Tweak"
                        color_arm.active = Color((0.5490, 1.0000, 1.0000))
                        color_arm.normal = Color((0.0392, 0.2118, 0.5804))
                        color_arm.select = Color((0.3140, 0.7840, 1.0000))
                        color_arm.standard_colors_lock = True
                    if co == "FK":
                        color_arm = met_armature.rigify_colors.add()
                        color_arm.name = "FK"
                        color_arm.active = Color((0.5490, 1.0000, 1.0000))
                        color_arm.normal = Color((0.1176, 0.5686, 0.0353))
                        color_arm.select = Color((0.3140, 0.7840, 1.0000))
                        color_arm.standard_colors_lock = True
                    if co == "Extra":
                        color_arm = met_armature.rigify_colors.add()
                        color_arm.name = "Extra"
                        color_arm.active = Color((0.5490, 1.0000, 1.0000))
                        color_arm.normal = Color((0.9686, 0.2510, 0.0941))
                        color_arm.select = Color((0.3140, 0.7840, 1.0000))
                        color_arm.standard_colors_lock = True
                
        armatures = ops.get_selected_obs(context)

        for src_object in armatures:
            if src_object == metarig:
                continue

            if src_object.type != 'ARMATURE':
                continue
            
            #test if its local
            if src_object.library is not None or src_object.data.library is not None:
                continue

            if not src_object.data.bones:
                continue

            src_settings = src_object.data.retarget_retarget

            if self.src_preset == '--Current--' and src_object.data.retarget_retarget.has_settings():
                if not src_settings.has_settings():
                    continue

                if src_settings.deform_preset and src_settings.deform_preset != '--':
                    deform_preset = src_settings.deform_preset
                    src_skeleton = preset_handler.get_preset_skel(deform_preset, src_settings)
                else:
                    src_skeleton = preset_handler.get_settings_skel(src_settings)

            else:
                src_skeleton = preset_handler.get_preset_skel(self.src_preset, src_settings)

                if src_skeleton and src_skeleton.deform_preset and src_skeleton.deform_preset != '--':
                    def_skeleton = preset_handler.get_preset_skel(src_skeleton.deform_preset, src_settings)
                    
                    if def_skeleton and def_skeleton.has_settings():
                        src_skeleton = def_skeleton

            if not src_skeleton:
                continue

            #preparation of the model
            if src_object.animation_data and src_object.animation_data.action:
                src_object.animation_data.action = None

            if src_object.animation_data:
                src_object.animation_data_clear()
            
            bpy.ops.object.mode_set(mode='OBJECT')
            src_object.location = [0,0,0]
            for bone in src_object.pose.bones:
                bone.matrix_basis = Matrix()

            context.view_layer.objects.active = src_object
            bpy.ops.object.mode_set(mode='POSE')

            src_armature = src_object.data

            if self.apply_transforms:
                
                bpy.ops.object.mode_set(mode='OBJECT')
                
                for o in armatures:
                    o.select_set(True, view_layer = context.view_layer)

                for ob in src_object.children_recursive:
                    ob.select_set(True)
                for ob in bone_utils.iterate_rigged_obs(src_object, context):
                    ob.select_set(True)

                src_object.select_set(True)
                context.view_layer.objects.active = src_object
                try:
                    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
                except:
                    pass

                bpy.ops.object.mode_set(mode='POSE')

                # rigged = (ob for ob in src_object.children_recursive)

                # for ob in rigged:
                #     if ob and ob.data:
                #         ob.data.transform(src_object.matrix_local)

                # src_armature.transform(src_object.matrix_local)
                # src_object.matrix_local = Matrix()

            if self.rigify_names:
                ConvertBoneNaming.rename_bones(src_object, src_skeleton, trg_skeleton)
                for bone in src_object.data.bones:
                    if bone.name in metarig.data.bones:
                        bone.name = "DEF-" + bone.name

            if self.fit_target:
                head = ''
                if self.search_option and self.head_bone in src_armature.bones:
                    head = self.head_bone
                elif trg_skeleton.spine.head and "DEF-" + trg_skeleton.spine.head in src_armature.bones:
                    head = "DEF-" + trg_skeleton.spine.head

                if head:
                    trg_head = head.removeprefix("DEF-")

                    try:
                        trg_bone = metarig.pose.bones[trg_head]
                        trg_height = (metarig.matrix_world @ trg_bone.bone.head_local)

                        ob_height = (src_object.matrix_world @ src_object.pose.bones[head].bone.head_local)
                        height_ratio = ob_height[2] / trg_height[2]
                        metarig.scale *= height_ratio

                        # Apply scale
                        bpy.ops.object.mode_set(mode='OBJECT')
                        context.view_layer.objects.active = metarig
                        bpy.ops.object.select_pattern( pattern=metarig.name, case_sensitive=True, extend=False)
                        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
                        for o in armatures:
                            o.select_set(True, view_layer = context.view_layer)
                        bpy.ops.object.mode_set(mode='POSE')
                    except:
                        pass

            dont_aligne_eye = self.dont_aligne_eye
            face_list = []
            if self.no_face:
                context.view_layer.objects.active = metarig
                bpy.ops.object.mode_set(mode='EDIT')

                if "face" in met_armature.bones:
                    rigify_face_bones = list()
                    for bone in met_armature.bones["face"].children_recursive:
                        rigify_face_bones.append(bone.name)
                    rigify_face_bones.append(met_armature.bones["face"].name)
                else:
                    #rigify_face_bones = bone_mapping.rigify_face_bones
                    rigify_face_bones = []

                for bone_name in rigify_face_bones:
                    if "DEF-" + bone_name in src_armature.bones:
                        if "eye" in bone_name:
                            dont_aligne_eye = False
                        bone = src_object.pose.bones["DEF-" + bone_name]
                        bone.rigify_type = "basic.super_copy"
                        continue
                    try:
                        face_bone = met_armature.edit_bones[bone_name]
                    except KeyError:
                        continue
                    face_list.append(face_bone)
                    #met_armature.edit_bones.remove(face_bone)

            otherbone = self.other_bone and self.rigify_names
            additional_bones = []
            if otherbone:

                list_deform = []
                if self.only_deform:
                    for child in src_object.children_recursive:
                        if child.type == "MESH":
                            for vert in child.vertex_groups:
                                if not vert.name in list_deform:
                                    list_deform.append(vert.name)

                root = src_object.pose.bones[0]
                for bone in src_object.pose.bones:
                    if root.name == bone.name:
                        continue

                    if self.only_deform:
                        if not bone.name in list_deform:
                            continue

                    if not bone.name.startswith("DEF-"):
                        bone.rigify_type = "basic.super_copy"

            additional_bones = [(b.name, b.rigify_type) for b in src_object.pose.bones if b.rigify_type]

            metarig.data.rigify_rig_basename = src_object.name
            metarig.data.rigify_target_rig = src_object

            context.view_layer.objects.active = metarig
            bpy.ops.object.mode_set(mode='EDIT')

            bone_to_aligne = dict()
            bone_to_aligne2 = dict()
            #bone aligned
            for bone in metarig.data.edit_bones:
                if not bone.parent or bone.use_connect:
                    continue
                parent = bone.parent
                if abs((parent.tail - bone.head).length) < 0.01:
                    bone_to_aligne[parent] = bone
                elif  abs((parent.head - bone.head).length) < 0.01:
                    bone_to_aligne2[parent] = bone

            for met_bone in metarig.data.edit_bones:
                if "eye" in met_bone.name and dont_aligne_eye:
                    continue

                try:
                    src_bone = src_object.data.bones.get("DEF-" + met_bone.name)
                except:
                    continue

                if not src_bone:
                    continue

                met_bone.head = src_bone.head_local
                met_bone.tail = src_bone.tail_local

                if met_bone.parent and met_bone.use_connect:
                    bone_dir = met_bone.vector.normalized()
                    parent_dir = met_bone.parent.vector.normalized()

                    if bone_dir.dot(parent_dir) < -0.6:
                        self.report({'WARNING'}, f"{met_bone.name} is not aligned with its parent")
                        # TODO

                try:
                    src_ed_bone = src_object.data.edit_bones("DEF-" + met_bone.name)
                    met_bone.roll = src_ed_bone.roll
                except:
                    src_x_axis = Vector((0.0, 0.0, 1.0)) @ src_bone.matrix_local.inverted().to_3x3()
                    src_x_axis.normalize()
                    met_bone.roll = bone_utils.ebone_roll_to_vector(met_bone, src_x_axis)

            #custom fix
            for bone in metarig.data.edit_bones:

                #offset bone
                try:
                    b = metarig.pose.bones.get(bone.name)
                    if b.rigify_type in ["limbs.arm", "limbs.leg", "limbs.paw"]:
                        if b.rigify_type == "limbs.leg":
                            offset_bone = - self.offset_bone
                        else:
                            offset_bone = self.offset_bone
                        offset = Vector((0.0, offset_bone, 0.0))
                        bone.tail += offset
                except:
                    pass

                if "heel" in bone.name and not bone.use_connect and bone.parent:

                    try:
                        src_bone = src_object.data.bones.get("DEF-" + bone.parent.name)
                    except:
                        continue

                    if not src_bone:
                        continue

                    # find foot vertices
                    foot_verts = {}
                    foot_ob = None
                    # pick object with most foot verts
                    for ob in bone_utils.iterate_rigged_obs(src_object, context):
                        if src_bone.name not in ob.vertex_groups:
                            continue
                        grouped_verts = bone_utils.get_group_verts(ob, src_bone.name, threshold=0.8)
                        if len(grouped_verts) > len(foot_verts):
                            foot_verts = grouped_verts
                            foot_ob = ob

                    if foot_verts:
                        # find rear verts (heel)
                        rearest_y = max([foot_ob.data.vertices[v].co[1] for v in foot_verts])
                        
                        heel_bone = bone

                        heel_bone.head.y = rearest_y
                        heel_bone.tail.y = rearest_y

                if "palm" in bone.name and bone.parent and not f'DEF-{bone.name}' in src_armature.bones:
                    try:
                        src_bone = src_object.data.bones.get("DEF-" + bone.parent.name)
                    except:
                        continue

                    if not src_bone:
                        continue

                    palm_bone = bone
                    palm_bone.tail = src_bone.head_local
                    hand_bone = palm_bone.parent
                    palm_bone.head = hand_bone.head * 0.75 + src_bone.head_local * 0.25
                    palm_bone.roll = 0

            # realign bone

            for parent, child in bone_to_aligne.items():
                parent.tail = child.head

            for parent, child in bone_to_aligne2.items():
                parent.head = child.head
            
            try:
                if 'spine.005' in met_armature.edit_bones and "DEF-spine.005" not in src_armature.bones:
                    met_armature.edit_bones['spine.005'].tail = (met_armature.edit_bones['spine.004'].tail + met_armature.edit_bones['spine.006'].tail) / 2
            except KeyError:
                pass
            #align again
            # for met_bone in metarig.data.edit_bones:
            #     try:
            #         src_bone = src_object.data.edit_bones.get("DEF-" + met_bone.name)
            #     except:
            #         continue

            #     if not src_bone:
            #         continue

            #     src_bone.head = met_bone.head
            #     src_bone.tail = met_bone.tail

            name_collect = "Other Bone" 

            try:
                ob_collection = met_armature.collections[name_collect]
            except KeyError:
                ob_collection = met_armature.collections.new(name_collect)
                ob_collection.is_visible = True
            other_bone_found = False

            for src_name, src_attr in additional_bones:

                new_bone_name = bone_utils.copy_bone_to_arm(src_object, metarig, src_name, suffix="")
                new_b = met_armature.edit_bones[new_bone_name]
                for coll in new_b.collections:
                    coll.unassign(new_b)
                other_bone_found = True
                ob_collection.assign(new_b)

                if 'chain' in src_attr:  # TODO: also fingers
                    # working around weird bug: sometimes src_armature.bones causes KeyError even if the bone is there
                    bone = next((b for b in src_armature.bones if b.name == src_name), None)

                    new_parent_name = new_bone_name
                    while bone:
                        # optional: use connect
                        try:
                            bone = bone.children[0]
                        except IndexError:
                            break

                        child_bone_name = bone_utils.copy_bone_to_arm(src_object, metarig, bone.name, suffix="")
                        child_bone = met_armature.edit_bones[child_bone_name]
                        child_bone.parent = met_armature.edit_bones[new_parent_name]
                        child_bone.use_connect = True

                        bone.name = f"DEF-{bone.name}"
                        new_parent_name = child_bone_name

                try:
                    bone = next((b for b in src_armature.bones if b.name == src_name), None)

                    if bone:
                        if bone.parent:
                            # FIXME: should use mapping to get parent bone name
                            parent_name = bone.parent.name.replace('DEF-', '')
                            met_armature.edit_bones[new_bone_name].parent = met_armature.edit_bones[parent_name]
                        if ".raw_" in src_attr:
                            met_armature.edit_bones[new_bone_name].use_deform = bone.use_deform
                        elif bone.name.startswith('DEF-'):
                            # already a DEF, need to strip that from metarig bone instead
                            met_armature.edit_bones[new_bone_name].name = new_bone_name.replace("DEF-", '')
                        else:
                            bone.name = f'DEF-{bone.name}'
                except KeyError:
                    self.report({'WARNING'}, "bones not found in target, perhaps wrong preset?")
                    continue

            if self.no_face:
                for bone in face_list:
                    try:
                        met_armature.edit_bones.remove(bone)
                    except:
                        pass

            bpy.ops.object.mode_set(mode='POSE')  

            if otherbone:
                #add other bone in interface
                if other_bone_found:
                    bpy.ops.armature.rigify_collection_add_ui_row(row=1, add=True)
                    bpy.ops.armature.rigify_collection_set_ui_row(index= ob_collection.index, row=1)

                    #set the color
                    if self.color != "white":

                        metarig.data.collections_all["Other Bone"].rigify_color_set_name = self.color

            # now we can copy the stored rigify attrs
            for src_name, src_attr in additional_bones:
                src_meta = src_name[4:] if src_name.startswith('DEF-') else src_name
                metarig.pose.bones[src_meta].rigify_type = src_attr

            #set the shape 
            metarig_bones = trg_skeleton.bone_names()
            for bone in metarig.pose.bones:
                if bone.name in ['eye.L', 'eye.R'] and bone.rigify_type == "basic.super_copy":
                    rig_params = bone.rigify_parameters
                    rig_params.super_copy_widget_type = self.bone_shape_eye

                if bone.name in metarig_bones:
                    continue
                if bone.rigify_type == "basic.super_copy":
                    rig_params = bone.rigify_parameters
                    rig_params.super_copy_widget_type = self.bone_shape
            

            metarig.parent = src_object.parent

            preset_handler.reset_setting(src_settings)


        bpy.ops.object.mode_set(mode= current_m)
        return {'FINISHED'}

class ActionRangeToScene(Operator):
    """Set Playback range to current action Start/End"""
    bl_idname = "object.retarget_action_to_range"
    bl_label = "Action Range to Scene"
    bl_description = "Match scene range with current action range"
    bl_options = {'REGISTER', 'UNDO'}

    _allowed_modes_ = ['POSE', 'OBJECT']

    @classmethod
    def poll(cls, context):
        obj = ops.get_ob_or_armature(context, context.active_object)

        if not obj:
            return False
        if obj.mode not in cls._allowed_modes_:
            return False
       
        return True

    def execute(self, context):
        ob = ops.get_ob_or_armature(context, context.active_object)

        if not ob:
            return {'FINISHED'}

        if not ob.animation_data:
            return {'FINISHED'}

        if not ob.animation_data.action:
            return {'FINISHED'}

        action_range = ob.animation_data.action.frame_range

        scn = context.scene
        scn.frame_start = int(action_range[0])
        scn.frame_end = int(action_range[1])
        scn.frame_set(int(action_range[0]))
        
        try:
            bpy.ops.action.view_all()
        except RuntimeError:
            # we are not in a timeline context, let's look for one in the screen
            for window in context.window_manager.windows:
                screen = window.screen
                for area in screen.areas:
                    if area.type == 'DOPESHEET_EDITOR':
                        for region in area.regions:
                            if region.type == 'WINDOW':
                                with context.temp_override(window=window,
                                                           area=area,
                                                           region=region):
                                    bpy.ops.action.view_all()
                                break
                        break
        return {'FINISHED'}


class ActionNlaRangeToScene(Operator):
    """Set Playback range to current action Start/End"""
    bl_idname = "object.retarget_action_nla_to_range"
    bl_label = "NLA Range to Scene"
    bl_description = "Match scene range with NLA range"
    bl_options = {'REGISTER', 'UNDO'}

    _allowed_modes_ = ['POSE', 'OBJECT']

    active_track: BoolProperty(name="Active Track", default=False)
    active_strip: BoolProperty(name="Active Strip", default=False)

    @classmethod
    def poll(cls, context):
        obj = ops.get_ob_or_armature(context, context.active_object)

        if not obj:
            return False
        if obj.mode not in cls._allowed_modes_:
            return False
       
        return True

    def execute(self, context):
        ob = ops.get_ob_or_armature(context, context.active_object)

        if not ob:
            return {'FINISHED'}

        if not ob.animation_data:
            return {'FINISHED'}
        
        frame_start = 0
        frame_end = 0

        first_strip = True

        if ob.animation_data and ob.animation_data.nla_tracks:
            for track in ob.animation_data.nla_tracks:
                if self.active_track and not self.active_strip and not track.active:
                    continue
                for strip in track.strips:
                    if self.active_strip and not strip.active:
                        continue
                    if first_strip:
                        frame_start = strip.frame_start
                        first_strip = False
                    else:
                        if frame_start > strip.frame_start:
                            frame_start = strip.frame_start
                        
                    if frame_end < strip.frame_end:
                        frame_end = strip.frame_end

        scn = context.scene
        scn.frame_start = int(frame_start)
        scn.frame_end = int(frame_end)
        scn.frame_set(int(frame_start))

        try:
            bpy.ops.anim.scene_range_frame()
        except RuntimeError:
            # we are not in a timeline context, let's look for one in the screen
            for window in context.window_manager.windows:
                screen = window.screen
                for area in screen.areas:
                    if area.type == 'NLA_EDITOR':
                        for region in area.regions:
                            if region.type == 'WINDOW':
                                with context.temp_override(window=window,
                                                           area=area,
                                                           region=region):
                                    bpy.ops.anim.scene_range_frame()
                                break
                        break
        return {'FINISHED'}


class MergeHeadTails(Operator):

    bl_idname = "armature.retarget_merge_head_tails"
    bl_label = "Merge Head/Tails"
    bl_description = "Connect (small bone) head/tails when closer than given max distance"
    bl_options = {'REGISTER', 'UNDO'}

    at_child_head: BoolProperty(
        name="Match at child head",
        description="Bring parent's tail to match child head when possible",
        default=True
    )

    min_distance: FloatProperty(
        name="Distance",
        description="Max Distance for merging",
        default=0.0
    )

    selected_only: BoolProperty(name="Only Selected",
                                default=False)
    
    def draw(self, context):
        layout = self.layout
        column = layout.column()

        #test if its local
        o = ops.get_ob_or_armature(context, context.active_object)
        if o.library is not None or o.data.library is not None:
            column.label(text=f"make '{o.name}' local", icon='ERROR')
            column.separator()


        #show number
        armatures = ops.get_selected_obs(context)
        num = 0
        for armature in armatures:

            if armature.type != 'ARMATURE':
                continue
            num += 1
        if num > 1:
            column.label(text=f"{num} Armatures Selected")
            column.separator()

        row = column.row()
        row.prop(self, "at_child_head")

        row = column.row()
        row.prop(self, "min_distance")

        row = column.row()
        row.prop(self, "selected_only")

    @classmethod
    def poll(cls, context):
        obj = ops.get_ob_or_armature(context, context.active_object)
        if not obj:
            return False

        if obj.type != 'ARMATURE':
            return False

        return True

    def execute(self, context):

        bake_up = list(context.selected_objects)

        #test if its local
        ob = ops.get_ob_or_armature(context, context.active_object)
        if ob.library is not None or ob.data.library is not None:
            return {'FINISHED'}

        current_m = context.mode
        actif =  context.active_object
        context.view_layer.objects.active = ob
        bpy.ops.object.mode_set(mode='EDIT')

        bones = []
        if self.selected_only:
            selected_names = [bone.name for bone in context.selected_bones]

            for obj in ops.get_selected_obs(context):
                if obj.type != 'ARMATURE':
                    continue
                #test if its local
                if obj.library is not None or obj.data.library is not None:
                    continue
                bones.extend([bone for bone in obj.data.edit_bones if bone.name in selected_names])
        else:
            for obj in ops.get_selected_obs(context):
                if obj.type != 'ARMATURE':
                    continue
                #test if its local
                if obj.library is not None or obj.data.library is not None:
                    continue
                bones.extend( obj.data.edit_bones)

        for bone in bones:
            if bone.use_connect:
                continue
            if not bone.parent:
                continue

            distance = (bone.parent.tail - bone.head).length
            if distance <= self.min_distance:
                if self.at_child_head and len(bone.parent.children) == 1:
                    bone.parent.tail = bone.head

                bone.use_connect = True

        for obj in ops.get_selected_obs(context):
            if obj.type != 'ARMATURE':
                    continue
            #test if its local
            if obj.library is not None or obj.data.library is not None:
                continue
            obj.update_from_editmode()

        bpy.ops.object.mode_set(mode=current_m)
        for o in bake_up:
            o.select_set(True, view_layer = context.view_layer)
        context.view_layer.objects.active = actif
        return {'FINISHED'}

"""
def mute_fcurves(obj: bpy.types.Object, channel_name: str):
    action = obj.animation_data.action
    if not action:
        return
    for slot in action.slots:
        if slot.target_id_type != 'OBJECT':
            continue
        if not (obj in slot.users() ):
            continue
        channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)

        for fc in channelbag.fcurves:
            if fc.data_path == channel_name:
                fc.mute = True

def limit_scale(obj):
    constr = obj.constraints.new('LIMIT_SCALE')

    constr.owner_space = 'LOCAL'
    constr.min_x = obj.scale[0]
    constr.min_y = obj.scale[1]
    constr.min_z = obj.scale[2]

    constr.max_x = obj.scale[0]
    constr.max_y = obj.scale[1]
    constr.max_z = obj.scale[2]

    constr.use_min_x = True
    constr.use_min_y = True
    constr.use_min_z = True

    constr.use_max_x = True
    constr.use_max_y = True
    constr.use_max_z = True
"""

class ConvertGameFriendly(Operator):
    """Convert Rigify rigs to a Game Friendly hierarchy (Select a Rigify Rig)"""
    bl_idname = "armature.retarget_convert_gamefriendly"
    bl_label = "Rigify Game Friendly"
    bl_description = "Make the rigify deformation bones a one root rig (Select a Rigify Armature)"
    bl_options = {'REGISTER', 'UNDO'}

    keep_backup: BoolProperty(
        name="Backup",
        description="Keep copy of datablock",
        default=True
    )
    rename: StringProperty(
        name="Rename",
        description="Rename rig to 'Armature'",
        default="Armature"
    )
    eye_bones: BoolProperty(
        name="Keep eye bones",
        description="Activate 'deform' for eye bones",
        default=True
    )
    limit_scale: BoolProperty(
        name="Limit Spine Scale",
        description="Limit scale on the spine deform bones",
        default=True
    )
    disable_bendy: BoolProperty(
        name="Disable B-Bones",
        description="Disable Bendy-Bones",
        default=True
    )
    fix_tail: BoolProperty(
        name="Invert Tail",
        description="Reverse the tail direction so that it spawns from hip",
        default=True
    )
    reparent_twist: BoolProperty(
        name="Dispossess Twist Bones",
        description="Rearrange Twist Hierarchy in limbs for in game IK",
        default=True
    )

    def draw(self, context):
        layout = self.layout
        column = layout.column()

        #test if its local
        o = ops.get_ob_or_armature(context, context.active_object)
        if o.library is not None or o.data.library is not None:
            column.label(text=f"make '{o.name}' local", icon='ERROR')
            column.separator()

        #show number
        armatures = ops.get_selected_obs(context)
        num = 0
        for armature in armatures:

            if armature.type != 'ARMATURE':
                continue
            num += 1
        if num > 1:
            column.label(text=f"{num} Armatures Selected")
            column.separator()

        row = column.row()
        row.prop(self, "keep_backup")

        row = column.row()
        row.prop(self, "rename")

        row = column.row()
        row.prop(self, "eye_bones")

        row = column.row()
        row.prop(self, "limit_scale")

        row = column.row()
        row.prop(self, "disable_bendy")

        row = column.row()
        row.prop(self, "fix_tail")

        row = column.row()
        row.prop(self, "reparent_twist")

    @classmethod
    def poll(cls, context):
        obj = ops.get_ob_or_armature(context, context.active_object)
        if not obj:
            return False
        if obj.type != 'ARMATURE':
            return False
        return bool(obj.data.get("rig_id"))

    def execute(self, context):

        o = ops.get_ob_or_armature(context, context.active_object)
        #test if its local
        if o.library is not None or o.data.library is not None:
            return {'FINISHED'}

        bake_up = list(context.selected_objects)
        
        actif =  context.active_object

        current_m = context.mode

        armatures = ops.get_selected_obs(context)
        for ob in armatures:

            if ob.type != 'ARMATURE':
                continue
            if not ob.data.get("rig_id"):
                continue
            #test if its local
            if ob.library is not None or ob.data.library is not None:
                continue

            context.view_layer.objects.active = ob
            bpy.ops.object.mode_set(mode='POSE')

            if self.keep_backup:
                backup_data = ob.data.copy()
                backup_data.name = ob.name + "_GameUnfriendly_backup"
                backup_data.use_fake_user = True

            if self.rename:
                ob.name = self.rename
                ob.data.name = self.rename

                try:
                    metarig = next(
                        obj for obj in context.scene.objects if obj.type == 'ARMATURE' and obj.data.rigify_target_rig == ob)
                except (StopIteration, AttributeError):  # Attribute Error if Rigify is not loaded
                    pass
                else:
                    try:
                        metarig.data.rigify_rig_basename = self.rename
                    except AttributeError:
                        # Removed in rigify 0.6.4
                        pass

            if self.eye_bones and 'DEF-eye.L' not in ob.pose.bones:
                # Old rigify face: eyes deform is disabled
                # FIXME: the 'DEF-eye.L' condition should be checked on invoke
                try:
                    # Oddly, changes to use_deform are not kept
                    ob.pose.bones["MCH-eye.L"].bone.use_deform = True
                    ob.pose.bones["MCH-eye.R"].bone.use_deform = True
                except KeyError:
                    pass

            bpy.ops.object.mode_set(mode='EDIT')
            num_reparents = bone_utils.gamefriendly_hierarchy(ob, fix_tail=self.fix_tail, limit_scale=self.limit_scale)

            if self.reparent_twist:
                arm_bones = ["DEF-upper_arm", "DEF-forearm", "DEF-hand"]
                leg_bones = ["DEF-thigh", "DEF-shin", "DEF-foot"]
                for side in ".L", ".R":
                    for bone_names in arm_bones, leg_bones:
                        parent_bone = ob.data.edit_bones[bone_names.pop(0) + side]
                        for bone in bone_names:
                            e_bone = ob.data.edit_bones[bone + side]
                            e_bone.use_connect = False

                            e_bone.parent = parent_bone
                            parent_bone = e_bone

                            num_reparents += 1

            bpy.ops.object.mode_set(mode='POSE')

            if self.disable_bendy:
                for bone in ob.data.bones:
                    bone.bbone_segments = 1
                    # TODO: disable bbone drivers

            self.report({'INFO'}, f'{num_reparents} bones were re-parented')

        bpy.ops.object.mode_set(mode= current_m)
        for o in bake_up:
            o.select_set(True, view_layer = context.view_layer)
        context.view_layer.objects.active = actif
        return {'FINISHED'}


class ConstrainToArmature(Operator):
    bl_idname = "armature.retarget_constrain_to_armature"
    bl_label = "Bind to Active Armature"
    bl_description = "Constrain bones of selected armatures to active armature (select at least 2 armatures)"
    bl_options = {'REGISTER', 'PRESET', 'UNDO'}

    same_bone_names: BoolProperty(name="Same Bone Names",
                                 description="When two armatures have the same bones names ",
                                 default=False)
    
    include_const: BoolProperty(name="",
                              description="Remove the location constraint",
                             default=False)

    motion_bones:  StringProperty(name = "",
                              description="Motion Bones List (Detect these bones to add or remove the location constraint)",
                              default="", options = {'SKIP_SAVE'})
    
    incl_child_b:  BoolProperty(name="",
                              description="Include All The Children",
                             default=True)

    clean_all:  BoolProperty(name="",
                              description="Delete All",
                             default=False, options = {'SKIP_SAVE'})

    clean_last:  BoolProperty(name="",
                              description="Delete the last one",
                              default=False, options = {'SKIP_SAVE'})

    motion_collection = dict()


    src_preset: EnumProperty(items=preset_handler.iterate_presets_with_current,
                             name="To Bind",
                             description="Source Armature"
                             )

    trg_preset: EnumProperty(items=preset_handler.iterate_presets_with_current,
                             name="Bind To",
                             description="Target Armature (Active Armature)"
                             )

    only_animated_Bone: BoolProperty(name="Only Animated Bone",
                               description="Bind only on Animated Bone (From Target Bones)",
                               default=False)

    only_selected: BoolProperty(name="Only Selected", default=False, description="Bind only selected bones (From Source Armature)")

    bind_by_name: BoolProperty(name="Bind bones by name",
                               description= "Look for bones present in both",
                               default=False)
    name_prefix: StringProperty(name="Add prefix to name",
                                description= "Add prefix to source bone name",
                                default="")
    name_replace: StringProperty(name="Replace in name",
                                  description= "Replace in source bone name",
                                 default="")
    name_replace_with: StringProperty(name="Replace in name with",
                                       description= "Replace with",
                                      default="")
    name_suffix: StringProperty(name="Add suffix to name",
                                 description= "Add suffix to source bone name",
                                default="")
    
    #bone influence

    bone_inf: BoolProperty(name="Bones",
                               description= "select between Bones",
                               default=False)
    
    include_bone: EnumProperty(items=[
        ('include', "Include", "Include Bones"),
        ('exclude', "Exclude", "Exclude Bones")
         ],
        name="",
        default='include')

    bone_sel: StringProperty(name = "",
                              description=" Bones List",
                              default="", options = {'SKIP_SAVE'})
    
    incl_child:  BoolProperty(name="",
                              description="Include All The Children",
                             default=True)

    clean_all_bone:  BoolProperty(name="",
                              description="Delete All",
                             default=False, options = {'SKIP_SAVE'})

    clean_last_bone:  BoolProperty(name="",
                              description="Delete the last one",
                              default=False, options = {'SKIP_SAVE'})

    bone_collection = dict()

    #limb
    limb: BoolProperty(name="Limb",
                               description= "select between Limb Bones",
                               default=False)
    
    include: EnumProperty(items=[
        ('include', "Include", "Include Bones"),
        ('exclude', "Exclude", "Exclude Bones")
         ],
        name="",
        default='include')

    limb_bones:  StringProperty(search=bone_utils.get_all_limb,
        name="", default="--",
        options = {'SKIP_SAVE'})

    clean_all_limb:  BoolProperty(name="",
                              description="Delete All",
                             default=False, options = {'SKIP_SAVE'})

    clean_last_limb:  BoolProperty(name="",
                              description="Delete the last one",
                              default=False, options = {'SKIP_SAVE'})

    limb_collection: StringProperty()

    #IK - FK
    hand_bone: EnumProperty(items=[
        ('ik', "IK", "only IK bones of the arm (From Source Armature)"),
        ('fk', "FK", "only FK bones of the arm  (From Source Armature)"),
        ('both', "Both", "default setting (From Source Armature)"),
         ],
        name="Arm",
        default='both')

    foot_bone: EnumProperty(items=[
        ('ik', "IK", "only IK bones of the leg (From Source Armature)"),
        ('fk', "FK", "only FK bone of the leg (From Source Armature)"),
        ('both', "Both", "default setting (From Source Armature)"),
         ],
        name="Leg",
        default='both')

    ik_fk_bone: EnumProperty(items=[
        ('ik', "IK", "only IK bones ( Bone that the name contain 'ik' )  (From Source Armature)"),
        ('fk', "FK", "only FK bone ( Bone that the name contain 'fk' )  (From Source Armature)"),
        ('both', "Both", "default setting  (From Source Armature)"),
         ],
        name="Bones",
        default='both')
    
    advance_setting: BoolProperty(name="",
                                description= "Advanced IK/FK Settings",
                                default=False)
    
    hand_fk_ik: BoolProperty(name="Arm: FK to IK",
                                description= "bind FK bones to IK bones for the Arm",
                                default=False)
        
    foot_fk_ik: BoolProperty(name="Leg: FK to IK",
                                description= "bind FK bones to IK bones for the Leg (This also corrects foot sliding)",
                                default=False)
    
    hand_ik_fk: BoolProperty(name="Arm: IK to FK",
                                description= "bind IK bones to FK bones for the Arm",
                                default=False)
        
    foot_ik_fk: BoolProperty(name="Leg: IK to FK",
                                description= "bind Ik bones to FK bones for the Leg",
                                default=False)
        
    #rigify setting
    hide_collect: BoolProperty(name="Automatically Hide The IK/FK Collection",
                                description= "Automatically hide the fk or ik collection (Rigify)",
                                default=False)

    rigify_hand:  FloatProperty(name="Arm IK-FK",
                         description="Arm IK/FK option from the source armture (Rigify) (0 for IK and 1 for FK)",
                         min=0, max=1,
                         default=0)

    rigify_foot:  FloatProperty(name="Leg IK-FK",
                         description="Leg IK/FK option from the source armture (Rigify) (0 for IK and 1 for FK)",
                         min=0, max=1,
                         default=0)

    Pole_bone_settings: BoolProperty(name="Pole bone",
                                description= "Pole bone settings (the Rigify naming convention must be complied)",
                                default=False)
    
    arm_pole: BoolProperty(name="Arm pole",
                                description= "Toggle pole on the arm (Rigify)",
                                default=True)
    
    leg_pole: BoolProperty(name="Leg pole",
                                description= "Toggle pole on the leg (Rigify)",
                                default=True)
    
    ret_bones_collection: StringProperty(name="Layer",
                                             default="Retarget Bones",
                                             description="Armature collection to use for connection bones (Usefull to ADD modification to the Animation)")
    #align limb
    align_limb: BoolProperty(name="Align By Limb",
                               description= "select between Limb Bones",
                               default=False)
    
    align_include: EnumProperty(items=[
        ('include', "Include", "Include Bones"),
        ('exclude', "Exclude", "Exclude Bones")
         ],
        name="",
        default='include')

    align_limb_bones:  StringProperty(search=bone_utils.get_all_limb,
        name="", default="--",
        options = {'SKIP_SAVE'})

    align_clean_all_limb:  BoolProperty(name="",
                              description="Delete All",
                             default=False, options = {'SKIP_SAVE'})

    align_clean_last_limb:  BoolProperty(name="",
                              description="Delete the last one",
                              default=False, options = {'SKIP_SAVE'})

    align_limb_collection: StringProperty()
    
    #other align
    align_rest_pose:  BoolProperty(name="Align rest pose",
                                description= "(This Aligns Only The Arm) [Experimental]",
                                default=False)
    
    # align_arm: BoolProperty(name="Align Arm",
    #                             description= "Align Arm",
    #                             default=False)
    
    align_leg: BoolProperty(name="",
                                description= "Align Leg [Experimental]",
                                default=False)

    match_transform: EnumProperty(items=[
        ('None', "- None -", "Don't match any transform"),
        ('Bone', "Bones Offset", "Account for difference between control and deform rest pose (Requires similar proportions and Y bone-axis)"),
        ('Pose', "Current Pose is target Rest Pose", "Armature was posed manually to match rest pose of target"),
        ('World', "Follow target Pose in world space", "Just copy target world positions (Same bone orient, different rest pose)"),
    ],
        name="Match Transform",
        default='None')

    match_object_transform: BoolProperty(name="Match Object Transform",
                                         description= "Reset The Position for best results.",
                                         default=True)
    
    center : BoolProperty(name="", description= "Reset The Position",
                                         default=True)
    
    apply_rotation : BoolProperty(name="", description= "Apply The rotation (Only when it's necessary)",
                                         default=True)
    
    math_look_at: BoolProperty(name="Fix direction",
                               description="Correct chain direction based on mid limb (Useful for IK)",
                               default=False)

    copy_IK_roll_hands: BoolProperty(name="Hands IK Roll",
                            description="USe IK target roll from source armature (Useful for IK) (Not recommended)",
                            default=False)

    copy_IK_roll_feet: BoolProperty(name="Feet IK Roll",
                            description="USe IK target roll from source armature (Useful for IK) (Not recommended)",
                            default=False)
    
    influence: FloatProperty(name="Influence", 
                              description="Influence of All Constraints",
                              min= 0, max= 1,
                              default=1)

    search_option: BoolProperty(name="Search",
                                description="Set The Head Bone Manually",
                                default=False)
    
    fit_target_scale: EnumProperty(name="Fit height",
                                   items=(('--', '- None -', 'None'),
                                          ('head', 'head', 'head'),
                                          ('neck', 'neck', 'neck'),
                                          ('spine2', 'chest', 'spine2'),
                                          ('spine1', 'spine1', 'spine1'),
                                          ('spine', 'spine', 'spine'),
                                          ('hips', 'hips', 'hips'),
                                          ),
                                    default='head',
                                    description="Fit height of the target Armature at selected bone")

    fit_target_scale_s: StringProperty(name="Fit height",
                            description="Fit height of the target Armature at selected bone",
                            default="")

    adjust_location: BoolProperty(default=False,
                                    description="scale location animation to avoid offset (will cause foot sliding)",
                                    name="Adjust location to new scale")

    constrain_root: EnumProperty(items=[
        ('None', "No Root", "Don't constrain root bone"),
        ('Default', "Default", "constrain root bone"),
        ('Bone', "Bone", "Constrain root to bone Manually"),
        ('Object', "Object", "Constrain root to object")
    ],
        name="Constrain Root",
        default='Default')


    loc_constraints: BoolProperty(name="Copy Location",
                                  description="Use Location Constraint when binding",
                                  default=False)

    rot_constraints: BoolProperty(name="Copy Rotation",
                                  description="Use Rotation Constraint when binding",
                                  default=True)
    
    fix_rot: BoolProperty(name="",
                                  description="fix rotation",
                                  default=False)

    scal_constraints:BoolProperty(name="Copy Scale",
                                  description="Use Scale Constraint when binding (_to be used only when they have the same scale )",
                                  default=False)

    constraint_policy: EnumProperty(items=[
        ('nothing', "Do Nothing", "Do Nothing"),
        ('skip', "Skip Existing Constraints", "Skip Bones that are constrained already"),
        ('disable', "Disable Existing Constraints", "Disable existing binding constraints and add new ones"),
        ('remove', "Delete Existing Constraints", "Delete existing binding constraints")
        ],
        name="Policy",
        description="Action to take with existing constraints",
        default='nothing'
        )

    bind_floating: BoolProperty(name="Bind Floating",
                                description="Always bind unparented bones Location and Rotation",
                                default=True)
    
    fix_foot:  BoolProperty(name="Fix Foot",
                                description="Fix Foot Sliding",
                                default=False)
    
    adv_loc:  BoolProperty(name="",
                                description="Advanced Location Constraint Setting",
                                default=False)
    
    root_motion_bone: StringProperty(name="Root Motion Target",
                                     description="Root Motion of the  Target Armature",
                                     default="")

    root_motion_bone_sr: StringProperty(name="Root Motion Source",
                                     description="Root Motion of the Source Armature",
                                     default="")
    
    keep_offset: BoolProperty(name="Keep Offset", default=False)
    keep_offset_value: FloatProperty(name="value", description="Keep Offset value", default=-1.0)

    root_cp_loc_x: BoolProperty(name="Root Copy Loc X", description="Copy Root X Location", default=True)
    root_cp_loc_y: BoolProperty(name="Root Copy Loc y", description="Copy Root Y Location", default=True)
    root_cp_loc_z: BoolProperty(name="Root Copy Loc Z", description="Copy Root Z Location", default=False)

    root_use_loc_min_x: BoolProperty(name="Use Root Min X", description="Use Minimum Root X Location", default=False)
    root_use_loc_min_y: BoolProperty(name="Use Root Min Y", description="Use Minimum Root Y Location", default=False)
    root_use_loc_min_z: BoolProperty(name="Use Root Min Z", description="Use Minimum Root Z Location", default=True)

    root_loc_min_x: FloatProperty(name="Root Min X", description="Minimum Root X Location", default=0.0)
    root_loc_min_y: FloatProperty(name="Root Min Y", description="Minimum Root Y Location", default=0.0)
    root_loc_min_z: FloatProperty(name="Root Min Z", description="Minimum Root Z Location", default=0.0)

    root_use_loc_max_x: BoolProperty(name="Use Root Max X", description="Use Maximum Root X Location", default=False)
    root_use_loc_max_y: BoolProperty(name="Use Root Max Y", description="Use Maximum Root Y Location", default=False)
    root_use_loc_max_z: BoolProperty(name="Use Root Max Z", description="Use Maximum Root Z Location", default=False)

    root_loc_max_x: FloatProperty(name="Root Max X", description="Maximum Root X Location", default=0.0)
    root_loc_max_y: FloatProperty(name="Root Max Y", description="Maximum Root Y Location", default=0.0)
    root_loc_max_z: FloatProperty(name="Root Max Z", description="Maximum Root Z Location", default=0.0)

    root_cp_rot_x: BoolProperty(name="Root Copy Rot X", description="Copy Root X Rotation", default=False)
    root_cp_rot_y: BoolProperty(name="Root Copy Rot y", description="Copy Root Y Rotation", default=False)
    root_cp_rot_z: BoolProperty(name="Root Copy Rot Z", description="Copy Root Z Rotation", default=False)

    root_cp_scal_x: BoolProperty(name="Root Copy Scal X", description="Copy Root X Scale", default=False)
    root_cp_scal_y: BoolProperty(name="Root Copy Scal y", description="Copy Root Y Scale", default=False)
    root_cp_scal_z: BoolProperty(name="Root Copy Scal Z", description="Copy Root Z Scale", default=False)


    no_finger_loc: BoolProperty(default=True, name="No FK Location",
                                description="Don't add Location Constraint on FK bones except the hips")

    force_dialog: BoolProperty(default=False, options={'HIDDEN', 'SKIP_SAVE'})

    _constrained_root = None

    _prop_indent = 0.15

    play: BoolProperty(name= "PLAY", default=True)

    action_range: BoolProperty(name= "Action Range to Scene",
                               description="Set Playback range to current action Start/End",
                               default=True)

    transfer_pose: BoolProperty(name= "Save The Pose",
                                description="Apply the Constrain and Delete Retarget Collection To save the Pose",
                                options={'SKIP_SAVE'},
                                default=False)
    custom_Frame: IntProperty(name="Frame", description="Select the Frame for {Save The Pose}", default=1)

    @property
    def _bind_constraints(self):
        constrs = []
        if self.loc_constraints:
            constrs.append('COPY_LOCATION')
        if self.rot_constraints:
            constrs.append('COPY_ROTATION')
        if self.scal_constraints:
            constrs.append('COPY_SCALE')

        return constrs

    #rigify setting
    def rigify_setting(self, ob):
        if ob.data.get("rig_id"):
            if "upper_arm_parent.R" in ob.pose.bones or \
                "upper_arm_parent.L" in ob.pose.bones or \
                "thigh_parent.R" in ob.pose.bones or \
                "thigh_parent.L" in ob.pose.bones:
                return True
        return False
    
    @classmethod
    def poll(cls, context):

        o = ops.get_ob_or_armature(context, context.active_object)

        if not o:
            return False
        if o.type != 'ARMATURE':
            return False

        if len(ops.get_selected_obs(context)) < 2:
            return False
        #At least 2 Armatures
        i = 0
        for ob in ops.get_selected_obs(context):
            if ob.type == 'ARMATURE':
                i = i + 1
            if i >= 2:
                return True
        return False

    current_m = None
    def invoke(self, context, event):

        self.current_m = context.mode

        o = ops.get_ob_or_armature(context, context.active_object)
        context.view_layer.objects.active = o

        #test if its local
        if o.library is not None or o.data.library is not None:
            if self.play and not context.screen.is_animation_playing:
                bpy.ops.screen.animation_play()
            return {'FINISHED'}

        bpy.ops.object.mode_set(mode='POSE')

        #init the custom_Frame
        self.custom_Frame = context.scene.frame_current

        # Set to use current Retarget settings if found
        to_bind = next(ob for ob in ops.get_selected_obs(context) if ob != o and ob.type == 'ARMATURE')

        if to_bind.data.retarget_retarget.has_settings():
            self.src_preset = '--Current--'

        else:
            self.src_preset = preset_handler.findPreset(to_bind)

        if o.data.retarget_retarget.has_settings():
            self.trg_preset = '--Current--'

        else:
            self.trg_preset = preset_handler.findPreset(o)

        if self.root_motion_bone and not self.root_motion_bone in o.pose.bones:
            self.root_motion_bone = ""

        if self.root_motion_bone_sr and not self.root_motion_bone_sr in to_bind.pose.bones:
            self.root_motion_bone_sr = ""

        if self.fit_target_scale_s and not self.fit_target_scale_s in to_bind.pose.bones:
            self.fit_target_scale_s = ""

        #rigify setting
        # if self.rigify_setting(to_bind):
        #     self.math_look_at = True
        #     # try:
        #     #     r_bone = to_bind.pose.bones["upper_arm_parent.R"]
        #     #     self.rigify_hand = r_bone["IK_FK"]
        #     #     r_bone = to_bind.pose.bones["thigh_parent.R"]
        #     #     self.rigify_foot = r_bone["IK_FK"]
        #     # except:
        #     #     pass
        # else:
        #     self.math_look_at = False
        if not self.rigify_setting(to_bind):
             self.math_look_at = False
        else:
            try:
                self.arm_pole = to_bind.pose.bones["upper_arm_parent.L"]["pole_vector"] and to_bind.pose.bones["upper_arm_parent.R"]["pole_vector"]
                self.leg_pole = to_bind.pose.bones["thigh_parent.L"]["pole_vector"] and to_bind.pose.bones["thigh_parent.R"]["pole_vector"]
                self.Pole_bone_settings = self.arm_pole or self.leg_pole
            except:
                pass


        if self.force_dialog:
            bpy.ops.object.mode_set(mode= self.current_m)
            return context.window_manager.invoke_props_dialog(self)

        return self.execute(context)
    

    def draw(self, context):

        layout = self.layout
        column = layout.column()

        #test if its local
        o = ops.get_ob_or_armature(context, context.active_object)
        if o.library is not None or o.data.library is not None:
            column.label(text=f"make '{o.name}' local", icon='ERROR')
            column.separator()

        row = column.row()
        row.prop(self, 'same_bone_names')

        if not self.same_bone_names:

            row = column.row()
            row.prop(self, 'src_preset', text="To Bind")

            row = column.row()
            row.prop(self, 'trg_preset', text="Bind To")

        if self.force_dialog:
            return

        sr_ob = None
        for ob in ops.get_selected_obs(context):
            if ob.type == 'ARMATURE' and ob != o:
                sr_ob = ob
                break

        column.separator()
        row = column.row()
        row.label(text='Conversion')

        row = column.split(factor=self._prop_indent, align=True)
        row.separator()

        col = row.column()
        if not self.same_bone_names:

            #align limb
            subcol = col.split(factor=0.80, align=True)
            subrow = subcol.row()
            subrow.prop(self, 'align_limb', text="", icon="SYNTAX_ON")

            if not self.align_limb:
                subrow.prop(self, 'align_rest_pose')
                subrow.prop(self, 'align_leg', toggle=True, icon='RESTRICT_COLOR_OFF')
            else:
                subrow.prop(self, 'align_include')

                row = col.split(factor=0.80, align=True)
                row.prop(self, 'align_limb_bones')
                row.prop(self, 'align_clean_all_limb', toggle=True, icon='PANEL_CLOSE')
                row.prop(self, 'align_clean_last_limb',toggle=True, icon='TRACKING_CLEAR_BACKWARDS')

                i = 0
                row = col.split(factor=0.33, align=True)

                align_limb_collection = self.align_limb_collection.split(":KBS:")

                for ik in align_limb_collection:
                    if not ik:
                        continue
                    if i == 3:
                        row = col.split(factor=0.33, align=True)
                        i = 0

                    row.label(text=ik, icon='OUTLINER_DATA_ARMATURE')

                    i += 1

        col.prop(self, 'match_transform', text='')

        subcol = col.split(factor=0.80, align=True)

        subcol.prop(self, 'match_object_transform')
        
        subcol.prop(self, 'center', toggle=True, icon='ORIENTATION_GLOBAL')

        subcol.prop(self, 'apply_rotation', toggle=True, icon='GESTURE_ROTATE')

        subrow = col.row()
        if not self.same_bone_names:
            subrow.prop(self, "search_option", text="", icon="SYNTAX_ON")

        if (self.same_bone_names or self.search_option) and sr_ob != None:
            subrow.prop_search(self, 'fit_target_scale_s',
                        sr_ob.data,
                        "bones", text="Fit height")

        else:
            subrow.prop(self, 'fit_target_scale')

        if (self.fit_target_scale != "--" and not self.same_bone_names) or ((self.same_bone_names or self.search_option) and self.fit_target_scale_s):
            col.prop(self, 'adjust_location')

        # if not self.loc_constraints and self.match_transform == 'Bone':
        #     col.label(text="'Copy Location' might be required", icon='ERROR')
        # elif ((self.fit_target_scale == '--' and not self.same_bone_names) or (self.same_bone_names and not self.fit_target_scale_s)) and self.match_transform == 'Pose':
        #     col.label(text="'Fit height' might improve results", icon='ERROR')
        # else:
        #     col.separator()

        column.separator()
        row = column.row()
        row.label(text='Constraints')

        row = column.row()
        row = column.split(factor=self._prop_indent, align=True)
        row.separator()

        constr_col = row.column()

        copy_loc_row = constr_col.row()
        copy_loc_row.prop(self, 'loc_constraints')
            
        if not self.same_bone_names and  not self.loc_constraints:
            copy_loc_row.prop(self, 'bind_floating')
            copy_loc_row = constr_col.row()

            if self.bind_floating:
                copy_loc_row.prop(self, 'no_finger_loc', text="Except FK bones")

            copy_loc_row.prop(self, 'fix_foot')
            copy_loc_row.prop(self, 'adv_loc', toggle=True, icon='DOWNARROW_HLT')

        if not self.same_bone_names and self.loc_constraints:
            copy_loc_row.prop(self, 'no_finger_loc', text="Except FK bones")
            copy_loc_row.prop(self, 'adv_loc', toggle=True, icon='DOWNARROW_HLT')


        if self.same_bone_names and not self.loc_constraints:
             copy_loc_row.prop(self, 'bind_floating')
             copy_loc_row.prop(self, 'adv_loc', toggle=True, icon='DOWNARROW_HLT')

        # advanced Location Setting
        if self.adv_loc:
            # row = column.split(factor=0.60, align=True)
            # row.label(text="")
            

            row = constr_col.split(factor=0.75, align=True)

            if sr_ob:
                row.prop_search(self, 'motion_bones',
                            sr_ob.data,
                            "bones")
                row.prop(self, 'include_const', toggle=True, icon='REMOVE')
                row.prop(self, 'incl_child_b', toggle=True, icon='OUTLINER_DATA_ARMATURE')
                row.prop(self, 'clean_all', toggle=True, icon='PANEL_CLOSE')
                row.prop(self, 'clean_last',toggle=True, icon='TRACKING_CLEAR_BACKWARDS')

            i = 0
            row = constr_col.split(factor=0.5, align=True)

            for k, v in self.motion_collection.items():
                if i == 2:
                    row = constr_col.split(factor=0.5, align=True)
                    i = 0

                if "REMV," in v and len(v) <= 2:
                    row.label(text=k, icon='REMOVE')

                elif "REMV," in v and len(v) > 2:
                    row.label(text=k, icon='POSE_HLT')

                elif len(v) > 1:
                    row.label(text=k, icon='OUTLINER_DATA_ARMATURE')

                else:
                    row.label(text=k, icon='BONE_DATA')

                i += 1

            constr_col.separator()
        #--------


        copy_rot_row = constr_col.row()
        copy_rot_row.prop(self, 'rot_constraints')

        if self.match_transform == 'World':
            copy_rot = copy_rot_row.split(factor=0.8, align=True)
            copy_rot.label(text="")
            copy_rot.prop(self, 'fix_rot', toggle=True, icon='GESTURE_ROTATE')

        copy_rot_row = constr_col.row()
        copy_rot_row.prop(self, 'scal_constraints')

        if not self.same_bone_names:
            copy_rot_row.prop(self, 'math_look_at')

        if not self.same_bone_names:
            ik_aim_row = constr_col.row()
            ik_aim_row.prop(self, 'copy_IK_roll_hands')
            ik_aim_row.prop(self, 'copy_IK_roll_feet')

        row = column.split(factor=self._prop_indent, align=True)
        constr_col.prop(self, 'constraint_policy', text='')

        row = column.split(factor=self._prop_indent, align=True)
        constr_col.prop(self, "influence")

        column.separator()
        row = column.row()
        row.label(text="Affect Bones")

        row = column.row()

        col = row.column()
        col.prop(self, 'only_animated_Bone')
        col = row.column()
        col.prop(self, 'only_selected')

        row = column.row()
        row.prop(self, 'bind_by_name', text="Also by Name")
        if self.bind_by_name:
            row = column.row()
            col = row.column()
            col.label(text="Prefix")
            col.prop(self, 'name_prefix', text="")

            col = row.column()
            col.label(text="Replace:")
            col.prop(self, 'name_replace', text="")

            col = row.column()
            col.label(text="With:")
            col.prop(self, 'name_replace_with', text="")

            col = row.column()
            col.label(text="Suffix:")
            col.prop(self, 'name_suffix', text="")

      
        #bone influence

        row = column.row()
        row.prop(self, 'bone_inf')

        if self.bone_inf:
            subcol = row.column()
            subcol.prop(self, 'include_bone')

            # row = column.row()
            # row.label(text="")

            if sr_ob:

                row = column.split(factor=0.80, align=True)

                row.prop_search(self, 'bone_sel',
                            sr_ob.data,
                            "bones")

                row.prop(self, 'incl_child', toggle=True, icon='OUTLINER_DATA_ARMATURE')
                row.prop(self, 'clean_all_bone', toggle=True, icon='PANEL_CLOSE')
                row.prop(self, 'clean_last_bone',toggle=True, icon='TRACKING_CLEAR_BACKWARDS')

                i = 0
                row = column.split(factor=0.33, align=True)

                for k, v in self.bone_collection.items():
                    if i == 3:
                        row = column.split(factor=0.33, align=True)
                        i = 0
                    if len(v) > 1:
                        row.label(text=k, icon='OUTLINER_DATA_ARMATURE')
                    else:
                        row.label(text=k, icon='BONE_DATA')

                    i += 1
        
        #limb
        if not self.same_bone_names:
            row = column.row()
            row.prop(self, 'limb')

            if self.limb:
                subcol = row.column()
                subcol.prop(self, 'include')

                # row = column.row()
                # row.label(text="")

                row = column.split(factor=0.80, align=True)
                row.prop(self, 'limb_bones')
                row.prop(self, 'clean_all_limb', toggle=True, icon='PANEL_CLOSE')
                row.prop(self, 'clean_last_limb',toggle=True, icon='TRACKING_CLEAR_BACKWARDS')

                i = 0
                row = column.split(factor=0.33, align=True)

                limb_collection = self.limb_collection.split(":KBS:")

                for ik in limb_collection:
                    if not ik:
                        continue
                    if i == 3:
                        row = column.split(factor=0.33, align=True)
                        i = 0

                    row.label(text=ik, icon='OUTLINER_DATA_ARMATURE')

                    i += 1
        
        #ik fk selection
        column.separator()
        row = column.row()
        row.label(text="IK / FK ")

        #advanced setting
        if not self.same_bone_names:
            subcolumn = row.split(factor=0.80, align=True)
            subcolumn.label(text="")
            subcolumn.prop(self, 'advance_setting', toggle=True, icon='VIEW_PAN')

        if not self.same_bone_names:
            row = column.row()
            col = row.column()
            col.prop(self, 'hand_bone')
            col = row.column()
            col.prop(self, 'foot_bone')

            #advanced setting

            if self.advance_setting:
                row = column.row()
                col = row.column()
                col.prop(self, 'hand_fk_ik')
                col = row.column()
                col.prop(self, 'foot_fk_ik')
                row = column.row()
                col = row.column()
                col.prop(self, 'hand_ik_fk')
                col = row.column()
                col.prop(self, 'foot_ik_fk')

        if self.same_bone_names:
            row = column.row()
            col = row.column()
            col.prop(self, 'ik_fk_bone')

        #rigify setting
        if sr_ob and self.rigify_setting(sr_ob):
            column.separator()
            row = column.row()
            row.label(text="Rigify Rig Setting")

            sub_col = row.split(factor=0.80, align=True)
            sub_col.label(text="")
            sub_col.prop(self, 'Pole_bone_settings', text='', toggle=True, icon='CON_ARMATURE')

            row = column.row()
            col = row.column()
            col.prop(self, 'hide_collect')

            row = column.row()
            col = row.column()
            col.prop(self, 'rigify_hand')
            col = row.column()
            col.prop(self, 'rigify_foot')

            if self.Pole_bone_settings:
                row = column.row()
                col = row.column()
                col.prop(self, 'arm_pole')
                col = row.column()
                col.prop(self, 'leg_pole')


        column.separator()
        row = column.row()
        row.label(text="Root Animation")
        row = column.split(factor=self._prop_indent, align=True)
        row.separator()
        row.prop(self, 'constrain_root', text="")

        if not (self.constrain_root == 'Default' or self.constrain_root == 'None'):

            if self.constrain_root != 'None' and self.constrain_root != 'Object' and sr_ob != None:
                row = column.split(factor=self._prop_indent, align=True)
                row.label(text="")
                row.prop_search(self, 'root_motion_bone_sr',
                                sr_ob.data,
                                "bones", text="")

            if self.constrain_root != 'None':
                row = column.split(factor=self._prop_indent, align=True)
                row.label(text="")
                row.prop_search(self, 'root_motion_bone',
                                o.data,
                                "bones", text="")

            if self.constrain_root != 'None':
                row = column.row(align=True)
                row.label(text="Location")
                row.prop(self, "root_cp_loc_x", text="X", toggle=True)
                row.prop(self, "root_cp_loc_y", text="Y", toggle=True)
                row.prop(self, "root_cp_loc_z", text="Z", toggle=True)

                if any((self.root_cp_loc_x, self.root_cp_loc_y, self.root_cp_loc_z)):
                    column.separator()

                    #keep offset
                    if self.root_cp_loc_z:

                        row = column.row(align=False)
                        row.prop(self, "keep_offset")
                        subcol = row.column()
                        subcol.prop(self, "keep_offset_value", text="")
                        subcol.enabled = self.keep_offset
                        row.separator()

                    # Min/Max X
                    if self.root_cp_loc_x:
                        row = column.row(align=True)
                        row.prop(self, "root_use_loc_min_x", text="Min X")

                        subcol = row.column()
                        subcol.prop(self, "root_loc_min_x", text="")
                        subcol.enabled = self.root_use_loc_min_x

                        row.separator()
                        row.prop(self, "root_use_loc_max_x", text="Max X")
                        subcol = row.column()
                        subcol.prop(self, "root_loc_max_x", text="")
                        subcol.enabled = self.root_use_loc_max_x
                        row.enabled = self.root_cp_loc_x

                    # Min/Max Y
                    if self.root_cp_loc_y:
                        row = column.row(align=True)
                        row.prop(self, "root_use_loc_min_y", text="Min Y")

                        subcol = row.column()
                        subcol.prop(self, "root_loc_min_y", text="")
                        subcol.enabled = self.root_use_loc_min_y

                        row.separator()
                        row.prop(self, "root_use_loc_max_y", text="Max Y")
                        subcol = row.column()
                        subcol.prop(self, "root_loc_max_y", text="")
                        subcol.enabled = self.root_use_loc_max_y
                        row.enabled = self.root_cp_loc_y

                    # Min/Max Z
                    if self.root_cp_loc_z:
                        row = column.row(align=True)
                        row.prop(self, "root_use_loc_min_z", text="Min Z")

                        subcol = row.column()
                        subcol.prop(self, "root_loc_min_z", text="")
                        subcol.enabled = self.root_use_loc_min_z

                        row.separator()
                        row.prop(self, "root_use_loc_max_z", text="Max Z")
                        subcol = row.column()
                        subcol.prop(self, "root_loc_max_z", text="")
                        subcol.enabled = self.root_use_loc_max_z
                        row.enabled = self.root_cp_loc_z

                    column.separator()

            row = column.row(align=True)
            row.label(text="Rotation")
            row.prop(self, "root_cp_rot_x", text="X", toggle=True)
            row.prop(self, "root_cp_rot_y", text="Y", toggle=True)
            row.prop(self, "root_cp_rot_z", text="Z", toggle=True)

            row = column.row(align=True)
            row.label(text="Scale")
            row.prop(self, "root_cp_scal_x", text="X", toggle=True)
            row.prop(self, "root_cp_scal_y", text="Y", toggle=True)
            row.prop(self, "root_cp_scal_z", text="Z", toggle=True)

        column.separator()
        row = column.row()
        row.prop(self, 'ret_bones_collection', text="Layer")

        row = column.split(factor=0.5, align=True)
        row.prop(self, "play", toggle=True, icon='PLAY')
        row.prop(self, "action_range", toggle=True, icon='PREVIEW_RANGE')

        row = column.split(factor=0.5, align=True)
        row.prop(self, "custom_Frame", text="Frame")
        row.prop(self, "transfer_pose", toggle=True, icon='ARMATURE_DATA')


    def _bone_bound_already(self, bone):
        if len (bone.constraints) > 0:
            return True
        return False

    def _add_limit_constraintss(self, ob, rot=True, loc=True, scale=False):
        limit_constraints = []
        if self.match_transform == 'Pose':
            return limit_constraints

        if rot:
            limit_rot = ob.constraints.new('LIMIT_ROTATION')
            limit_rot.use_limit_x = True
            limit_rot.use_limit_y = True
            limit_rot.use_limit_z = True

            limit_constraints.append(limit_rot)

        def limit_all(constr):
            constr.use_min_x = True
            constr.use_min_y = True
            constr.use_min_z = True
            constr.use_max_x = True
            constr.use_max_y = True
            constr.use_max_z = True

        if loc:
            limit_loc = ob.constraints.new('LIMIT_LOCATION')
            limit_all(limit_loc)
            limit_constraints.append(limit_loc)

        if scale:
            limit_scale = ob.constraints.new('LIMIT_SCALE')
            limit_scale.min_x = 1.0
            limit_scale.min_y = 1.0
            limit_scale.min_z = 1.0

            limit_scale.max_x = 1.0
            limit_scale.max_y = 1.0
            limit_scale.max_z = 1.0

            limit_all(limit_scale)
            limit_constraints.append(limit_scale)

        return limit_constraints

    def execute(self, context):

        # force_dialog limits drawn properties and is no longer required
        self.force_dialog = False

        bake_up = list(context.selected_objects)


        trg_ob = ops.get_ob_or_armature(context, context.active_object)
        context.view_layer.objects.active = trg_ob

        #test if its local
        if trg_ob.library is not None or trg_ob.data.library is not None:
            
            if self.play and not context.screen.is_animation_playing:
                bpy.ops.screen.animation_play()
            return {'FINISHED'}

        bpy.ops.object.mode_set(mode='POSE')

        if self.action_range and trg_ob.animation_data and trg_ob.animation_data.action:
            bpy.ops.object.retarget_action_to_range()

        if context.scene.frame_current != self.custom_Frame:
            context.scene.frame_set(self.custom_Frame)

        #// update value ik bones
        motion_collection_tp = []
        motion_collection_rmv = []

        if self.adv_loc:

            if self.clean_all:
                if len(self.motion_collection) > 0 :
                    self.motion_collection.clear()
                self.clean_all = False

            if self.clean_last:
                if len(self.motion_collection) > 0 :
                    self.motion_collection.popitem()
                self.clean_last = False

            if self.motion_bones:

                if not self.motion_bones in self.motion_collection.keys():

                    sr_ob = None
                    for ob in ops.get_selected_obs(context):
                        if ob.type == 'ARMATURE' and ob != trg_ob:
                            sr_ob = ob
                            break
                    if sr_ob:

                        list_bone = list()

                        bone = sr_ob.pose.bones[self.motion_bones]
                        list_bone.append(bone.name)

                        if self.incl_child_b:

                            for b in bone.bone.children_recursive:
                                list_bone.append(b.name)
                        
                        if self.include_const:
                            list_bone.append("REMV,")

                        self.motion_collection[self.motion_bones] = list_bone

                self.motion_bones = ""

            for v in self.motion_collection.values():

                if "REMV," in v:
                    motion_collection_rmv.extend(v)

                else:
                    motion_collection_tp.extend(v)

        if not self.same_bone_names:
            #limb
            if self.clean_all_limb:
                if self.limb_collection:
                    self.limb_collection = ''
                self.clean_all_limb = False

            if self.clean_last_limb:
                if len(self.limb_collection) > 0 :
                    limb_collection = self.limb_collection.split(":KBS:")
                    limb_collection.pop()
                    self.limb_collection = ":KBS:".join(limb_collection)
                self.clean_last_limb = False

            if self.limb_bones != "--":
                limb_collection = self.limb_collection.split(":KBS:")
                if not self.limb_bones in limb_collection:
                    self.limb_collection +=":KBS:" + self.limb_bones
                self.limb_bones = "--"

            #align limb
            if self.align_limb:
                if self.align_clean_all_limb:
                    if self.align_limb_collection:
                        self.align_limb_collection = ''
                    self.align_clean_all_limb = False

                if self.align_clean_last_limb:
                    if len(self.align_limb_collection) > 0 :
                        align_limb_collection = self.align_limb_collection.split(":KBS:")
                        align_limb_collection.pop()
                        self.align_limb_collection = ":KBS:".join(align_limb_collection)
                    self.align_clean_last_limb = False

                if self.align_limb_bones != "--":
                    align_limb_collection = self.align_limb_collection.split(":KBS:")
                    if not self.align_limb_bones in align_limb_collection:
                        self.align_limb_collection +=":KBS:" + self.align_limb_bones
                    self.align_limb_bones = "--"

        #bone influence
        if self.clean_all_bone:
            if len(self.bone_collection) > 0 :
                self.bone_collection.clear()
            self.clean_all_bone = False

        if self.clean_last_bone:
            if len(self.bone_collection) > 0 :
                self.bone_collection.popitem()
            self.clean_last_bone = False

        if self.bone_sel:

            if not self.bone_sel in self.bone_collection.keys():

                sr_ob = None
                for ob in ops.get_selected_obs(context):
                    if ob.type == 'ARMATURE' and ob != trg_ob:
                        sr_ob = ob
                        break
                if sr_ob:

                    list_bone = list()

                    bone = sr_ob.pose.bones[self.bone_sel]
                    list_bone.append(bone.name)

                    if self.incl_child:

                        for b in bone.bone.children_recursive:
                            list_bone.append(b.name)

                    self.bone_collection[self.bone_sel] = list_bone

            self.bone_sel = ""
        #----

        trg_skeleton = HumanSkeleton()
        trg_settings = trg_ob.data.retarget_retarget

        if not self.same_bone_names:

            if self.trg_preset == '--':
                bpy.ops.object.mode_set(mode=self.current_m)
                
                if self.play and not context.screen.is_animation_playing:
                    bpy.ops.screen.animation_play()
                return {'FINISHED'}

            if self.src_preset == '--':
                bpy.ops.object.mode_set(mode=self.current_m)
            
                if self.play and not context.screen.is_animation_playing:
                    bpy.ops.screen.animation_play()
                return {'FINISHED'}


            if self.trg_preset == '--Current--' and trg_ob.data.retarget_retarget.has_settings():
                trg_skeleton = preset_handler.get_settings_skel(trg_settings)
                
            else:
                trg_skeleton = preset_handler.set_preset_skel(self.trg_preset, context)

                if not trg_skeleton:
                    bpy.ops.object.mode_set(mode=self.current_m)
                    
                    if self.play and not context.screen.is_animation_playing:
                        bpy.ops.screen.animation_play()
                    return {'FINISHED'}

        prefix = ""

        
        if self.center:
            bpy.ops.object.mode_set(mode='OBJECT')
            trg_ob.location = [0,0,0]
            bpy.ops.object.mode_set(mode='POSE')

        armatures = ops.get_selected_obs(context)

        if self.apply_rotation:

            apply_rotation = True

            for ob in armatures:

                if ob.type != 'ARMATURE':
                    continue

                if ob.library is not None:
                    continue

                if ob.animation_data and ob.animation_data.action:
                    action = ob.animation_data.action

                    if ops.action_armature(action):

                        for slot in action.slots:

                            if slot.target_id_type != 'OBJECT' or not ops.slot_armature(action, slot):
                                continue

                            channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)
                            
                            if channelbag:
                                for fcurve in channelbag.fcurves:
                                    if fcurve.data_path in ["rotation_axis_angle", "rotation_quaternion", "rotation_euler"]:
                                        apply_rotation = False
                                        break
                            if not apply_rotation:
                                break
                            
                if not apply_rotation:
                    break
                else:
                    ob.select_set(True)

            try:
                if apply_rotation:                   
                    bpy.ops.object.mode_set(mode='OBJECT')
                    bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
                    bpy.ops.object.mode_set(mode='POSE')

            except:
                pass

        for ob in armatures:

            if ob == trg_ob:
                continue

            if ob.type != 'ARMATURE':
                continue

            if ob.library is not None:
                continue

            src_skeleton = HumanSkeleton()
            src_settings = ob.data.retarget_retarget

            if not self.same_bone_names:
                
                if self.src_preset == '--Current--' and ob.data.retarget_retarget.has_settings():
                    if not src_settings.has_settings():
                        continue
                   
                    src_skeleton = preset_handler.get_settings_skel(src_settings)

                else:
                    src_skeleton = preset_handler.get_preset_skel(self.src_preset, src_settings)

                if not src_skeleton:
                    continue

                root = src_skeleton.root

                #advanced setting
                if self.advance_setting:
                    trg_skeleton._hand_fk_as_ik = self.hand_ik_fk
                    trg_skeleton._foot_fk_as_ik = self.foot_ik_fk

            else:
                root = ""

            if self.center:
                bpy.ops.object.mode_set(mode='OBJECT')
                ob.location = [0,0,0]
                bpy.ops.object.mode_set(mode='POSE')                
               
            #bone influence
            list_bone_list = []
            if self.bone_inf:

                if self.bone_collection:

                    #list_bone_list = []
                    for b_list in self.bone_collection.values():
                        list_bone_list.extend(b_list)

                    # b_names = list(bone_names_map.keys())
                    # for key in b_names:

                    #     if key in list_bone_list:
                    #         if self.include_bone == 'exclude':
                    #             del bone_names_map[key]
                    #     else:
                    #         if self.include_bone == 'include':
                    #             del bone_names_map[key]


            #limb
            list_limb = []
            #store the property name to exclu
            other_bone_to_exclu = []
            bone_to_exclu = []

            if not self.same_bone_names:
                
                list_other_bone = []

                if self.limb:
                    other_bone_limb = bone_utils.get_limb_other_bone(src_settings)
                    limb_collection = self.limb_collection.split(":KBS:")
                    for limb in limb_collection:

                        if limb == "hips":
                            list_limb.append(src_skeleton.spine.hips)
                          
                        if limb in ('spine', 'left_arm', 'left_arm_ik', 'right_arm', 'right_arm_ik',
                                        'right_leg_ik','left_leg_ik'):
                            
                            setting = getattr(src_skeleton, limb)
                            for k in sorted(dir(setting)):
                                if k.startswith("__") or k in ["bl_rna", "type", "name"]:
                                    continue
                                try:
                                    if k not in ["super_copy", "shoulder", "hips", "head", "neck"]:
                                    #if not 'super_copy' in k and not "shoulder" in k and not "hips" in k:
                                        tmp = getattr(setting, k)
                                        
                                        list_limb.append(tmp)
                                except:
                                    continue

                        if limb == "right_leg":
                            list_limb.append(src_skeleton.right_leg.upleg)
                            list_limb.append(src_skeleton.right_leg.leg)

                        if limb == "left_leg":
                            list_limb.append(src_skeleton.left_leg.upleg)
                            list_limb.append(src_skeleton.left_leg.leg)

                        if limb == "right_foot":
                            list_limb.append(src_skeleton.right_leg.foot)
                            list_limb.append(src_skeleton.right_leg.toe)

                        if limb == "left_foot":
                            list_limb.append(src_skeleton.left_leg.foot)
                            list_limb.append(src_skeleton.left_leg.toe)

                        if limb == "head":
                            list_limb.append(src_skeleton.spine.neck)
                            list_limb.append(src_skeleton.spine.head)
                            setting = getattr(src_skeleton, "face")
                            for k in sorted(dir(setting)):
                                if k.startswith("__") or k in ["bl_rna", "type", "name"]:
                                    continue
                                try:
                                    #if not 'super_copy' in k and not "shoulder" in k and not "hips" in k:
                                    tmp = getattr(setting, k)
                                    list_limb.append(tmp)
                                except:
                                    continue

                        if limb == "RightShoulder":
                            list_limb.append(src_skeleton.right_arm.shoulder)
                            
                        if limb == "LeftShoulder":
                            list_limb.append(src_skeleton.left_arm.shoulder)

                        if limb == "left_fingers":
                            list_limb.extend(chain(*src_skeleton.left_fingers.values()))
                            
                        if limb == "right_fingers":
                            list_limb.extend(chain(*src_skeleton.right_fingers.values()))

                        if limb in other_bone_limb:
                            if src_settings.other_bone:
                                for item in src_settings.other_bone:
                                    if limb == item.limb:
                                        list_other_bone.append(item.name)

                                   

                    for item in src_settings.other_bone:
                    
                        if item.name in list_other_bone:
                            if self.include == 'exclude':
                                other_bone_to_exclu.append(item.name)
                                
                        else:
                            if self.include == 'include':
                                other_bone_to_exclu.append(item.name)

            # set between bone and limb options
            

            if list_bone_list or list_limb:

                for bone in ob.pose.bones:
                    
                    key = bone.name

                    if list_bone_list:

                        if key in list_bone_list:
                            if self.include_bone == 'exclude':
                                
                                # if list_limb and key in list_limb and self.include == 'include':
                                #     continue

                                # if list_limb and key not in list_limb and self.include == 'exclude':
                                #     continue


                                bone_to_exclu.append(key)
                                continue
                        else:
                            if self.include_bone == 'include':

                                if list_limb and key in list_limb and self.include == 'include':
                                    continue

                                # if list_limb and key not in list_limb and self.include == 'exclude':
                                #     continue

                                bone_to_exclu.append(key)
                                continue
                    
                    if list_limb:
                        
                        if key in list_limb:
                            if self.include == 'exclude':

                                # if list_bone_list and key in list_bone_list and self.include_bone == 'include':
                                #     continue

                                # if list_bone_list and key not in list_bone_list and self.include_bone == 'exclude':
                                #     continue

                                bone_to_exclu.append(key)
                        else:
                            if self.include == 'include':

                                if list_bone_list and key in list_bone_list and self.include_bone == 'include':
                                    continue

                                # if list_bone_list and key not in list_bone_list and self.include_bone == 'exclude':
                                #     continue

                                bone_to_exclu.append(key)
            
            bone_names_map = dict()

            src_arm_ik_bone = dict()
            src_fk_ik_bone = []

            if self.same_bone_names:

                def findBone(name, bones):

                    if name != "":

                        v = name
                        if ":" in name:
                            v = name.split(":")[-1]

                        for bone in bones:
                            if bone_utils.is_pose_bone_all_locked(bone):
                                continue
                            if v in bone.name:
                                return bone.name
                    return ""

                for bone in ob.pose.bones:

                    if bone_utils.is_pose_bone_all_locked(bone):
                        continue

                    if bone_to_exclu and bone.name in bone_to_exclu:
                        continue

                    name = ""
                    try:
                        pb = trg_ob.pose.bones[bone.name]
                        name = bone.name
                    except KeyError:
                        name = findBone(bone.name, trg_ob.pose.bones)
                        
                    if not name:
                        continue

                    bone_names_map[bone.name] = name
            else:
                
                bone_names_map = src_skeleton.conversion_map(trg_skeleton, bone_to_exclu = bone_to_exclu, other_bone_to_exclu = other_bone_to_exclu)
                
            #rigify setting
            if self.rigify_setting(ob):
                if self.Pole_bone_settings:
                    try:
                        ob.pose.bones["upper_arm_parent.L"]["pole_vector"] = self.arm_pole
                        ob.pose.bones["upper_arm_parent.R"]["pole_vector"] = self.arm_pole

                        if self.arm_pole:
                            if 'upper_arm_ik.L' in bone_names_map.keys() and src_skeleton.left_arm_ik.arm == 'upper_arm_ik.L':
                                v = bone_names_map['upper_arm_ik.L']
                                del bone_names_map['upper_arm_ik.L']
                                bone_names_map["upper_arm_ik_target.L"] = v
                                if not self.same_bone_names:
                                    src_skeleton.left_arm_ik.arm = 'upper_arm_ik_target.L'

                            if 'upper_arm_ik.R' in bone_names_map.keys() and src_skeleton.right_arm_ik.arm == 'upper_arm_ik.R':
                                v = bone_names_map['upper_arm_ik.R']
                                del bone_names_map['upper_arm_ik.R']
                                bone_names_map["upper_arm_ik_target.R"] = v
                                if not self.same_bone_names:
                                    src_skeleton.right_arm_ik.arm = 'upper_arm_ik_target.R'
                        else:
                            if 'upper_arm_ik_target.L' in bone_names_map.keys() and src_skeleton.left_arm_ik.arm == 'upper_arm_ik_target.L':
                                v = bone_names_map['upper_arm_ik_target.L']
                                del bone_names_map['upper_arm_ik_target.L']
                                bone_names_map["upper_arm_ik.L"] = v
                                if not self.same_bone_names:
                                    src_skeleton.left_arm_ik.arm = 'upper_arm_ik.L'
                            if 'upper_arm_ik_target.R' in bone_names_map.keys() and src_skeleton.right_arm_ik.arm == 'upper_arm_ik_target.R':
                                v = bone_names_map['upper_arm_ik_target.R']
                                del bone_names_map['upper_arm_ik_target.R']
                                bone_names_map["upper_arm_ik.R"] = v
                                if not self.same_bone_names:
                                    src_skeleton.right_arm_ik.arm = 'upper_arm_ik.R'

                        ob.pose.bones["thigh_parent.L"]["pole_vector"] = self.leg_pole
                        ob.pose.bones["thigh_parent.R"]["pole_vector"] = self.leg_pole

                        if self.leg_pole:
                            if 'thigh_ik.L' in bone_names_map.keys() and src_skeleton.left_leg_ik.upleg == 'thigh_ik.L':
                                v = bone_names_map['thigh_ik.L']
                                del bone_names_map['thigh_ik.L']
                                bone_names_map['thigh_ik_target.L'] = v
                                if not self.same_bone_names:
                                    src_skeleton.left_leg_ik.upleg = 'thigh_ik_target.L'
                            if 'thigh_ik.R' in bone_names_map.keys() and src_skeleton.right_leg_ik.upleg == 'thigh_ik.R':
                                v = bone_names_map['thigh_ik.R']
                                del bone_names_map['thigh_ik.R']
                                bone_names_map['thigh_ik_target.R'] = v
                                if not self.same_bone_names:
                                    src_skeleton.right_leg_ik.upleg = 'thigh_ik_target.R'
                        else:
                            if 'thigh_ik_target.L' in bone_names_map.keys() and src_skeleton.left_leg_ik.upleg == 'thigh_ik_target.L':
                                v = bone_names_map['thigh_ik_target.L']
                                del bone_names_map['thigh_ik_target.L']
                                bone_names_map['thigh_ik.L'] = v
                                if not self.same_bone_names:
                                    src_skeleton.left_leg_ik.upleg = 'thigh_ik.L'
                            if 'thigh_ik_target.R' in bone_names_map.keys() and src_skeleton.right_leg_ik.upleg == 'thigh_ik_target.R':
                                v = bone_names_map['thigh_ik_target.R']
                                del bone_names_map['thigh_ik_target.R']
                                bone_names_map['thigh_ik.R'] = v
                                if not self.same_bone_names:
                                    src_skeleton.right_leg_ik.upleg = 'thigh_ik.R'

                    except:
                        pass

            if not self.same_bone_names:

                for item in src_settings.other_bone:

                    #pole or arm ik
                    if item.bone_name in bone_names_map.keys() and item.ik and item.target:
                        trg_item = None
                        
                        for it in trg_settings.other_bone:
                            if it.name == item.name:
                                trg_item = it
                                break
                        
                        if trg_item and trg_item.ik and trg_item.target:
                            if item.target not in bone_to_exclu:
                                bone_names_map[item.target] = trg_item.target

                        else:
                            trg_name = bone_names_map[item.bone_name]
                            trg_bone = trg_ob.pose.bones.get(trg_name)
                            if trg_bone and trg_bone.parent:
                                src_arm_ik_bone[item.target] = trg_bone.parent.name

                                if trg_bone.parent.parent:
                                    if item.target not in bone_to_exclu:
                                        bone_names_map[item.target] = trg_bone.parent.parent.name

                    #special fk other bone
                    elif item.bone_name in bone_names_map.keys() and not item.ik:
                        trg_item = None
                        for it in trg_settings.other_bone:
                            if it.name == item.name:
                                trg_item = it
                                break
                        if trg_item and trg_item.ik and trg_item.target:
                            ob_bone = ob.pose.bones.get(item.bone_name)
                            if ob_bone and ob_bone.parent:
                                if ob_bone.parent.name not in bone_to_exclu:
                                    bone_names_map[ob_bone.parent.name] = trg_item.bone_name
                                    src_fk_ik_bone.append(ob_bone.parent.name)

                                if ob_bone.parent.parent:
                                    if ob_bone.parent.parent.name not in bone_to_exclu:
                                        bone_names_map[ob_bone.parent.parent.name] = trg_item.target                                
                
            fit_scale = False

            trg_height = []

            if (self.same_bone_names or self.search_option):

                if self.fit_target_scale_s:
                    try:
                        trg_head = bone_names_map[self.fit_target_scale_s]
                        trg_bone = trg_ob.pose.bones[trg_head]
                    except KeyError:
                        pass
                    else:
                        fit_scale = True
                        trg_height = (trg_ob.matrix_world @ trg_bone.bone.head_local)
            else:

                if self.fit_target_scale != '--':

                    try:
                        trg_bone = trg_ob.pose.bones[getattr(trg_skeleton.spine, self.fit_target_scale)]
                    except KeyError:
                        pass
                    else:
                        fit_scale = True
                        trg_height = (trg_ob.matrix_world @ trg_bone.bone.head_local)

            if fit_scale:

                try:
                    if (self.same_bone_names or self.search_option):
                        ob_height = (ob.matrix_world @ ob.pose.bones[self.fit_target_scale_s].bone.head_local)
                    else:
                        ob_height = (ob.matrix_world @ ob.pose.bones[getattr(src_skeleton.spine, self.fit_target_scale)].bone.head_local)
                    height_ratio = ob_height[2] / trg_height[2]

                    #mute_fcurves(trg_ob, 'scale')
                    trg_ob.scale *= height_ratio
                    #limit_scale(trg_ob)

                    if self.adjust_location:
                        # scale location animation to avoid offset
                        trg_action = trg_ob.animation_data.action
                        if trg_action:
                            for slot in trg_action.slots:

                                if slot.target_id_type != 'OBJECT':
                                    continue
                                if not  (trg_ob in slot.users() ):
                                    continue

                                channelbag = anim_utils.action_get_channelbag_for_slot(trg_action, slot)
                                #TODO: i need to check this
                                if not (trg_ob in slot.users() ):
                                    continue
                                for fc in channelbag.fcurves:
                                    data_path = fc.data_path

                                    if not data_path.endswith('location'):
                                        continue

                                    for kf in fc.keyframe_points:
                                        kf.co[1] /= height_ratio
                except KeyError:
                    pass

            if not self.same_bone_names:
                
                def_skeleton = preset_handler.get_preset_skel(src_settings.deform_preset)
                
                if def_skeleton and def_skeleton.has_settings():
                    deformation_map = src_skeleton.conversion_map(def_skeleton)
                else:
                    deformation_map = None
            else:
                deformation_map = None

            if self.bind_by_name:
                # Look for bones present in both
                for bone in ob.pose.bones:
                    bone_name = bone.name
                    bone_look_up = self.name_prefix + bone_name.replace(self.name_replace, self.name_replace_with) + self.name_suffix

                    if bone_look_up in bone_names_map:
                        continue
                    if bone_utils.is_pose_bone_all_locked(bone):
                        continue
                    if bone_look_up in trg_ob.pose.bones:
                        bone_names_map[bone_name] = bone_look_up

            look_ats = {}
            

            # only_animated_Bone -------------------------------
            trg_action = trg_ob.animation_data.action if trg_ob.animation_data and trg_ob.animation_data.action else None
            channelbag = None
            if trg_action:
                for slot in trg_action.slots:

                    if slot.target_id_type != 'OBJECT':
                        continue
                    if not  (trg_ob in slot.users() ):
                        continue
                    channelbag = anim_utils.action_get_channelbag_for_slot(trg_action, slot)
                    break

            if self.only_animated_Bone:
                if channelbag:

                    to_del = []
                    for key_b_name, b_name in bone_names_map.items():
                        if not key_b_name:
                            continue

                        if not b_name in channelbag.groups:
                            to_del.append(key_b_name)


                    for name in to_del:
                        del bone_names_map[name]

                else:
                    bone_names_map.clear()
            #--------------

            #Only selected
            if self.only_selected:
                b_names = list(bone_names_map.keys())
                for b_name in b_names:
                    if not b_name:
                        continue
                    try:
                        bone = ob.pose.bones[b_name]
                    except KeyError:
                        continue

                    if not bone.select:

                        del bone_names_map[b_name]

            

            #hand/foot ik/fk
            if not self.same_bone_names:

                if self.hand_bone != "both":

                    exclu = []
                    for group in ('left_arm', 'right_arm'):
                        setting = getattr(src_skeleton, group)
                        for k in sorted(dir(setting)):
                            if k.startswith("__") or k in ["bl_rna", "type", "name"]:
                                continue
                            b_name = str(getattr(setting, k))
                            exclu.append(b_name)
                            #dont remove the shoulder
                            if k == "shoulder" or "twist" in k:
                                continue
                            if self.hand_bone == "ik":

                                if b_name in bone_names_map.keys():
                                    del bone_names_map[b_name]

                    if self.hand_bone == "fk":
                        for group in ('left_arm_ik', 'right_arm_ik'):
                            setting = getattr(src_skeleton, group)
                            for k in sorted(dir(setting)):
                                if k.startswith("__") or k in ["bl_rna", "type", "name"]:
                                    continue
                                b_name = str(getattr(setting, k))
                                if b_name not in exclu and b_name in bone_names_map.keys():
                                    del bone_names_map[b_name]


                if self.foot_bone != "both":
                    exclu = []

                    for group in ('left_leg', 'right_leg'):
                        setting = getattr(src_skeleton, group)
                        for k in sorted(dir(setting)):
                            if k.startswith("__") or k in ["bl_rna", "type", "name"]:
                                continue
                            b_name = str(getattr(setting, k))
                            exclu.append(b_name)

                            if "twist" in k:
                                continue

                            if self.foot_bone == "ik":

                                if b_name in bone_names_map.keys():
                                    del bone_names_map[b_name]


                    if self.foot_bone == "fk":
                        for group in ('left_leg_ik', 'right_leg_ik'):
                            setting = getattr(src_skeleton, group)
                            for k in sorted(dir(setting)):
                                if k.startswith("__") or k in ["bl_rna", "type", "name"]:
                                    continue
                                b_name = str(getattr(setting, k))

                                if b_name not in exclu and b_name in bone_names_map.keys():
                                    del bone_names_map[b_name]

                #advanced setting
                if self.advance_setting:

                    if self.hand_fk_ik:
                        #left arm
                        fk_map = dict()
                        
                        setting = getattr(src_skeleton, 'left_arm')
                        for k in sorted(dir(setting)):
                            if k.startswith("__") or k in ["bl_rna", "type", "name", "shoulder"]:
                                continue
                            b_name = str(getattr(setting, k))
                            if b_name in bone_names_map.keys():
                                fk_map[k] = b_name

                        ik_map = dict()

                        setting = getattr(trg_skeleton, 'left_arm_ik')
                        for k in sorted(dir(setting)):
                            if k.startswith("__") or k in ["bl_rna", "type", "name", "shoulder"]:
                                continue
                            b_name = str(getattr(setting, k))
                            #if b_name in bone_names_map.values():
                            ik_map[k] = b_name

                        #invert
                        for key, value in fk_map.items():
                            if key in ik_map.keys():
                                if key == "forearm":
                                    if "hand" in ik_map.keys():
                                        bone_names_map[value] = ik_map["hand"]
                                else:
                                    bone_names_map[value] = ik_map[key]
                         #right arm
                        fk_map = dict()

                        setting = getattr(src_skeleton, 'right_arm')
                        for k in sorted(dir(setting)):
                            if k.startswith("__") or k in ["bl_rna", "type", "name", "shoulder"]:
                                continue
                            b_name = str(getattr(setting, k))
                            if b_name in bone_names_map.keys():
                                fk_map[k] = b_name

                        ik_map = dict()

                        setting = getattr(trg_skeleton, 'right_arm_ik')
                        for k in sorted(dir(setting)):
                            if k.startswith("__") or k in ["bl_rna", "type", "name", "shoulder"]:
                                continue
                            b_name = str(getattr(setting, k))
                            #if b_name in bone_names_map.values():
                            ik_map[k] = b_name

                        #invert
                        for key, value in fk_map.items():
                            if key in ik_map.keys():
                                if key == "forearm":
                                    if "hand" in ik_map.keys():
                                        bone_names_map[value] = ik_map["hand"]
                                else:
                                    bone_names_map[value] = ik_map[key]

                    if self.foot_fk_ik:
                        #left arm
                        fk_map = dict()
                        
                        setting = getattr(src_skeleton, 'left_leg')
                        for k in sorted(dir(setting)):
                            if k.startswith("__") or k in ["bl_rna", "type", "name"]:
                                continue
                            b_name = str(getattr(setting, k))
                            if b_name in bone_names_map.keys():
                                fk_map[k] = b_name

                        ik_map = dict()

                        setting = getattr(trg_skeleton, 'left_leg_ik')
                        for k in sorted(dir(setting)):
                            if k.startswith("__") or k in ["bl_rna", "type", "name"]:
                                continue
                            b_name = str(getattr(setting, k))
                            #if b_name in bone_names_map.values():
                            ik_map[k] = b_name

                        #invert
                        for key, value in fk_map.items():
                            if key in ik_map.keys():
                                if key == "leg":
                                    if "foot" in ik_map.keys():
                                        bone_names_map[value] = ik_map["foot"]
                                else:
                                    bone_names_map[value] = ik_map[key]
                         #right arm
                        fk_map = dict()

                        setting = getattr(src_skeleton, 'right_leg')
                        for k in sorted(dir(setting)):
                            if k.startswith("__") or k in ["bl_rna", "type", "name"]:
                                continue
                            b_name = str(getattr(setting, k))
                            if b_name in bone_names_map.keys():
                                fk_map[k] = b_name

                        ik_map = dict()

                        setting = getattr(trg_skeleton, 'right_leg_ik')
                        for k in sorted(dir(setting)):
                            if k.startswith("__") or k in ["bl_rna", "type", "name"]:
                                continue
                            b_name = str(getattr(setting, k))
                            #if b_name in bone_names_map.values():
                            ik_map[k] = b_name

                        #invert
                        for key, value in fk_map.items():
                            if key in ik_map.keys():
                                if key == "leg":
                                    if "foot" in ik_map.keys():
                                        bone_names_map[value] = ik_map["foot"]
                                else:
                                    bone_names_map[value] = ik_map[key]

            # ik - Fk option for same_bone_names
            if self.same_bone_names and self.ik_fk_bone != "both":

                if self.ik_fk_bone == "ik":
                    list_bname  = list(bone_names_map.keys())
                    for key in list_bname:
                        if "fk" in key.lower():
                            del bone_names_map[key]


                if self.ik_fk_bone == "fk":
                    list_bname  = list(bone_names_map.keys())
                    for key in list_bname:
                        if "ik" in key.lower():
                            del bone_names_map[key]

            #rigify setting
            if self.rigify_setting(ob):
                try:
                    r_bone = ob.pose.bones["upper_arm_parent.R"]
                    r_bone["IK_FK"] = self.rigify_hand

                    if self.hide_collect:
                        if self.rigify_hand == 0:
                            ob.data.collections_all["Arm.R (FK)"].is_visible = False
                            ob.data.collections_all["Arm.R (IK)"].is_visible = True
                        elif self.rigify_hand == 1:
                            ob.data.collections_all["Arm.R (FK)"].is_visible = True
                            ob.data.collections_all["Arm.R (IK)"].is_visible = False
                        else:
                            ob.data.collections_all["Arm.R (FK)"].is_visible = True
                            ob.data.collections_all["Arm.R (IK)"].is_visible = True

                except:
                    pass
                try:
                    r_bone = ob.pose.bones["upper_arm_parent.L"]
                    r_bone["IK_FK"] = self.rigify_hand

                    if self.hide_collect:
                        if self.rigify_hand == 0:
                            ob.data.collections_all["Arm.L (FK)"].is_visible = False
                            ob.data.collections_all["Arm.L (IK)"].is_visible = True
                        elif self.rigify_hand == 1:
                            ob.data.collections_all["Arm.L (FK)"].is_visible = True
                            ob.data.collections_all["Arm.L (IK)"].is_visible = False
                        else:
                            ob.data.collections_all["Arm.L (FK)"].is_visible = True
                            ob.data.collections_all["Arm.L (IK)"].is_visible = True
                except:
                    pass
                try:
                    r_bone = ob.pose.bones["thigh_parent.R"]
                    r_bone["IK_FK"] = self.rigify_foot

                    if self.hide_collect:
                        if self.rigify_foot == 0:
                            ob.data.collections_all["Leg.R (FK)"].is_visible = False
                            ob.data.collections_all["Leg.R (IK)"].is_visible = True
                        elif self.rigify_foot == 1:
                            ob.data.collections_all["Leg.R (FK)"].is_visible = True
                            ob.data.collections_all["Leg.R (IK)"].is_visible = False
                        else:
                            ob.data.collections_all["Leg.R (FK)"].is_visible = True
                            ob.data.collections_all["Leg.R (IK)"].is_visible = True
                except:
                    pass
                try:
                    r_bone = ob.pose.bones["thigh_parent.L"]
                    r_bone["IK_FK"] = self.rigify_foot

                    if self.hide_collect:
                        if self.rigify_foot == 0:
                            ob.data.collections_all["Leg.L (FK)"].is_visible = False
                            ob.data.collections_all["Leg.L (IK)"].is_visible = True
                        elif self.rigify_foot == 1:
                            ob.data.collections_all["Leg.L (FK)"].is_visible = True
                            ob.data.collections_all["Leg.L (IK)"].is_visible = False
                        else:
                            ob.data.collections_all["Leg.L (FK)"].is_visible = True
                            ob.data.collections_all["Leg.L (IK)"].is_visible = True
                except:
                    pass

                            #root setting
            self._constrained_root = None

            if self.constrain_root == 'None':

                if not self.same_bone_names:
                    try:
                        del bone_names_map[root]
                    except KeyError:
                        pass


            elif self.constrain_root == 'Bone':

                if self.root_motion_bone_sr:
                    root = self.root_motion_bone_sr

                bone_names_map[root] = self.root_motion_bone

            #align rest pose
            align_list = []

            if not self.same_bone_names and self.align_limb and self.align_limb_collection:

                other_bone_limb = bone_utils.get_limb_other_bone(src_settings)
                tmp_limb_list = []

                align_limb_collection = self.align_limb_collection.split(":KBS:")

                for limb in align_limb_collection:

                    if limb == "hips":
                        tmp_limb_list.append(src_skeleton.spine.hips)
                        
                    if limb in ('spine', 'left_arm', 'left_arm_ik', 'right_arm', 'right_arm_ik',
                                    'right_leg_ik', 'left_leg_ik'):
                        
                        setting = getattr(src_skeleton, limb)
                        for k in sorted(dir(setting)):
                            if k.startswith("__") or k in ["bl_rna", "type", "name"]:
                                continue
                            try:
                                if k not in ["super_copy", "shoulder", "hips", "head", "neck"]:
                                #if not 'super_copy' in k and not "shoulder" in k and not "hips" in k:
                                    tmp = getattr(setting, k)
                                    
                                    tmp_limb_list.append(tmp)
                            except:
                                continue

                    if limb == "right_leg":
                        tmp_limb_list.append(src_skeleton.right_leg.upleg)
                        tmp_limb_list.append(src_skeleton.right_leg.leg)

                    if limb == "left_leg":
                        tmp_limb_list.append(src_skeleton.left_leg.upleg)
                        tmp_limb_list.append(src_skeleton.left_leg.leg)

                    if limb == "right_foot":
                        tmp_limb_list.append(src_skeleton.right_leg.foot)
                        tmp_limb_list.append(src_skeleton.right_leg.toe)

                    if limb == "left_foot":
                        tmp_limb_list.append(src_skeleton.left_leg.foot)
                        tmp_limb_list.append(src_skeleton.left_leg.toe)
                            
                    if limb == "head":
                        tmp_limb_list.append(src_skeleton.spine.neck)
                        tmp_limb_list.append(src_skeleton.spine.head)
                        setting = getattr(src_skeleton, "face")
                        for k in sorted(dir(setting)):
                            if k.startswith("__") or k in ["bl_rna", "type", "name"]:
                                continue
                            try:
                                #if not 'super_copy' in k and not "shoulder" in k and not "hips" in k:
                                tmp = getattr(setting, k)
                                tmp_limb_list.append(tmp)
                            except:
                                continue

                    if limb == "RightShoulder":
                        tmp_limb_list.append(src_skeleton.right_arm.shoulder)
                        
                    if limb == "LeftShoulder":
                        tmp_limb_list.append(src_skeleton.left_arm.shoulder)

                    if limb == "left_fingers":
                        tmp_limb_list.extend(chain(*src_skeleton.left_fingers.values()))
                        
                    if limb == "right_fingers":
                        tmp_limb_list.extend(chain(*src_skeleton.right_fingers.values()))

                    if limb in other_bone_limb:
                        if src_settings.other_bone:
                            for item in src_settings.other_bone:
                                if limb == item.limb:
                                    tmp_limb_list.append(item.bone_name)
                    
                if tmp_limb_list:
                    for bone in ob.pose.bones:
                        if bone.name in tmp_limb_list:
                            if self.align_include == 'include':
                                align_list.append(bone.name)
                        else:
                            if self.align_include == 'exclude':
                                align_list.append(bone.name)


            if not self.same_bone_names and not self.align_limb and self.align_rest_pose:
                
                #if  self.align_arm:

                for limb in ('left_arm', 'left_arm_ik', 'right_arm', 'right_arm_ik'):
                    
                    setting = getattr(src_skeleton, limb)
                    for k in sorted(dir(setting)):
                        if k.startswith("__") or k in ["bl_rna", "type", "name"]:
                            continue
                        try:
                            tmp = getattr(setting, k)
                            align_list.append(tmp)
                        except:
                            pass

                align_list.extend(chain(*src_skeleton.left_fingers.values()))
                align_list.extend(chain(*src_skeleton.right_fingers.values()))

            if not self.same_bone_names and not self.align_limb and self.align_leg:

                for limb in ('right_leg', 'right_leg_ik', 'left_leg', 'left_leg_ik'):
                    
                    setting = getattr(src_skeleton, limb)
                    for k in sorted(dir(setting)):
                        if k.startswith("__") or k in ["bl_rna", "type", "name", "foot" ,"toe"]:
                            continue
                        try:
                            tmp = getattr(setting, k)
                            align_list.append(tmp)
                        except:
                            pass


            # hacky, but will do it: keep target armature in place during binding
            limit_constraints = self._add_limit_constraintss(trg_ob)

            try:
                ret_collection = trg_ob.data.collections[self.ret_bones_collection]
            except KeyError:
                ret_collection = trg_ob.data.collections.new(self.ret_bones_collection)
                ret_collection.is_visible = False

            # create Retarget bones
            bpy.ops.object.mode_set(mode='EDIT')
            for src_name, trg_name in bone_names_map.items():
                if not src_name:
                    continue

                if self.constraint_policy == 'skip':
                    try:
                        pb = ob.pose.bones[src_name]
                    except KeyError:
                        pass
                    else:
                        if self._bone_bound_already(pb):
                            continue

                is_object_root = src_name == root and self.constrain_root == 'Object'
                if not trg_name and not is_object_root:
                    continue

                trg_name = str(prefix) + str(trg_name)

                new_bone_name = bone_utils.copy_bone_to_arm(ob, trg_ob, src_name, suffix=bone_utils.cp_suffix)
                if not new_bone_name:
                    continue
                try:
                    new_parent = trg_ob.data.edit_bones[trg_name]
                except KeyError:
                    if is_object_root:
                        new_parent = None
                    else:
                        self.report({'WARNING'}, f"{trg_name} not found in target")
                        continue

                new_bone = trg_ob.data.edit_bones[new_bone_name]
                new_bone.parent = new_parent

                match_transform = self.match_transform

                
                #align rest pose
                if align_list and src_name in align_list:
                    match_transform = 'World'

                if match_transform == 'Bone':
                    # counter deformation bone transform

                    if deformation_map:
                        try:
                            def_bone = ob.data.edit_bones[deformation_map[src_name]]
                        except KeyError:
                            try:
                                def_bone = ob.data.edit_bones[src_name]
                            except KeyError:
                                continue
                    else:
                        try:
                            def_bone = ob.data.edit_bones[src_name]
                        except KeyError:
                            continue

                    try:
                        trg_ed_bone = trg_ob.data.edit_bones[trg_name]
                    except KeyError:
                        continue

                    new_bone.transform(def_bone.matrix.inverted())

                    # even transform
                    if self.match_object_transform:
                        new_bone.transform(ob.matrix_world)
                   
                    # counter target transform
                    new_bone.transform(trg_ob.matrix_world.inverted())

                    # align target temporarily
                    trg_roll = trg_ed_bone.roll
                    trg_ed_bone.roll = bone_utils.ebone_roll_to_vector(trg_ed_bone, def_bone.z_axis)

                    # bring under trg_bone
                    new_bone.transform(trg_ed_bone.matrix)

                    # restore target orient
                    trg_ed_bone.roll = trg_roll

                    new_bone.roll = bone_utils.ebone_roll_to_vector(trg_ed_bone, def_bone.z_axis)
                
                elif match_transform == 'Pose':

                    new_bone.matrix = ob.pose.bones[src_name].matrix

                    if self.match_object_transform:
                        new_bone.transform(ob.matrix_world)
                    
                    new_bone.transform(trg_ob.matrix_world.inverted_safe())
                
                elif match_transform == 'World':
                    new_bone.head = new_bone.parent.head
                    new_bone.tail = new_bone.parent.tail
                    new_bone.roll = new_bone.parent.roll

                    fix_rot = False

                    if self.fix_rot:
                        fix_rot = True

                    # Align pose
                    elif align_list and src_name in align_list:
                        fix_rot = True

                    if fix_rot:
                        
                        try:
                            src_bone = ob.data.edit_bones[src_name]
                            new_bone.roll = src_bone.roll
                        except:
                            # src_bone = ob.data.bones[src_name]
                            # src_z_axis_neg = Vector((0.0, 0.0, 1.0)) @ src_bone.matrix_local.inverted().to_3x3()
                            # src_z_axis_neg.normalize()
                            # new_bone.roll = bone_utils.ebone_roll_to_vector(new_bone, src_z_axis_neg)
                            pass

                        # src_bone = ob.data.edit_bones[src_name]
                        # new_bone.roll = src_bone.roll

                    if self.match_object_transform:
                        new_bone.transform(ob.matrix_world)

                else:
                    try:
                        src_bone = ob.data.edit_bones[src_name]
                        new_bone.roll = src_bone.roll
                    except:
                        # src_bone = ob.data.bones[src_name]
                        # src_z_axis_neg = Vector((0.0, 0.0, 1.0)) @ src_bone.matrix_local.inverted().to_3x3()
                        # src_z_axis_neg.normalize()
                        # new_bone.roll = bone_utils.ebone_roll_to_vector(new_bone, src_z_axis_neg)
                        pass

                    if self.match_object_transform:
                        new_bone.transform(ob.matrix_world)
                        new_bone.transform(trg_ob.matrix_world.inverted())

                if not self.same_bone_names:
                    if self.copy_IK_roll_hands:
                        if src_name in (src_skeleton.right_arm_ik.hand,
                                        src_skeleton.left_arm_ik.hand):

                            src_ik = ob.data.bones[src_name]
                            new_bone.roll = bone_utils.ebone_roll_to_vector(new_bone, src_ik.z_axis)
                    if self.copy_IK_roll_feet:
                        if src_name in (src_skeleton.left_leg_ik.foot,
                                        src_skeleton.right_leg_ik.foot):

                            src_ik = ob.data.bones[src_name]
                            new_bone.roll = bone_utils.ebone_roll_to_vector(new_bone, src_ik.z_axis)


                for coll in new_bone.collections:
                    coll.unassign(new_bone)
                ret_collection.assign(new_bone)

                if not self.same_bone_names:
                    if self.math_look_at:
                        if src_name == src_skeleton.right_arm_ik.arm:
                            start_bone_name = trg_skeleton.right_arm_ik.forearm
                        elif src_name == src_skeleton.left_arm_ik.arm:
                            start_bone_name = trg_skeleton.left_arm_ik.forearm
                        elif src_name == src_skeleton.right_leg_ik.upleg:
                            start_bone_name = trg_skeleton.right_leg_ik.leg
                        elif src_name == src_skeleton.left_leg_ik.upleg:
                            start_bone_name = trg_skeleton.left_leg_ik.leg
                        elif src_arm_ik_bone and src_name in src_arm_ik_bone.keys():
                            start_bone_name = src_arm_ik_bone[src_name]
                        else:
                            start_bone_name = ""

                        if start_bone_name:
                            start_bone = trg_ob.data.edit_bones[prefix + start_bone_name]

                            look_bone = trg_ob.data.edit_bones.new(start_bone_name + '_LOOK')
                            look_bone.head = start_bone.head
                            look_bone.tail = 2 * start_bone.head - start_bone.tail
                            look_bone.parent = start_bone

                            look_ats[src_name] = look_bone.name

                            for coll in look_bone.collections:
                                coll.unissign(look_bone)
                            ret_collection.assign(look_bone)

            for constr in limit_constraints:
                trg_ob.constraints.remove(constr)

            bpy.ops.object.mode_set(mode='POSE')

            for src_name, trg_name in look_ats.items():
                ret_bone = trg_ob.pose.bones[f'{src_name}{bone_utils.cp_suffix}']
                constr = ret_bone.constraints.new(type='LOCKED_TRACK')

                constr.head_tail = 1.0
                constr.target = trg_ob
                constr.subtarget = trg_name
                constr.lock_axis = 'LOCK_Y'
                constr.track_axis = 'TRACK_NEGATIVE_Z'

                constr = ret_bone.constraints.new(type='COPY_LOCATION')
                constr.target = trg_ob
                constr.subtarget = trg_name

            fk_arm_finger_bones = []
            if not self.same_bone_names and self.no_finger_loc and (self.loc_constraints or self.bind_floating):
                fk_arm_finger_bones = list(chain(*src_skeleton.left_fingers.values()))
                fk_arm_finger_bones.extend(chain(*src_skeleton.right_fingers.values()))
                
                for limb_name, bone_name in src_skeleton.face.items():
                    if limb_name != "name" and limb_name != "super_copy" and bone_name and not bone_name in fk_arm_finger_bones:
                        fk_arm_finger_bones.append(bone_name)

                for limb_name, bone_name in src_skeleton.spine.items():
                    if limb_name != "name" and limb_name != "hips" and bone_name and not bone_name in fk_arm_finger_bones:
                        fk_arm_finger_bones.append(bone_name)

                for limb_name, bone_name in src_skeleton.left_arm.items():
                    if limb_name != "name" and bone_name and not bone_name in fk_arm_finger_bones:
                        fk_arm_finger_bones.append(bone_name)

                for limb_name, bone_name in src_skeleton.right_arm.items():
                    if limb_name != "name" and bone_name and not bone_name in fk_arm_finger_bones:
                        fk_arm_finger_bones.append(bone_name)

                for limb_name, bone_name in src_skeleton.left_leg.items():
                    if limb_name != "name" and bone_name and not bone_name in fk_arm_finger_bones:
                        fk_arm_finger_bones.append(bone_name)

                for limb_name, bone_name in src_skeleton.right_leg.items():
                    if limb_name != "name" and bone_name and not bone_name in fk_arm_finger_bones:
                        fk_arm_finger_bones.append(bone_name)

                if src_settings.other_bone:
                    for item in src_settings.other_bone:
                        if not item.ik and not item.loc and item.bone_name:
                            if item.bone_name in bone_names_map.keys():
                                fk_arm_finger_bones.append(item.bone_name)

            add_loc_other_bone = []
            if not self.same_bone_names:
                add_loc_other_bone.append(src_settings.right_arm_ik.hand)
                add_loc_other_bone.append(src_settings.left_arm_ik.hand)
                add_loc_other_bone.append(src_settings.right_leg_ik.foot)
                add_loc_other_bone.append(src_settings.left_leg_ik.foot)
            if src_settings.other_bone and not self.same_bone_names:
                    for item in src_settings.other_bone:
                        if item.loc and item.bone_name:
                            if item.bone_name in bone_names_map.keys():
                                add_loc_other_bone.append(item.bone_name)

            for src_name in bone_names_map.keys():
                if not src_name:
                    continue
                if src_name == root:
                    if self.constrain_root == "None":
                        continue
                    if self.constrain_root == "Bone" and (not self.root_motion_bone or not self.root_motion_bone_sr):
                        continue
                try:
                    src_pbone = ob.pose.bones[src_name]

                except KeyError:
                    continue

                if self._bone_bound_already(src_pbone):
                    if self.constraint_policy == 'skip':
                       continue

                    if self.constraint_policy == 'disable':
                        for constr in src_pbone.constraints:
                            constr.mute = True

                    elif self.constraint_policy == 'remove':
                        for constr in reversed(src_pbone.constraints):
                            src_pbone.constraints.remove(constr)
                    # TODO: should unconstrain mid bones to!

                #fix foot
                fix_foot_list = []
                if self.fix_foot and not self.same_bone_names:
                    fix_foot_list = [src_skeleton.spine.hips, src_skeleton.left_leg.upleg, src_skeleton.right_leg.upleg, src_skeleton.left_leg.foot, src_skeleton.right_leg.foot]

                
                #find root bone
                hips_name = src_skeleton.spine.hips if src_skeleton.spine.hips in ob.pose.bones else ''

                root_bone = None
                for bone in ob.pose.bones:
                    root_bone = bone
                    break
                
                if not hips_name and root_bone:
                    hips_name = root_bone.name

                constr_types = []

                if self.scal_constraints:
                    constr_types.append('COPY_SCALE')

                #special forearm, leg
                if not self.same_bone_names and self.advance_setting and self.hand_fk_ik and (src_name == src_skeleton.right_arm.forearm or src_name ==  src_skeleton.left_arm.forearm):
                    constr_types.append('DAMPED_TRACK')

                elif not self.same_bone_names and self.advance_setting and self.foot_fk_ik and (src_name == src_skeleton.right_leg.leg or src_name == src_skeleton.left_leg.leg):
                    constr_types.append('DAMPED_TRACK')
                
                #special fk target type on other bone
                elif not self.same_bone_names and src_fk_ik_bone and src_name in src_fk_ik_bone:
                    constr_types.append('DAMPED_TRACK')
                #-----------

                # advanced Location Setting
                elif self.adv_loc and motion_collection_rmv and src_name in motion_collection_rmv:
                    constr_types.append('COPY_ROTATION')

                elif self.adv_loc and motion_collection_tp and src_name in motion_collection_tp:
                    constr_types.append('COPY_LOCATION')
                    constr_types.append('COPY_ROTATION')

                #other bone location
                elif not self.same_bone_names and add_loc_other_bone and src_name in add_loc_other_bone:
                    constr_types.append('COPY_LOCATION')
                    constr_types.append('COPY_ROTATION')

                #----------
                
                #fix foot
                elif not self.same_bone_names and not self.loc_constraints and self.fix_foot and src_name in fix_foot_list:
                    constr_types.extend(['COPY_LOCATION', 'COPY_ROTATION'])
                
                # not finger location
                elif not self.same_bone_names and self.no_finger_loc and (self.loc_constraints or self.bind_floating) and (src_name in fk_arm_finger_bones):
                    constr_types.append('COPY_ROTATION')
                
                #floating bones
                elif not self.same_bone_names and not self.loc_constraints and self.bind_floating and is_bone_floating(src_pbone, hips_name, trg_ob):
                    constr_types.extend(['COPY_LOCATION', 'COPY_ROTATION'])

                #floating bones 2
                elif self.same_bone_names and not self.loc_constraints and self.bind_floating and root_bone and is_bone_floating(src_pbone, root_bone.name, trg_ob):
                    constr_types.extend(['COPY_LOCATION', 'COPY_ROTATION'])

                #default setting
                else:
                    constr_types = self._bind_constraints

                if not self.rot_constraints and 'COPY_ROTATION' in constr_types:
                    constr_types.remove('COPY_ROTATION')

                subtarget_name = f'{src_name}{bone_utils.cp_suffix}'

                if subtarget_name in trg_ob.data.bones:

                    for constr_type in constr_types:
                        constr = src_pbone.constraints.new(type=constr_type)
                        constr.target = trg_ob
                        # fk to ik
                        if ( not self.same_bone_names and self.advance_setting and self.hand_fk_ik and (src_name == src_skeleton.right_arm.forearm or src_name ==  src_skeleton.left_arm.forearm))\
                            or (not self.same_bone_names and self.advance_setting and self.foot_fk_ik and (src_name == src_skeleton.right_leg.leg or src_name == src_skeleton.left_leg.leg)):
                            if src_name == src_skeleton.right_arm.forearm:
                                constr.subtarget = trg_skeleton.right_arm_ik.hand
                            if src_name == src_skeleton.left_arm.forearm:
                                constr.subtarget = trg_skeleton.left_arm_ik.hand
                            if src_name == src_skeleton.left_leg.leg:
                                constr.subtarget = trg_skeleton.left_leg_ik.foot
                            if src_name == src_skeleton.right_leg.leg:
                                constr.subtarget = trg_skeleton.right_leg_ik.foot
                        

                                
                        #use it breack the retarget collection for hand ik
                        # elif not self.same_bone_names and self.advance_setting and self.align_arm and src_name in [src_skeleton.right_arm_ik.hand, src_skeleton.left_arm_ik.hand]:
                        #     if src_name == src_skeleton.right_arm_ik.hand:
                        #         constr.subtarget = trg_skeleton.right_arm_ik.hand
                        #     if src_name == src_skeleton.left_arm_ik.hand:
                        #         constr.subtarget = trg_skeleton.left_arm_ik.hand
                        elif not self.same_bone_names and src_fk_ik_bone and src_name in src_fk_ik_bone:
                            constr.subtarget = bone_names_map[src_name]
                        else:
                            constr.subtarget = subtarget_name
                        constr.name = f'{constr.name}{bone_utils.cp_suffix}'
                        constr.influence = self.influence

                    #//shape
                    new_ob_bone = trg_ob.pose.bones[subtarget_name]
                    new_ob_bone.custom_shape = src_pbone.custom_shape
                    new_ob_bone.custom_shape_transform = src_pbone.custom_shape_transform
                    new_ob_bone.custom_shape_rotation_euler = src_pbone.custom_shape_rotation_euler
                    new_ob_bone.custom_shape_scale_xyz = src_pbone.custom_shape_scale_xyz
                    new_ob_bone.custom_shape_translation = src_pbone.custom_shape_translation
                    new_ob_bone.custom_shape_wire_width = src_pbone.custom_shape_wire_width
                    new_ob_bone.color.palette = src_pbone.color.palette
                    new_ob_bone.color.custom.normal = src_pbone.color.custom.normal
                    new_ob_bone.color.custom.select = src_pbone.color.custom.select
                    new_ob_bone.color.custom.active = src_pbone.color.custom.active

                if self.constrain_root == 'Bone' and src_name == root:
                    self._constrained_root = src_pbone

            if self.constrain_root == 'Object' and self.root_motion_bone:
                constr_types = ['COPY_LOCATION']
                if any([self.root_cp_rot_x, self.root_cp_rot_y, self.root_cp_rot_z]):
                    constr_types.append('COPY_ROTATION')
                if any([self.root_cp_scal_x, self.root_cp_scal_y, self.root_cp_scal_z]):
                    constr_types.append('COPY_SCALE')
                for constr_type in constr_types:
                    constr = ob.constraints.new(type=constr_type)
                    constr.target = trg_ob

                    constr.subtarget = self.root_motion_bone
                    constr.name = f'{constr.name}{bone_utils.cp_suffix}'
                    constr.influence = self.influence

                self._constrained_root = ob


            if self._constrained_root and self.root_motion_bone:

                constr = None
                loc_constr = None
                offset_constr = None
                for cons in self._constrained_root.constraints:
                    # if cons.type == 'LIMIT_LOCATION':
                    #     constr = cons
                    #     if not bone_utils.cp_suffix in constr.name:
                    #         constr.name = f'{constr.name}{bone_utils.cp_suffix}'

                    if cons.type == 'FLOOR' and cons.target and cons.target == trg_ob:
                        offset_constr = cons
                        offset_constr.target = trg_ob
                        offset_constr.subtarget = self.root_motion_bone
                        if not bone_utils.cp_suffix in offset_constr.name:
                            offset_constr.name = f'{offset_constr.name}{bone_utils.cp_suffix}'

                    if cons.type == 'COPY_LOCATION' and cons.target and cons.target == trg_ob:
                        loc_constr = cons
                        loc_constr.target = trg_ob
                        loc_constr.subtarget = self.root_motion_bone
                        if not bone_utils.cp_suffix in loc_constr.name:
                            loc_constr.name = f'{loc_constr.name}{bone_utils.cp_suffix}'

                #create a contraint if not found
                if not loc_constr:
                    loc_constr = self._constrained_root.constraints.new('COPY_LOCATION')
                    loc_constr.target = trg_ob
                    loc_constr.subtarget = self.root_motion_bone
                    loc_constr.name = f'{loc_constr.name}{bone_utils.cp_suffix}'
                    loc_constr.influence = self.influence

                loc_constr.use_x = self.root_cp_loc_x
                loc_constr.use_y = self.root_cp_loc_y
                loc_constr.use_z = self.root_cp_loc_z

                if self.keep_offset and self.root_cp_loc_z:
                    if not offset_constr:
                        offset_constr = self._constrained_root.constraints.new('FLOOR')

                    offset_constr.target = trg_ob
                    offset_constr.subtarget = self.root_motion_bone
                    if self.keep_offset_value < 0:
                        offset_constr.floor_location = 'FLOOR_NEGATIVE_Z'
                    else:
                        offset_constr.floor_location = 'FLOOR_Z'

                    #leng between armature
                    #TODO leng between
                    # bone = trg_ob.pose.bones[self.root_motion_bone]
                    # trh_mat = bone.bone.matrix_locaconstr.influence = self.influencel.inverted()
                    # if self.constrain_root == 'Object':
                    #     source_mat = self._constrained_root.data.matrix_local.inverted()
                    # else:
                    #     source_mat = self._constrained_root.bone.matrix_local.inverted()
                    # self.keep_offset_value = source_mat[2][3]
                    offset_constr.offset = self.keep_offset_value
                    offset_constr.name = f'{offset_constr.name}{bone_utils.cp_suffix}'
                    offset_constr.influence = self.influence

                if not constr:
                    constr = self._constrained_root.constraints.new('LIMIT_LOCATION')
                    constr.name = f'{constr.name}{bone_utils.cp_suffix}'
                    constr.influence = self.influence

                constr.use_min_x = self.root_use_loc_min_x or not self.root_cp_loc_x
                constr.use_min_y = self.root_use_loc_min_y or not self.root_cp_loc_y
                constr.use_min_z = self.root_use_loc_min_z or not self.root_cp_loc_z

                constr.use_max_x = self.root_use_loc_max_x or not self.root_cp_loc_x
                constr.use_max_y = self.root_use_loc_max_y or not self.root_cp_loc_y
                constr.use_max_z = self.root_use_loc_max_z or not self.root_cp_loc_z

                constr.min_x = self.root_loc_min_x if self.root_cp_loc_x and self.root_use_loc_min_x else 0.0
                constr.min_y = self.root_loc_min_y if self.root_cp_loc_y and self.root_use_loc_min_y else 0.0
                constr.min_z = self.root_loc_min_z if self.root_cp_loc_z and self.root_use_loc_min_z else 0.0

                constr.max_x = self.root_loc_max_x if self.root_cp_loc_x and self.root_use_loc_max_x else 0.0
                constr.max_y = self.root_loc_max_y if self.root_cp_loc_y and self.root_use_loc_max_y else 0.0
                constr.max_z = self.root_loc_max_z if self.root_cp_loc_z and self.root_use_loc_max_z else 0.0

            if self._constrained_root and self.root_motion_bone:
                constr = None
                for cons in self._constrained_root.constraints:
                    if cons.type == 'COPY_ROTATION' and cons.target and cons.target == trg_ob:
                        constr = cons
                        constr.target = trg_ob
                        constr.subtarget = self.root_motion_bone
                        if not bone_utils.cp_suffix in constr.name:
                            constr.name = f'{constr.name}{bone_utils.cp_suffix}'
                        break
                    
                if not constr:
                    constr = self._constrained_root.constraints.new('COPY_ROTATION')
                    constr.target = trg_ob
                    constr.subtarget = self.root_motion_bone
                    constr.name = f'{constr.name}{bone_utils.cp_suffix}'
                    constr.influence = self.influence

                constr.use_x = self.root_cp_rot_x
                constr.use_y = self.root_cp_rot_y
                constr.use_z = self.root_cp_rot_z

            if self._constrained_root and self.root_motion_bone:
                constr = None
                for cons in self._constrained_root.constraints:
                    if cons.type == 'COPY_SCALE' and cons.target and cons.target == trg_ob:
                        constr = cons
                        constr.target = trg_ob
                        constr.subtarget = self.root_motion_bone
                        if not bone_utils.cp_suffix in constr.name:
                            constr.name = f'{constr.name}{bone_utils.cp_suffix}'
                        break
                if constr or any((self.root_cp_scal_x, self.root_cp_scal_y, self.root_cp_scal_z)):

                    if not constr:
                        constr = self._constrained_root.constraints.new('COPY_SCALE')
                        constr.target = trg_ob
                        constr.subtarget = self.root_motion_bone
                        constr.name = f'{constr.name}{bone_utils.cp_suffix}'
                        constr.influence = self.influence

                    constr.use_x = self.root_cp_scal_x
                    constr.use_y = self.root_cp_scal_y
                    constr.use_z = self.root_cp_scal_z

            if self.transfer_pose:

                bpy.ops.object.mode_set(mode= 'OBJECT')
                context.view_layer.objects.active = ob
                bpy.ops.object.mode_set(mode= 'POSE')

                # delete bone collection
                list_trg = bone_utils.get_trg_ob(ob)
               
                # apply Constraints

                #object
                if ob.constraints:
                        
                    omat = ob.matrix_world.copy()
                    for constr in reversed(ob.constraints):
                        
                        if constr.type in bone_utils.const_type:
                            if not bone_utils.cp_suffix in constr.name:
                                continue
                            ob.constraints.remove(constr)
                            
                    ob.matrix_world = bone_utils.get_ob_matrix(ob, omat)
                #bone   
                for pbone in ob.pose.bones:

                    if not pbone.constraints:
                        continue
                    
                    bmat = pbone.matrix.copy()
                    for constr in reversed(pbone.constraints):
                        
                        if constr.type in bone_utils.const_type:
                            if not bone_utils.cp_suffix in constr.name:
                                continue
                            pbone.constraints.remove(constr)
                            
                    pbone.matrix = bone_utils.get_bone_matrix(pbone, bmat)

                # delete bone collection
                for t_obj in list_trg:

                    if t_obj.type != 'ARMATURE':
                        continue

                    #check visibility
                    view = False
                    if t_obj.hide_get(view_layer=context.view_layer):
                        view = True
                        t_obj.hide_set(False, view_layer=context.view_layer)

                    context.view_layer.objects.active = t_obj

                    if self.ret_bones_collection in t_obj.data.collections:
                        ret_collection = t_obj.data.collections[self.ret_bones_collection]
                        
                        bpy.ops.object.mode_set(mode= 'POSE')
                        
                        bones_to_delete = [bone.name for bone in t_obj.pose.bones if bone.name in ret_collection.bones]

                        bpy.ops.object.mode_set(mode='EDIT')

                        for bone_name in bones_to_delete:

                            if bone_name in t_obj.data.edit_bones:
                                t_obj.data.edit_bones.remove(t_obj.data.edit_bones[bone_name])

                        t_obj.data.collections.remove(ret_collection)
                        bpy.ops.object.mode_set(mode= 'POSE')

                    if view:
                        t_obj.hide_set(True, view_layer=context.view_layer)

                context.view_layer.objects.active = trg_ob

               

        bpy.ops.object.mode_set(mode= self.current_m)
        # for o in bake_up:
        #     o.select_set(True, view_layer = context.view_layer)
        # if self.actif:
        #     context.view_layer.objects.active = self.actif
        if self.play and not context.screen.is_animation_playing:
            bpy.ops.screen.animation_play()

        return {'FINISHED'}


def validate_actions(action: bpy.types.Action, path_resolve: callable):

    if not action:
        return False
    
    valid = False
    for slot in action.slots:

        if valid:
            break

        test = None

        if slot.target_id_type != 'OBJECT':
            continue

        channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)

        if channelbag:
            for fc in channelbag.fcurves:
                data_path = fc.data_path
                # if fc.array_index:
                #     data_path = data_path #+ "[%d]" % fc.array_index
                if not "pose.bones" in data_path:
                    continue

                try:
                    path_resolve(data_path)
                    valid = True
                    break
                except ValueError:
                    continue  # Invalid.
        
    return valid

def selected_action(context):
    actions = []
    for act in bpy.data.actions:
        if act.retarget_act.is_selected:
            actions.append(act)
    return actions

def selected_action_view(context):
    action_list = ops.get_only_selected_action_list(context)
    actions = []
    for item in action_list:
        if item.action_ptr:
            actions.append(item.action_ptr)
    return actions
    
class UnbindArmature(Operator):
    bl_idname = "armature.retarget_unbind_armature"
    bl_label = "Unbind Armature"
    bl_description = "Unbind Selected Armature"
    bl_options = {'REGISTER', 'UNDO'}

    target_list:StringProperty(name="Target List", search=bone_utils.get_trg_iterate, options={'SKIP_SAVE'}, default="All",
                               description="The list of targets is displayed when you link your source armature to multiple armatures")
    show_target_list = False

    del_const:BoolProperty(name="Delete Constraint",
                           description="(Only remove constraints created with 'Bind to Active Armature')",
                           default=True)
    
    del_col:BoolProperty(name="Delete Retarget Collection",
                         description="Delete Retarget Collection (AND ALL THE BONES INSIDE) ",
                         default=True)
    
    del_col_c:BoolProperty(name="",
                         description="Delete Retarget Collection On The Active Object",
                         default=False, options={'SKIP_SAVE'})
    
    col_name:StringProperty(name = "Name", description="Name of the Collection", default="Retarget Bones")
    
    unbind: BoolProperty(name="  Unbind  ", description="Unbind",
                        default=True)
    
    number_trg = []
    
    def draw(self, context):
        layout = self.layout
        column = layout.column()

        _prop_indent = 0.05

        o = ops.get_ob_or_armature(context, context.active_object)
        #test if its local
        if o.library is not None or o.data.library is not None:
            column.label(text=f"make '{ops.get_ob_or_armature(context, context.active_object).name}' local", icon='ERROR')
            column.separator()

        #number of target
        if self.number_trg:
            for tob_name, bk_name in self.number_trg:
                    column.label(text=f"Unbind {tob_name} and {bk_name}")
            column.separator()
        else:
            column.label(text="No binding detected", icon='ERROR')
            column.separator()

        if self.show_target_list:        
            row = column.split(factor=_prop_indent, align=True)
            row.label(text="")
            row.prop(self, "target_list")

        row = column.split(factor=_prop_indent, align=True)
        row.label(text="")
        row.prop(self, "del_const")

        if self.del_col:
            row = column.split(factor=_prop_indent, align=True)
            row.label(text="")
            subcolumn = row.split(factor=0.80, align=True)
            subcolumn.prop(self, "del_col")
            subcolumn.prop(self, 'del_col_c', toggle=True, icon='PANEL_CLOSE')
            
            row = column.split(factor=_prop_indent, align=True)
            row.label(text="")
            row.prop(self, "col_name")

        else:
            row = column.split(factor=_prop_indent, align=True)
            row.label(text="")
            row.prop(self, "del_col")

        row = column.split(factor=_prop_indent, align=True)
        row.label(text="")
        row.prop(self, "unbind", toggle=True)

    @classmethod
    def poll(cls, context):
        o = ops.get_ob_or_armature(context, context.active_object)
        if not o:
            return False
        if o.type != 'ARMATURE':
            return False
        return True
   
    def del_bone_collection(self ,context ,ob):
        #check visibility
        view = False
        if ob.hide_get(view_layer=context.view_layer):
            view = True
            ob.hide_set(False, view_layer=context.view_layer)
        
        context.view_layer.objects.active = ob
            
        if self.col_name in ob.data.collections:
            ret_collection = ob.data.collections[self.col_name]

            bpy.ops.object.mode_set(mode= 'POSE')

            bones_to_delete = [bone.name for bone in ob.pose.bones if bone.name in ret_collection.bones]

            bpy.ops.object.mode_set(mode='EDIT')

            for bone_name in bones_to_delete:
                if bone_name in ob.data.edit_bones:
                    ob.data.edit_bones.remove(ob.data.edit_bones[bone_name])
            ob.data.collections.remove(ret_collection)

        if view:
            ob.hide_set(True, view_layer=context.view_layer)
        bpy.ops.object.mode_set(mode= 'POSE')

    def invoke(self, context, event):

        if len(bone_utils.get_trg_iterate(self, context, None)) > 2:
            # if self.target_list not in bone_utils.get_trg_iterate(self, context, None):
            #     self.target_list = "--"
            self.show_target_list = True
            self.unbind =  False
        

        return self.execute(context)
    
    def execute(self, context):

        o = ops.get_ob_or_armature(context, context.active_object)
        #test if its local
        if o.library is not None or o.data.library is not None:
            return {'FINISHED'}

        bake_up = list(context.selected_objects)

        self.number_trg.clear()
        
        current_m = context.mode
        actif = context.active_object
        sel_obs = ops.get_selected_obs(context)

        for ob in sel_obs:
            if ob.type != 'ARMATURE':
                continue

            #test if its local
            if ob.library is not None or ob.data.library is not None:
                continue

            context.view_layer.objects.active = ob
            bpy.ops.object.mode_set(mode='POSE')

            # delete collection
            if self.del_col_c and self.del_col:
                #test if its local
                if ob.data.library is not None:
                    continue
                self.del_bone_collection(context, ob)

            list_trg = bone_utils.get_trg_ob(ob)
            for trg_ob in list_trg:
        
                if  trg_ob:

                    #test if its local
                    if trg_ob.data.library is not None:
                        continue

                    if self.target_list != "All" and trg_ob.name != self.target_list:
                        continue

                    self.number_trg.append((trg_ob.name, ob.name))

                    #exit
                    if not self.unbind or not self.del_col:
                        continue

                    self.del_bone_collection(context, trg_ob)

            #exit
            if not self.unbind:
               continue

            # delete Constraints
            if self.del_const:
                
                for constr in reversed(ob.constraints):
                    if constr.type in bone_utils.const_type:
                        if not bone_utils.cp_suffix in constr.name:
                            continue
                        if self.target_list != "All" and getattr(constr, "target", None) and constr.target.name != self.target_list:
                            continue
                        ob.constraints.remove(constr)

                for bone in ob.pose.bones:
    
                    for constr in reversed(bone.constraints):
                        if constr.type in bone_utils.const_type:
                            if not bone_utils.cp_suffix in constr.name:
                                continue
                            if self.target_list != "All" and getattr(constr, "target", None) and constr.target.name != self.target_list:
                                continue
                            bone.constraints.remove(constr)

        bpy.ops.object.mode_set(mode= current_m)
        for o in bake_up:
            o.select_set(True, view_layer = context.view_layer)
        context.view_layer.objects.active = actif
        return {'FINISHED'}    
                
    
class BakeConstrainedActions(Operator):
    bl_idname = "armature.retarget_bake_constrained_actions"
    bl_label = "Bake Constrained Actions"
    bl_description = "Bake Actions constrained from another Armature. No need to select two armatures"
    bl_options = {'REGISTER', 'PRESET', 'UNDO'}

    show_10: BoolProperty(name="",
                          description="Show Those Action",
                                default=True)
    
    show_all: BoolProperty(name="",
                           description="SHow All Action",
                                default=False, options={'SKIP_SAVE'})
    
    clear_users_old: BoolProperty(name="Clear original Action Users",
                                  default=False)

    fake_user_new: BoolProperty(name="Save New Action User",
                                default=True)
    
    add_to_object: BoolProperty(name="Add To Object(s) List",
                                default=True)
    
    #similar

    bake_similar:BoolProperty(name="Include Similar Action",
                              description="i.e: if you have 5 Mixamo animations(actions) and you bind your armature to one of them, this feature will bake these 5 actions in one go",
                                default=False)
    #-----

    only_selected_action: BoolProperty(name="Only Selected Action(s)",
                                description= "Only selected Action(s) in Action Manager",
                                default=False)
    
    by_name: BoolProperty(name="by Name",
                            description= "Only Look for Action with this Prefix/Suffix",
                            default=False)
    
    include: EnumProperty(items=[
        ('include', "Include", "Include Action with this Prefix/Suffix"),
        ('exclude', "Exclude", "Exclude Action with this Prefix/Suffix")
         ],
        name="",
        default='include')
    
    prefix: StringProperty(name="prefix",
                                description= "Prefix (comma is the separator)",
                                default="")
    
    contain: StringProperty(name="Contain",
                                  description= "Contain (comma is the separator)",
                                 default="")
    
    suffix: StringProperty(name="suffix",
                                 description= "Suffix (comma is the separator)",
                                default="")
    
    #list 

    action_select: BoolProperty(name="Action",
                               description= "Select between Actions",
                               default=False)
    
    include_a: EnumProperty(items=[
        ('include', "Include", "Include Actions"),
        ('exclude', "Exclude", "Exclude Actions")
         ],
        name="",
        default='include')
    
    action_l: StringProperty(name = "",
                              description=" Actions List",
                              default="", options = {'SKIP_SAVE'})

    clean_all:  BoolProperty(name="",
                              description="Delete All",
                             default=False, options = {'SKIP_SAVE'})

    clean_last:  BoolProperty(name="",
                              description="Delete the last one",
                              default=False, options = {'SKIP_SAVE'})

    action_collection = []
    
    #----------
    
    exclude_deform:BoolProperty(name="Exclude deform bones", default=False)

    all_bone: BoolProperty(name="All Contrained bones", 
                           description="(When it is false, it only includes contrained bones created with 'Bind to Active Armature')",
                           default=False)
    
    visible: BoolProperty(name="Visible",
                            description="Only visible bone",
                            default=False)
    
    only_selected: BoolProperty(name="Only Selected", default=False,
                                description="only selected bones")

    custom_start_end:BoolProperty(name="Custom Start and End", default=False)

    start:IntProperty(name="Start", default=0)

    end:IntProperty(name="End", default=32)

    del_const:BoolProperty(name="Delete Constraint", 
                           description="(Only remove constraints with mark below)",
                           default=True)

    del_col:BoolProperty(name="Delete Retarget Collection",
                         description="Delete Retarget Collection (AND ALL THE BONES INSIDE) ",
                         default=True)

    col_name:StringProperty(name = "Name", description="Name of the Collection", default="Retarget Bones")
    
    use_current_action: BoolProperty(name="Use Current Action", description="Overwrite Current Action",
                          default=False)

    inverse: BoolProperty(name="Inverse Animation", description="Inverse Animation",
                          default=False)

    const_suffix:StringProperty(name = "Mark", 
                                description="The constraint name must contain this value, 'Delete Constraint' also use it", 
                                
                                default=bone_utils.cp_suffix)
    
    step: IntProperty(name="Step", default=1, min = 1)

    interpolation: EnumProperty(items=[
            ('CONSTANT', 'Step', 'Poses hold until the next key', 'IPO_CONSTANT', 1),
            ('LINEAR', 'Linear', 'Gradual linear transition between keys', 'IPO_LINEAR', 2),
            ('BEZIER', 'Bezier', 'Transition between keys is affected by a curve tangents that can be manipulated',
             'IPO_BEZIER', 3),
             ],
                             name="", description="Interpolation",
                             default='LINEAR')
    
    handle_type: EnumProperty(items=[
             ('FREE', 'Free', 'Each handle can be manipulated independently', 'HANDLE_FREE', 1),
             ('ALIGNED', 'Aligned', 'Handles remain aligned as you modify them', 'HANDLE_ALIGNED', 2),
             ('VECTOR', 'Vector', 'Each handle points to the adjacent key', 'HANDLE_VECTOR', 3),
             ('AUTO', 'Auto', 'Automatically adjust both handles to conform the the curve', 'HANDLE_AUTO', 4),
             ('AUTO_CLAMPED', 'Auto Clamped',
             'Automatically adjust both handles to conform the curve but'
             ' flattens it as it gets to picks and valleys',
             'HANDLE_AUTOCLAMPED', 5)
            ],
                             name="", description="Handle type",
                             default='AUTO_CLAMPED')

    do_bake: BoolProperty(name="  BAKE  ", description="Bake driven motion",
                          default=False, options={'SKIP_SAVE'})
    
    number_trg = dict()

    def draw(self, context):
        layout = self.layout
        column = layout.column()

        _prop_indent = 0.05

        o = ops.get_ob_or_armature(context, context.active_object)
        #test if its local
        if o.library is not None:
            column.label(text=f"make '{ops.get_ob_or_armature(context, context.active_object).name}' local", icon='ERROR')
            column.separator()

        #target list
        if self.number_trg:

            if self.bake_similar:

                for ob_name, action_valid in self.number_trg.items():
                        column.label(text=f"Baking from {len(action_valid)} Actions to {ob_name}")

                        show_10 = 10

                        if self.show_10 and not self.show_all and action_valid:

                            i = 1
                            for action in action_valid:
                                if i > show_10:
                                    break
                                column.label(text=f"- {action.name} ")
                                i += 1

                        if self.show_all and action_valid:

                            for action in action_valid:
                                column.label(text=f"- {action.name} ")

                        if (not self.show_all and len(action_valid) >= 1) or (self.show_10 and len(action_valid) > show_10):
                            
                            row = column.split(factor=0.80, align=True)
                            row.label(text="")

                            if not self.show_all and len(action_valid) >= 1 :
                                row.prop(self, "show_10", toggle=True, icon='DOWNARROW_HLT')

                            if self.show_10 and len(action_valid) > show_10 :
                                row.prop(self, "show_all", toggle=True, icon='DOWNARROW_HLT')
            else:
                for ob_name, trg_ob_name in self.number_trg.items():

                    if trg_ob_name:
                        if ob_name == trg_ob_name[0]:
                            column.label(text=f"Baking: {ob_name}")
                        else:
                            column.label(text=f"Baking from {trg_ob_name[0]} to {ob_name}")

            column.separator()

        else:
            column.label(text="CAN'T BAKE (NO BONES ASSIGNED) ", icon='ERROR')
            column.separator()

        row = column.split(factor=_prop_indent, align=True)
        row.label(text="")
        row.prop(self, "clear_users_old")

        row = column.split(factor=_prop_indent, align=True)
        row.label(text="")
        row.prop(self, "fake_user_new")

        row = column.split(factor=_prop_indent, align=True)
        row.label(text="")
        row.prop(self, "add_to_object")

        row = column.split(factor=_prop_indent, align=True)
        row.label(text="")
        row.prop(self, "bake_similar")

        if self.bake_similar:

            row = column.split(factor=_prop_indent, align=True)
            row.label(text="")
            row.prop(self, "only_selected_action")

            row = column.split(factor=_prop_indent, align=True)
            row.label(text="")
            row.prop(self, "by_name")

            if self.by_name:
                subcol = row.column()
                subcol.prop(self, 'include')

                row = column.row()
                col = row.column()
                col.label(text="Prefix")
                col.prop(self, 'prefix', text="")

                col = row.column()
                col.label(text="Contain:")
                col.prop(self, 'contain', text="")

                col = row.column()
                col.label(text="Suffix:")
                col.prop(self, 'suffix', text="")

            row = column.split(factor=_prop_indent, align=True)
            row.label(text="")
            row.prop(self, "action_select")

            if self.action_select:

                subcol = row.column()
                subcol.prop(self, 'include_a')

                row = column.split(factor=0.80, align=True)
                row.prop_search(self, 'action_l',
                            bpy.data,
                            "actions")
                
                row.prop(self, 'action_l')
                row.prop(self, 'clean_all', toggle=True, icon='PANEL_CLOSE')
                row.prop(self, 'clean_last',toggle=True, icon='TRACKING_CLEAR_BACKWARDS')

                i = 0
                row = column.split(factor=0.33, align=True)

                for act in self.action_collection:
                    if i == 3:
                        row = column.split(factor=0.33, align=True)
                        i = 0

                    row.label(text=act, icon='ACTION')

                    i += 1
                    
        column.separator()


        row = column.split(factor=_prop_indent, align=True)
        row.label(text="")
        row.label(text="Affect Bones")

        row = column.split(factor=_prop_indent + 0.1 , align=True)
        row.label(text="")
        row.prop(self, "exclude_deform")
        row.enabled = not (self.only_selected or self.visible)

        row = column.split(factor=_prop_indent + 0.1 , align=True)
        row.label(text="")
        row.prop(self, "all_bone")
        row.enabled = not (self.only_selected or self.visible)

        row = column.split(factor=_prop_indent + 0.1 , align=True)
        row.label(text="")
        row.prop(self, "visible")
        row.enabled = not (self.only_selected)

        row = column.split(factor=_prop_indent + 0.1 , align=True)
        row.label(text="")
        row.prop(self, "only_selected")

        column.separator()

        row = column.split(factor=_prop_indent, align=True)
        row.label(text="")
        row.label(text="Unbind")

        row = column.split(factor=_prop_indent + 0.1 , align=True)
        row.label(text="")
        row.prop(self, "del_const")

        if self.del_const:

            row = column.split(factor=_prop_indent + 0.1 , align=True)
            row.label(text="")
            row.prop(self, "del_col")

            if self.del_col:
                row = column.split(factor=_prop_indent + 0.1 , align=True)
                row.label(text="")
                row.prop(self, "col_name")

        column.separator()


        row = column.split(factor=_prop_indent, align=True)
        row.label(text="")
        row.prop(self, "custom_start_end")

        if self.custom_start_end:
            row = column.split(factor=_prop_indent, align=True)
            row.label(text="")
            row.prop(self, "start")
            row.prop(self, "end")

        row = column.split(factor=_prop_indent, align=True)
        row.label(text="")
        row.prop(self, "use_current_action")

        row = column.split(factor=_prop_indent, align=True)
        row.label(text="")
        row.prop(self, "inverse")

        row = column.split(factor=_prop_indent, align=True)
        row.label(text="")
        row.prop(self, "const_suffix")

        row = column.split(factor=_prop_indent, align=True)
        row.label(text="")
        row.prop(self, "step")
        row.prop(self, "interpolation")
        if self.interpolation == "BEZIER":
            row.prop(self, "handle_type")

        row = column.split(factor=_prop_indent, align=True)
        row.label(text="")
        row.prop(self, "do_bake", toggle=True)

    def correct_action(self, action, context):

        if not self.bake_similar:
            return True
        
        if self.only_selected_action:
            selected_act = selected_action(context)
            if not action in selected_act:
                return False


        incl = -1
        incls = -1
        inclc = -1

        
        if self.by_name:
            if self.include == 'include':
                if self.prefix:
                    list_ = self.prefix.split(",")
                    incl = 0
                    for li in list_:
                        if li and not action.name.startswith(li):
                            incl -= 1
                        if li and action.name.startswith(li):
                            incl += 1
                    if incl < 0:
                        return self.test_list_action(action)

                if self.suffix:
                    list_ = self.suffix.split(",")
                    incls = 0
                    for li in list_:
                        if li and not action.name.endswith(li):
                            incls -= 1
                        if li and action.name.endswith(li):
                            incls += 1
                    if incls < 0:
                        return self.test_list_action(action)
                    
                if self.contain:
                    list_ = self.contain.split(",")
                    inclc = 0
                    for li in list_:
                        if li and not li in action.name:
                            inclc -= 1
                        if li and li in action.name:
                            inclc += 1
                    if inclc < 0:
                        return self.test_list_action(action)
            
            else:
                if self.prefix:
                    list_ = self.prefix.split(",")
                    for li in list_:
                        if li and action.name.startswith(li):
                            return False

                if self.suffix:
                    list_ = self.suffix.split(",")
                    for li in list_:
                        if li and action.name.endswith(li):
                            return False

                if self.contain:
                    list_ = self.contain.split(",")
                    for li in list_:
                        if li and li in action.name:
                            return False
        
        if self.action_select:

            if self.include_a == 'include':

                if self.action_collection and action.name not in self.action_collection:
                    return False or (incl >= 0 or incls >= 0 or inclc >= 0)
            
            elif self.action_collection and action.name in self.action_collection:
                return False
        
        return True
    
    def test_list_action(self, action):
        if self.action_select:
            if self.include_a == 'include':

                if self.action_collection and action.name in self.action_collection:
                    return True
        return False

    def bake_action(self, ob, action = None):

        fr_start, fr_end = 0, 32

        if self.custom_start_end:
            fr_start = self.start
            fr_end = self.end
        elif action:
            fr_start, fr_end = action.frame_range

        # bpy.ops.nla.bake(frame_start=int(fr_start), frame_end=int(fr_end),
        #                 bake_types={'POSE'}, only_selected= True,
        #                 visual_keying=True, clear_constraints=False)

        bone_utils.bake_anim(frame_start=int(fr_start), frame_end=int(fr_end),
                             bake_bones = True, use_current_action= self.use_current_action, only_selected= True, suffix = self.const_suffix, 
                             step = self.step, interpolation= self.interpolation, handle_type = self.handle_type, inverse = self.inverse)

        if not ob.animation_data or  not ob.animation_data.action:
            self.report({'WARNING'}, f"failed to bake ")

        if ob.animation_data and ob.animation_data.action:

            ob.animation_data.action.use_fake_user = self.fake_user_new

            if self.add_to_object:
                ob_action = ob.retarget_object_list.add()
                ob_action.action_ptr = ob.animation_data.action

            if action:
                tmp = action.name.split("|")
            else:
                tmp = [""]

            old_name = tmp[- 1] 
            new_name = f"{ob.name}|{old_name}"

            ob.animation_data.action.name = new_name

            if self.clear_users_old and action:
                action.user_clear()

        # find if there's constraint on object
        if len(ob.constraints) > 0:
            #check constr name

            #find the correct constraint if needed
            found = False

            if self.all_bone:
                found = True

            if self.only_selected:
                found = True
            
            if self.visible:
                found = True

            if not found:
                for constr in ob.constraints:
                    if self.const_suffix in constr.name:
                        found = True
                        break

            if not found:
                return

            ob.select_set(True)

            # bpy.ops.nla.bake(frame_start=int(fr_start), frame_end=int(fr_end),
            #             bake_types={'OBJECT'},
            #             visual_keying=True, clear_constraints=False, use_current_action=True)
            bone_utils.bake_anim(frame_start=int(fr_start), frame_end=int(fr_end),
                             bake_object = True, use_current_action= True, suffix = self.const_suffix, 
                             step = self.step, interpolation= self.interpolation, handle_type = self.handle_type, inverse = self.inverse)
            
            if not ob.animation_data or not ob.animation_data.action:
                self.report({'WARNING'}, f"failed to bake ")
                return

            #create a new channel (Only necesseray when we bake with bpy.ops.nla.bake )
            
            # slot = ob.animation_data.action_slot
            # channelbag = anim_utils.action_get_channelbag_for_slot(ob.animation_data.action, slot)
            # new_group = channelbag.groups.new("Object Transforms")

            # for fc in channelbag.fcurves:
            #     if not fc.group:
            #         fc.group = new_group

    @classmethod
    def poll(cls, context):
        o = ops.get_ob_or_armature(context, context.active_object)
        if not o:
            return False
        if o.type != 'ARMATURE':
            return False
        return True

    def execute(self, context):

        o = ops.get_ob_or_armature(context, context.active_object)
        #test if its local
        if o.library is not None:
            return {'FINISHED'}

        bake_up = list(context.selected_objects)

        self.number_trg.clear()

        #similar action
        if self.clean_all:
            if len(self.action_collection) > 0 :
                self.action_collection.clear()
            self.clean_all = False

        if self.clean_last:
            if len(self.action_collection) > 0 :
                self.action_collection.pop()
            self.clean_last = False

        if self.action_l != "":
            if not self.action_l in self.action_collection:
                self.action_collection.append(self.action_l)
            self.action_l = ""

        actif =  context.active_object
        sel_obs = list(ops.get_selected_obs(context))

        current_m = context.mode

        #handle action here to prevent duplication
        all_actions = list(bpy.data.actions)

        #deselect to prevent multiple backing
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')

        for ob in sel_obs:
            if ob.type != 'ARMATURE':
                continue

            if ob.library is not None:
                continue
            
            #also find for custom suffix
            target_list = bone_utils.get_trg_ob(ob, self.all_bone, suffix = self.const_suffix)

            trg_ob = None

            if not target_list:
                trg_ob = ob

            else:
                for tr in target_list:
                    if tr != ob:
                        trg_ob = tr

            if not trg_ob:
                trg_ob = ob

            context.view_layer.objects.active = ob
            if context.mode != "POSE":
                bpy.ops.object.mode_set(mode='POSE')

            #test selected bone
            found_bone = False

            if  not (self.only_selected or self.visible):

                bpy.ops.pose.select_all(action='DESELECT')

                for pb in bone_utils.get_constrained_controls(ob, unselect=True, use_deform=not self.exclude_deform):

                    if self.all_bone:
                        pb.select = True
                        found_bone = True

                    else:
                        for const in reversed(pb.constraints):
                            if self.const_suffix in const.name:
                                pb.select = True
                                found_bone = True
                                break
            
            if self.visible and not self.only_selected:
                for bone in ob.pose.bones:
                    bone.select = bone_utils.visible_bone(bone)

            #test selected bone 
            if not found_bone and context.selected_pose_bones_from_active_object:
                found_bone = True

            #test constraint in object
            if not found_bone and len(ob.constraints) > 0:

                if self.all_bone:
                    found_bone = True

                if self.only_selected:
                    found_bone = True

                if self.visible:
                    found_bone = True

                if not found_bone:
                    for constr in ob.constraints:
                        if self.const_suffix in constr.name:
                            found_bone = True
                            break

            if not found_bone:
                continue
            #----

            actions = []

            if self.bake_similar:
                for action in all_actions:
                    if not action:
                        continue
                    if not validate_actions(action, trg_ob.path_resolve):
                        continue
                    if not self.correct_action(action, context):
                        continue
                    actions.append(action)

                self.number_trg[ob.name] = actions

            else:
                if trg_ob.animation_data and trg_ob.animation_data.action:
                    actions.append(trg_ob.animation_data.action)

                self.number_trg[ob.name] = [trg_ob.name]

            
            #dont bake
            if not self.do_bake:
                continue

            if not trg_ob.animation_data:
                trg_ob.animation_data_create()

            first_action = True

            if not actions:

                self.bake_action(ob)

            else:
                for action in actions:  # convert to list beforehand to avoid picking new actions

                    if not first_action and self.use_current_action:
                        if ob.animation_data and ob.animation_data.action:
                            action_dupli = ob.animation_data.action.copy()
                            ob.animation_data.action = action_dupli

                    trg_ob.animation_data.action = action
                    if not trg_ob.animation_data.action_slot:
                        for slot in action.slots:
                            if ops.validate_slot(action, slot, trg_ob.path_resolve, armature= bool(trg_ob.type == "'ARMATURE'")):
                                trg_ob.animation_data.action_slot = slot
                                break
                        
                    self.bake_action(ob, action)

                    first_action = False


        if not self.do_bake:

            bpy.ops.object.mode_set(mode= current_m)
            for o in bake_up:
                o.select_set(True, view_layer = context.view_layer)
            context.view_layer.objects.active = actif
            return {'FINISHED'}
        
        # delete collection
        if self.del_const and self.del_col:

            for o in sel_obs:

                if ob.type != 'ARMATURE':
                    continue

                if ob.library is not None:
                    continue

                for ob in bone_utils.get_trg_ob(o):

                    if ob.type != 'ARMATURE':
                        continue

                     #test if its local
                    if ob.data.library is not None:
                        continue

                    #check visibility
                    view = False
                    if ob.hide_get(view_layer=context.view_layer):
                        view = True
                        ob.hide_set(False, view_layer=context.view_layer)
                    
                    context.view_layer.objects.active = ob
                        
                    if self.col_name in ob.data.collections:
                        ret_collection = ob.data.collections[self.col_name]

                        bpy.ops.object.mode_set(mode= 'POSE')

                        bones_to_delete = [bone.name for bone in ob.pose.bones if bone.name in ret_collection.bones]

                        bpy.ops.object.mode_set(mode='EDIT')

                        for bone_name in bones_to_delete:
                            if bone_name in ob.data.edit_bones:
                                ob.data.edit_bones.remove(ob.data.edit_bones[bone_name])
                        ob.data.collections.remove(ret_collection)

                    if view:
                        ob.hide_set(True, view_layer=context.view_layer)

            bpy.ops.object.mode_set(mode= 'POSE')

        # delete Constraints
        if self.del_const:
            
            for ob in sel_obs:
                
                if ob.type != 'ARMATURE':
                    continue

                if ob.library is not None:
                    continue

                for constr in reversed(ob.constraints):
                    if not self.const_suffix in constr.name:
                        continue
                    ob.constraints.remove(constr)

                for pbone in ob.pose.bones:
                    
                    for constr in reversed(pbone.constraints):
                        if not self.const_suffix in constr.name:
                            continue
                        pbone.constraints.remove(constr)

        bpy.ops.object.mode_set(mode= current_m)
        for o in bake_up:
            o.select_set(True, view_layer = context.view_layer)
        context.view_layer.objects.active = actif

        bpy.ops.screen.animation_play()
        return {'FINISHED'}

class ActionNameCandidates(bpy.types.PropertyGroup):
    name = StringProperty(name="Name Candidate", default="")

class RenameActionsFromFbxFiles(Operator, ImportHelper):
    bl_idname = "armature.retarget_rename_actions_fbx"
    bl_label = "Rename Actions from fbx data..."
    bl_description = "Rename Actions from candidate fbx files"
    bl_options = {'PRESET', 'UNDO'}

    directory: StringProperty(name="Folder Path", subtype='DIR_PATH')

    filename_ext = ".fbx"
    filter_glob: StringProperty(default="*.fbx", options={'HIDDEN'})

    files: CollectionProperty(
        name="File Path",
        type=bpy.types.OperatorFileListElement,
    )

    contains: StringProperty(name="Containing", default="|")
    starts_with: StringProperty(name="Starting with", default="Action")

    only_selected_action: BoolProperty(name="Only Selected Action(s)",
                                description= "Only selected Action(s) in Action Manager",
                                default=False)
    
    def draw(self, context):
        layout = self.layout
        column = layout.column()

        row = column.row()
        row.prop(self, "contains")
        row.enabled = not self.only_selected_action
        column.separator()

        row = column.row()
        row.prop(self, "starts_with")
        row.enabled = not self.only_selected_action
        column.separator()

        row = column.row()
        row.prop(self, "only_selected_action")
    
    def execute(self, context):
        fbx_durations = dict()
        for f in self.files:
            fbx_path = os.path.join(self.directory, f.name)
            local_time = fbx_helper.get_fbx_local_time(fbx_path)
            if not local_time:
                continue

            duration = fbx_helper.convert_from_fbx_duration(*local_time)
            duration = round(duration, 5)
            duration = str(duration)
            action_name = os.path.splitext(f.name[:-3])[0]

            try:
                fbx_durations[duration].append(action_name)
            except KeyError:  # entry doesn'exist yet
                fbx_durations[duration] = action_name
            except AttributeError:  # existing entry is not a list
                current = fbx_durations[duration]
                fbx_durations[duration] = [current, action_name]

        selected_act = []
        if self.only_selected_action:
            selected_act = selected_action_view(context)

        for action in bpy.data.actions:
            skip_action = True

            if self.only_selected_action:
                
                if action in selected_act:
                    skip_action = False
            
            else:

                if self.contains and self.contains in action.name:
                    skip_action = False
                if skip_action and self.starts_with and action.name.startswith(self.starts_with):
                    skip_action = False

            if skip_action:
                continue

            start, end = action.frame_range
            ac_duration = end - start
            ac_duration /= context.scene.render.fps
            ac_duration = round(ac_duration, 5)
            ac_duration = str(ac_duration)

            try:
                fbx_match = fbx_durations[ac_duration]
            except KeyError:
                continue

            if not fbx_match:
                continue
            if isinstance(fbx_match, list):
                for name in fbx_match:
                    entry = action.retarget_name_candidates.add()
                    entry.name = name
                continue

            action.name = fbx_match
        
        ops.update_action_list(context)

        return {'FINISHED'}

class Mirror(Operator):

    bl_idname = "armature.retarget_mirror"
    bl_label = "Mirror Support"
    bl_description = "Add .L and .R to bone name"
    bl_options = {'REGISTER', 'UNDO'}

    selected_only: BoolProperty(name="Only Selected",
                                description="Only on Selected Bones",
                                default=False)
    
    remove_support: BoolProperty(name="Remove Support",
                                description="Remove .L and .R to bone name",
                                default=False)
   #similar

    show_10: BoolProperty(name="",
                          description="Show Those Action",
                                default=True)
    
    show_all: BoolProperty(name="",
                           description="SHow All Action",
                                default=False, options={'SKIP_SAVE'})

    bake_similar:BoolProperty(name="Include Similar Action",
                              description="convert other action",
                                default=False)
    #-----
    only_selected_action: BoolProperty(name="Only Selected Action(s)",
                                description= "Only selected Action(s) in Action Manager",
                                default=False)
    
    by_name: BoolProperty(name="by Name",
                            description= "Only Look for Action with this Prefix/Suffix",
                            default=False)
    
    include: EnumProperty(items=[
        ('include', "Include", "Include Action with this Prefix/Suffix"),
        ('exclude', "Exclude", "Exclude Action with this Prefix/Suffix")
         ],
        name="",
        default='include')
    
    prefix: StringProperty(name="prefix",
                                description= "Prefix (comma is the separator)",
                                default="")
    
    contain: StringProperty(name="Contain",
                                  description= "Contain (comma is the separator)",
                                 default="")
    
    suffix: StringProperty(name="suffix",
                                 description= "Suffix (comma is the separator)",
                                default="")
    
    #list 

    action_select: BoolProperty(name="Action",
                               description= "Select between Actions",
                               default=False)
    
    include_a: EnumProperty(items=[
        ('include', "Include", "Include Actions"),
        ('exclude', "Exclude", "Exclude Actions")
         ],
        name="",
        default='include')
    
    action_l: StringProperty(name = "",
                              description=" Actions List",
                              default="", options = {'SKIP_SAVE'})

    clean_all:  BoolProperty(name="",
                              description="Delete All",
                             default=False, options = {'SKIP_SAVE'})

    clean_last:  BoolProperty(name="",
                              description="Delete the last one",
                              default=False, options = {'SKIP_SAVE'})

    action_collection = []

    number_trg = dict()

    def draw(self, context):
        layout = self.layout
        column = layout.column()

        o = ops.get_ob_or_armature(context, context.active_object)
        #test if its local
        if o.library is not None or o.data.library is not None:
            column.label(text=f"make '{ops.get_ob_or_armature(context, context.active_object).name}' local", icon='ERROR')
            column.separator()

        if self.bake_similar and self.number_trg:

            for ob_name, action_valid in self.number_trg.items():
                column.label(text=f"Rename {len(action_valid)} Actions of {ob_name}")

                show_10 = 10

                if self.show_10 and not self.show_all and action_valid:

                    i = 1
                    for action in action_valid:
                        if i > show_10:
                            break
                        column.label(text=f"- {action.name} ")
                        i += 1

                if self.show_all and action_valid:

                    for action in action_valid:
                        column.label(text=f"- {action.name} ")

                if (not self.show_all and len(action_valid) >= 1) or (self.show_10 and len(action_valid) > show_10):
                    
                    row = column.split(factor=0.80, align=True)
                    row.label(text="")

                    if not self.show_all and len(action_valid) >= 1 :
                        row.prop(self, "show_10", toggle=True, icon='DOWNARROW_HLT')

                    if self.show_10 and len(action_valid) > show_10 :
                        row.prop(self, "show_all", toggle=True, icon='DOWNARROW_HLT')
            column.separator()
        else:
            #show number
            armatures = ops.get_selected_obs(context)
            num = 0
            for armature in armatures:

                if armature.type != 'ARMATURE':
                    continue
                num += 1
            if num > 1:
                column.label(text=f"{num} Armatures Selected")
                column.separator()


        row = column.row()
        row.prop(self, 'selected_only')

        row = column.row()
        row.prop(self, 'remove_support')

        column.separator()
        row = column.row()
        tex = "-- Actions/Slots Influence --".center(50)
        row.label(text=tex, icon='ACTION')

        row = column.row()
        row.prop(self, "bake_similar")

        if self.bake_similar:

            row = column.row()
            row.prop(self, "only_selected_action")

            row = column.row()
            row.prop(self, "by_name")

            if self.by_name:
                subcol = row.column()
                subcol.prop(self, 'include')

                row = column.row()
                col = row.column()
                col.label(text="Prefix")
                col.prop(self, 'prefix', text="")

                col = row.column()
                col.label(text="Contain:")
                col.prop(self, 'contain', text="")

                col = row.column()
                col.label(text="Suffix:")
                col.prop(self, 'suffix', text="")

            row = column.row()
            row.prop(self, "action_select")

            if self.action_select:

                subcol = row.column()
                subcol.prop(self, 'include_a')

                row = column.split(factor=0.80, align=True)
                row.prop_search(self, 'action_l',
                            bpy.data,
                            "actions")
                
                row.prop(self, 'action_l')
                row.prop(self, 'clean_all', toggle=True, icon='PANEL_CLOSE')
                row.prop(self, 'clean_last',toggle=True, icon='TRACKING_CLEAR_BACKWARDS')

                i = 0
                row = column.split(factor=0.33, align=True)

                for act in self.action_collection:
                    if i == 3:
                        row = column.split(factor=0.33, align=True)
                        i = 0

                    row.label(text=act, icon='ACTION')

                    i += 1

    def correct_action(self, action, context):

        if not self.bake_similar:
            return True
        
        if self.only_selected_action:
            selected_act = selected_action(context)
            if not action in selected_act:
                return False

        incl = -1
        incls = -1
        inclc = -1

        
        if self.by_name:
            if self.include == 'include':
                if self.prefix:
                    list_ = self.prefix.split(",")
                    incl = 0
                    for li in list_:
                        if li and not action.name.startswith(li):
                            incl -= 1
                        if li and action.name.startswith(li):
                            incl += 1
                    if incl < 0:
                        return self.test_list_action(action)

                if self.suffix:
                    list_ = self.suffix.split(",")
                    incls = 0
                    for li in list_:
                        if li and not action.name.endswith(li):
                            incls -= 1
                        if li and action.name.endswith(li):
                            incls += 1
                    if incls < 0:
                        return self.test_list_action(action)
                    
                if self.contain:
                    list_ = self.contain.split(",")
                    inclc = 0
                    for li in list_:
                        if li and not li in action.name:
                            inclc -= 1
                        if li and li in action.name:
                            inclc += 1
                    if inclc < 0:
                        return self.test_list_action(action)
            
            else:
                if self.prefix:
                    list_ = self.prefix.split(",")
                    for li in list_:
                        if li and action.name.startswith(li):
                            return False

                if self.suffix:
                    list_ = self.suffix.split(",")
                    for li in list_:
                        if li and action.name.endswith(li):
                            return False

                if self.contain:
                    list_ = self.contain.split(",")
                    for li in list_:
                        if li and li in action.name:
                            return False
        
        if self.action_select:

            if self.include_a == 'include':

                if self.action_collection and action.name not in self.action_collection:
                    return False or (incl >= 0 or incls >= 0 or inclc >= 0)
            
            elif self.action_collection and action.name in self.action_collection:
                return False
        
        return True
    
    def test_list_action(self, action):
        if self.action_select:
            if self.include_a == 'include':

                if self.action_collection and action.name in self.action_collection:
                    return True
        return False

    @classmethod
    def poll(cls, context):
        o = ops.get_ob_or_armature(context, context.active_object)
        if not o:
            return False
        if o.type != 'ARMATURE':
            return False
        return True

    def find_mirror_bone(self, name, ob):
        strip = bone_utils.lrl_strip(name)
        for bone in ob.pose.bones:
            if name != bone.name and strip == bone_utils.lrl_strip(bone.name):
                return bone.name
        return ""

    def execute(self, context):

        o = ops.get_ob_or_armature(context, context.active_object)
        #test if its local
        if o.library is not None or o.data.library is not None:
            return {'FINISHED'}

        self.number_trg.clear()

        current_m = context.mode

        armatures = ops.get_selected_obs(context)
        for ob in armatures:

            if ob.type != 'ARMATURE':
                continue

            if ob.library is not None or ob.data.library is not None:
                continue
            
            context.view_layer.objects.active = ob
            bpy.ops.object.mode_set(mode='POSE')

            actions = []

            if self.bake_similar:
                actions = [action for action in bpy.data.actions if action and validate_actions(action, ob.path_resolve) and self.correct_action(action, context)]
                self.number_trg[ob.name] = actions

            left_right = dict()
            bone_map = dict()

            for bone in ob.pose.bones:
                if bone_utils.is_pose_bone_all_locked(bone):
                    continue
                if bone.name in left_right.keys() or bone.name in left_right.values():
                    continue

                if self.selected_only and not bone.select:
                    continue

                if self.remove_support and not bone.name.endswith(".L") and not bone.name.endswith(".R"):
                    continue

                find = self.find_mirror_bone(bone.name, ob)
                if find and find not in left_right.values() and find not in left_right.keys():
                    if bone_utils.bone_left_or_right(find):
                        left_right[find] = bone.name
                    else:
                        left_right[bone.name] = find

            for l, r in left_right.items():
                try:
                    l_bone = ob.pose.bones[l]
                    r_bone = ob.pose.bones[r]
                except:
                    continue

                if self.remove_support:

                    if r_bone.name.endswith(".R"):
                        bone_map[r_bone.name] = r_bone.name[:-2]
                        r_bone.name = r_bone.name[:-2]

                    if l_bone.name.endswith(".L"):
                        bone_map[l_bone.name] = bone_utils.bone_left_name(r_bone)
                        l_bone.name = bone_utils.bone_left_name(r_bone)

                else:
                    if not l_bone.name.endswith(".L"):
                        bone_map[l_bone.name] = r_bone.name + ".L"
                        l_bone.name = r_bone.name + ".L"

                    if not r_bone.name.endswith(".R"):
                        bone_map[r_bone.name] = r_bone.name + ".R"
                        r_bone.name = r_bone.name + ".R"

            if ob.animation_data and ob.data.animation_data:
                for driver in chain(ob.animation_data.drivers, ob.data.animation_data.drivers):
                    try:
                        driver_bone = driver.data_path.split('"')[1]
                    except IndexError:
                        continue

                    try:
                        trg_name = bone_map[driver_bone]
                    except KeyError:
                        continue

                    driver.data_path = driver.data_path.replace('bones["{0}"'.format(driver_bone),
                                                                    'bones["{0}"'.format(trg_name))
                    
            for action in actions:

                if not action:
                    continue

                for slot in action.slots:

                    if slot.target_id_type != 'OBJECT':
                        continue

                    channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)

                    for group in channelbag.groups:
                        try:
                            # Update group data paths
                            gr_name = group.name
                            
                            new_name = bone_map[group.name]
                            group.name = new_name

                            # Update F-Curve data paths
                            for fcurve in group.channels:
                                fcurve.data_path = fcurve.data_path.replace(gr_name, new_name)
                        except KeyError:
                            pass

        bpy.ops.object.mode_set(mode=current_m)
        return {'FINISHED'}


def is_bone_floating(bone, hips_bone_name, target = None):

    while bone.parent:
        if bone.parent.name == hips_bone_name:
            return False
        for constr in bone.constraints:
            if constr.type in bone_utils.const_type and bone_utils.cp_suffix in constr.name:
                if target:
                    if getattr(constr, 'target', None) and constr.target == target:
                        return False
                    continue
                    
                return False
        bone = bone.parent

    return True


def add_loc_key(bone, frame, options):
    bone.keyframe_insert('location', index=0, frame=frame, options=options)
    bone.keyframe_insert('location', index=1, frame=frame, options=options)
    bone.keyframe_insert('location', index=2, frame=frame, options=options)


def get_rot_ani_path(to_animate):
    if to_animate.rotation_mode == 'QUATERNION':
        return 'rotation_quaternion', 4
    if to_animate.rotation_mode == 'AXIS_ANGLE':
        return 'rotation_axis_angle', 4

    return 'rotation_euler', 3


def add_loc_rot_key(bone, frame, options):
    add_loc_key(bone, frame, options)

    mode, channels = get_rot_ani_path(bone)
    for i in range(channels):
        bone.keyframe_insert(mode, index=i, frame=frame, options=options)

def add_rot_key(bone, frame, options):
    mode, channels = get_rot_ani_path(bone)
    for i in range(channels):
        bone.keyframe_insert(mode, index=i, frame=frame, options=options)

def add_scal_key(bone, frame, options):
    bone.keyframe_insert('scale', index=0, frame=frame, options=options)
    bone.keyframe_insert('scale', index=1, frame=frame, options=options)
    bone.keyframe_insert('scale', index=2, frame=frame, options=options)

def update_hip(self, context):
    o = ops.get_ob_or_armature(context, context.active_object)
    rig_settings = o.data.retarget_retarget
    if self.rig_preset != "--Current--":
        rig_settings = preset_handler.set_preset_skel(self.rig_preset, context)

    self.hips_bone = rig_settings.spine.hips

class AddRoot(Operator):

    bl_idname = "armature.retarget_add_root"
    bl_label = "Add Root Bone"
    bl_description = "Add Root Bone, (Apply the Rotation)"
    bl_options = {'REGISTER', 'UNDO'}

    rig_preset: EnumProperty(items=preset_handler.iterate_presets_with_current,
                              update=update_hip,
                             name="Target Preset",
                             )
    hips_bone: StringProperty(name="Hips_Bone",
                               default="",
                               options={'SKIP_SAVE'})

    root_name: StringProperty(name="Root Name",
                              description="'Root' is the recommended name, it will make it compatible with other features (it will automatically add the prefix if it's not specified)",
                                default="Root")

    addroot: BoolProperty(name="Add Root", default=True)

    @classmethod
    def poll(cls, context):
        o = ops.get_ob_or_armature(context, context.active_object)
        if not o:
            return False
        if o.type != 'ARMATURE':
            return False
        return True

    def draw(self, context):
        layout = self.layout
        column = layout.column()

        #test if its local
        o = ops.get_ob_or_armature(context, context.active_object)
        if o.library is not None or o.data.library is not None:
            column.label(text=f"make '{o.name}' local", icon='ERROR')
            column.separator()

        #show number
        armatures = ops.get_selected_obs(context)
        num = 0
        for armature in armatures:

            if armature.type != 'ARMATURE':
                continue
            num += 1
        if num > 1:
            column.label(text=f"{num} Armatures Selected")
            column.separator()

        row = column.row()
        row.prop(self, 'rig_preset', text="Rig Type:")

        # if len(ops.get_selected_obs(context)) > 1 and not self.rig_preset == '--':
        #     row = column.row()
        #     tex = "--Rig Type its sometimes Required--".center(50)
        #     row.label(text=tex, icon='ERROR')

        row = column.split(factor=0.2, align=True)
        row.label(text="Hips Bone")
        row.prop_search(self, 'hips_bone',
                        o.data,
                        "bones", text="")

        row = column.row()
        row.prop(self, "root_name")

        row = column.split(factor=0.30, align=True)
        row.label(text="")
        row.prop(self, "addroot", toggle=True)

    def _set_defaults(self, context, rig_settings, force = False):
        if not rig_settings:
            return
        o = ops.get_ob_or_armature(context, context.active_object)
        if force or (rig_settings.spine.hips in o.pose.bones):
            self.hips_bone = rig_settings.spine.hips

    def invoke(self, context, event):
        o = ops.get_ob_or_armature(context, context.active_object)
        if o.data.retarget_retarget.has_settings():
            self.rig_preset = '--Current--'

        else:
            self.rig_preset = preset_handler.findPreset(o)

        rig_settings = o.data.retarget_retarget
        if self.rig_preset != "--Current--":
            rig_settings = preset_handler.set_preset_skel(self.rig_preset, context)


        self._set_defaults(context, rig_settings)
        
        return self.execute(context)
   
    def execute(self, context):

        #test if its local
        o = ops.get_ob_or_armature(context, context.active_object)
        if o.library is not None or o.data.library is not None:
            return {'FINISHED'}

        current_m = context.mode

        if not self.hips_bone:
            bpy.ops.object.mode_set(mode=current_m)
            return {'FINISHED'}

        if not self.addroot:
            bpy.ops.object.mode_set(mode=current_m)
            return {'FINISHED'}
        
        bake_up = list(context.selected_objects)
        
        actif =  context.active_object

        armatures = ops.get_selected_obs(context)
        current_m = context.mode
        

        for armature in armatures:

            if armature.type != 'ARMATURE':
                continue

            #test if its local
            if armature.library is not None or armature.data.library is not None:
                continue

            context.view_layer.objects.active = armature
            bpy.ops.object.mode_set(mode='EDIT')

            if armature != o:

                rig_settings = armature.data.retarget_retarget
                if self.rig_preset != "--Current--":
                    rig_settings = preset_handler.set_preset_skel(self.rig_preset, context)
                self._set_defaults(context, rig_settings, force = True)

            if not self.hips_bone in armature.pose.bones:
                continue

            root_name = "Root" if self.root_name == "" else self.root_name

            prefix_ = ""
            #find the prefix
            for bone in armature.data.edit_bones:
                if ":" in bone.name:
                    prefix_ = bone.name.split(":")[0]
                    if ":" not in root_name:
                        root_name = prefix_ +":"+ root_name
                    #if there's many armatures find the hips bone name for each armature
                    # if(len(armatures) > 1) and self.rig_preset.endswith(".py"):
                    #     self.hips_bone = prefix_ +":"+ preset_handler.get_preset_skel(self.rig_preset).spine.hips
                    break
                else:
                    break

            try:
                if armature.data.edit_bones[self.hips_bone]:
                    root_bone = armature.data.edit_bones.new(root_name)
                    root_bone.length = armature.data.edit_bones[self.hips_bone].length * 3
                    armature.data.edit_bones[self.hips_bone].parent = root_bone
                    #set setting
                    rig_settings = armature.data.retarget_retarget
                    if rig_settings:
                        rig_settings.root = root_name

            except KeyError:
                print(self.hips_bone + " not found in " + armature.name)


        bpy.ops.object.mode_set(mode= current_m)
        for o in bake_up:
            o.select_set(True, view_layer = context.view_layer)
        context.view_layer.objects.active = actif
        return {'FINISHED'}

def update_setting(self, context):
    o = ops.get_ob_or_armature(context, context.active_object)
    rig_settings = o.data.retarget_retarget
    if self.rig_preset != "--Current--":
        rig_settings = preset_handler.set_preset_skel(self.rig_preset, context)

    self.root_motion_bone = rig_settings.root
    self.motion_bone = rig_settings.spine.hips
    self.channel = rig_settings.spine.hips

class AddRootMotion(Operator):
    bl_idname = "armature.retarget_add_rootmotion"
    bl_label = "Transfer Root Motion"
    bl_description = "Bring Motion to Root Bone, ( apply the scale if there's problem )"
    bl_options = {'REGISTER', 'PRESET', 'UNDO'}

    rig_preset: EnumProperty(items=preset_handler.iterate_presets_with_current,
                             update=update_setting,
                             description="the rig preset it needed",
                             name="Target Preset",
                            )
    
    bone_or_channel: EnumProperty(items=[
        ('bone', "Bone", "Use Bone"),
        ('channel', "Channel", "Use Channel")],
                              name="Bone/Channel", default='bone')

    channel: StringProperty(name="Channel",
                                description="select Channel",
                                default="")
    #channel
    channelbag = None

    motion_bone: StringProperty(name="Motion",
                                description="select motion bone ( most of the time it's the hips bone )",
                                default="")

    del_keyframe: BoolProperty(name="Delete KeyFrame", default=False)

    position_x: BoolProperty(name="X",
                               description="Delete the Position X",
                               default=True)

    position_y: BoolProperty(name="Y",
                               description="Delete the Position Y",
                               default=True)

    position_z: BoolProperty(name="Z",
                               description="Delete the Position Z",
                               default=True)

    rotation_x: BoolProperty(name="X",
                               description="Delete the Rotation X",
                               default=False)

    rotation_y: BoolProperty(name="Y",
                               description="Delete the Rotation Y",
                               default=False)

    rotation_z: BoolProperty(name="Z",
                               description="Delete the Rotation Z",
                               default=False)

    scale_freeze: BoolProperty(name="Delete the scale",
                               description="Delete the Scale",
                               default=False)


    root_motion_bone: StringProperty(name="Root Motion",
                                     description="select the new motion bone ( root bone )",
                                     default="")

    new_anim_suffix: StringProperty(name="Suffix",
                                    default="",
                                    description="Suffix of the duplicate animation, leave empty to overwrite")

    obj_or_bone: EnumProperty(items=[
        ('object', "Object", "Transfer Root Motion To Object (Apply the Scale of the Armature)"),
        ('bone', "Bone", "Transfer Root Motion To Bone")],
                              name="Object/Bone", default='bone')

    keep_offset: BoolProperty(name="Keep Offset", default=False)
    offset_type: EnumProperty(items=[
        ('start', "Action Start", "Offset to Start Pose"),
        ('end', "Action End", "Offset to Match End Pose"),
        ('rest', "Rest Pose", "Offset to Match Rest Pose")],
                              name="Offset",
                              default='rest')

    root_cp_loc_x: BoolProperty(name="Root Copy Loc X", description="Copy Root X Location", default=True)
    root_cp_loc_y: BoolProperty(name="Root Copy Loc y", description="Copy Root Y Location", default=True)
    root_cp_loc_z: BoolProperty(name="Root Copy Loc Z", description="Copy Root Z Location", default=False)

    root_use_loc_min_x: BoolProperty(name="Use Root Min X", description="Use Minimum Root X Location", default=False)
    root_use_loc_min_y: BoolProperty(name="Use Root Min Y", description="Use Minimum Root Y Location", default=False)
    root_use_loc_min_z: BoolProperty(name="Use Root Min Z", description="Use Minimum Root Z Location", default=True)

    root_loc_min_x: FloatProperty(name="Root Min X", description="Minimum Root X Location", default=0.0)
    root_loc_min_y: FloatProperty(name="Root Min Y", description="Minimum Root Y Location", default=0.0)
    root_loc_min_z: FloatProperty(name="Root Min Z", description="Minimum Root Z Location", default=0.0)

    root_use_loc_max_x: BoolProperty(name="Use Root Max X", description="Use Maximum Root X Location", default=False)
    root_use_loc_max_y: BoolProperty(name="Use Root Max Y", description="Use Maximum Root Y Location", default=False)
    root_use_loc_max_z: BoolProperty(name="Use Root Max Z", description="Use Maximum Root Z Location", default=False)

    root_loc_max_x: FloatProperty(name="Root Max X", description="Maximum Root X Location", default=0.0)
    root_loc_max_y: FloatProperty(name="Root Max Y", description="Maximum Root Y Location", default=0.0)
    root_loc_max_z: FloatProperty(name="Root Max Z", description="Maximum Root Z Location", default=0.0)

    root_cp_rot_x: BoolProperty(name="Root Copy Rot X", description="Copy Root X Rotation", default=False)
    root_cp_rot_y: BoolProperty(name="Root Copy Rot y", description="Copy Root Y Rotation", default=False)
    root_cp_rot_z: BoolProperty(name="Root Copy Rot Z", description="Copy Root Z Rotation", default=False)

    root_cp_scal_x: BoolProperty(name="Root Copy Scal X", description="Copy Root X Scale", default=False)
    root_cp_scal_y: BoolProperty(name="Root Copy Scal y", description="Copy Root Y Scale", default=False)
    root_cp_scal_z: BoolProperty(name="Root Copy Scal Z", description="Copy Root Z Scale", default=False)

    _armature = None
    _prop_indent = 0.15

    custom_Frame: IntProperty(name="Frame",
                               description=" To test the animation ",
                              default=1)
    
    play: BoolProperty(name= "PLAY", default=True)

    action_range: BoolProperty(name= "Action Range to Scene",
                               description="Set Playback range to current action Start/End",
                               default=True)

    transfert_root: BoolProperty(name= "Transfer Root Motion",
                               description="Clic here to transfer",
                               default=False, options={'SKIP_SAVE'})

    #similar

    show_10: BoolProperty(name="",
                          description="Show Those Action",
                                default=True)
    
    show_all: BoolProperty(name="",
                           description="SHow All Action",
                                default=False, options={'SKIP_SAVE'})

    bake_similar:BoolProperty(name="Include Similar Action",
                              description="convert other action",
                                default=False)
    #-----
    only_selected_action: BoolProperty(name="Only Selected Action(s)",
                                description= "Only selected Action(s) in Action Manager",
                                default=False)
    
    by_name: BoolProperty(name="by Name",
                            description= "Only Look for Action with this Prefix/Suffix",
                            default=False)
    
    include: EnumProperty(items=[
        ('include', "Include", "Include Action with this Prefix/Suffix"),
        ('exclude', "Exclude", "Exclude Action with this Prefix/Suffix")
         ],
        name="",
        default='include')
    
    prefix: StringProperty(name="prefix",
                                description= "Prefix (comma is the separator)",
                                default="")
    
    contain: StringProperty(name="Contain",
                                  description= "Contain (comma is the separator)",
                                 default="")
    
    suffix: StringProperty(name="suffix",
                                 description= "Suffix (comma is the separator)",
                                default="")
    
    #list 

    action_select: BoolProperty(name="Action",
                               description= "Select between Actions",
                               default=False)
    
    include_a: EnumProperty(items=[
        ('include', "Include", "Include Actions"),
        ('exclude', "Exclude", "Exclude Actions")
         ],
        name="",
        default='include')
    
    action_l: StringProperty(name = "",
                              description=" Actions List",
                              default="", options = {'SKIP_SAVE'})

    clean_all:  BoolProperty(name="",
                              description="Delete All",
                             default=False, options = {'SKIP_SAVE'})

    clean_last:  BoolProperty(name="",
                              description="Delete the last one",
                              default=False, options = {'SKIP_SAVE'})

    action_collection = []

    number_trg = dict()

    @classmethod
    def poll(cls, context):
        o = ops.get_ob_or_armature(context, context.active_object)
        if not o:
            return False
        if o.type != 'ARMATURE':
            return False
    
        return True

    def draw(self, context):
        layout = self.layout
        column = layout.column()

        o = ops.get_ob_or_armature(context, context.active_object)

        #test if its local
        if o.library is not None:
            column.label(text=f"make '{o.name}' local", icon='ERROR')
            column.separator()

        if self.bake_similar and self.number_trg:

            for ob_name, action_valid in self.number_trg.items():
                column.label(text=f"Transfert Root to {len(action_valid)} Actions of {ob_name}")

                show_10 = 5

                if self.show_10 and not self.show_all and action_valid:

                    i = 1
                    for action in action_valid:
                        if i > show_10:
                            break
                        column.label(text=f"- {action.name} ")
                        i += 1

                if self.show_all and action_valid:

                    for action in action_valid:
                        column.label(text=f"- {action.name} ")

                if (not self.show_all and len(action_valid) >= 1) or (self.show_10 and len(action_valid) > show_10):
                    
                    row = column.split(factor=0.80, align=True)
                    row.label(text="")

                    if not self.show_all and len(action_valid) >= 1 :
                        row.prop(self, "show_10", toggle=True, icon='DOWNARROW_HLT')

                    if self.show_10 and len(action_valid) > show_10 :
                        row.prop(self, "show_all", toggle=True, icon='DOWNARROW_HLT')
            column.separator()
        else:
            #show number
            armatures = ops.get_selected_obs(context)
            num = 0
            for armature in armatures:

                if armature.type != 'ARMATURE':
                    continue
                num += 1
            if num > 1:
                column.label(text=f"{num} Armatures Selected")
                column.separator()

        row = column.row()
        row.prop(self, 'rig_preset', text="Rig Type:")

        split = column.split(factor=self._prop_indent, align=True)
        split.label(text="From")
        col = split.column()
        col.prop(self, 'bone_or_channel', expand=True)

        if self.bone_or_channel == "bone":

            col.prop_search(self, 'motion_bone',
                            o.data,
                            "bones", text="")
        else:
            channelbag = None
            
            action = o.animation_data.action
            slot = o.animation_data.action_slot
            if slot:
                channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)

            if channelbag:

                col.prop_search(self, 'channel',
                                channelbag,
                                "groups", text="")

        row = column.row(align=False)
        row.prop(self, "del_keyframe")

        if self.del_keyframe:

            row = column.row(align=True)
            row.label(text="Location")
            row.prop(self, "position_x", text="X", toggle=True)
            row.prop(self, "position_y", text="Y", toggle=True)
            row.prop(self, "position_z", text="Z", toggle=True)

            row = column.row(align=True)
            row.label(text="Rotation")
            row.prop(self, "rotation_x", text="X", toggle=True)
            row.prop(self, "rotation_y", text="Y", toggle=True)
            row.prop(self, "rotation_z", text="Z", toggle=True)

            row = column.split(factor=0.20, align=True)
            row.label(text="Scale")
            row.prop(self, "scale_freeze", text="Delete the Scale", toggle=True)

        #separator
        row = column.row()
        row.label(text="")

        split = column.split(factor=self._prop_indent, align=True)
        split.label(text="To")

        col = split.column()
        col.prop(self, 'obj_or_bone', expand=True)

        if self.obj_or_bone == "bone":

            col.prop_search(self, 'root_motion_bone',
                                o.data,
                                "bones", text="")

        row = column.split(factor=self._prop_indent, align=True)
        row.label(text="Suffix:")
        row.prop(self, 'new_anim_suffix', text="")

        column.separator()

        row = column.row(align=False)
        row.prop(self, "keep_offset")
        subcol = row.column()
        subcol.prop(self, "offset_type", text="Match ")
        subcol.enabled = self.keep_offset

        row = column.row(align=True)
        row.label(text="Location")
        row.prop(self, "root_cp_loc_x", text="X", toggle=True)
        row.prop(self, "root_cp_loc_y", text="Y", toggle=True)
        row.prop(self, "root_cp_loc_z", text="Z", toggle=True)

        row = column.row(align=True)
        row.label(text="Rotation Plane")
        row.prop(self, "root_cp_rot_x", text="X", toggle=True)
        row.prop(self, "root_cp_rot_y", text="Y", toggle=True)
        row.prop(self, "root_cp_rot_z", text="Z", toggle=True)

        row = column.row(align=True)
        row.label(text="Scale")
        row.prop(self, "root_cp_scal_x", text="X", toggle=True)
        row.prop(self, "root_cp_scal_y", text="Y", toggle=True)
        row.prop(self, "root_cp_scal_z", text="Z", toggle=True)

        column.separator()

        # Min/Max X
        row = column.row(align=True)
        row.prop(self, "root_use_loc_min_x", text="Min X")

        subcol = row.column()
        subcol.prop(self, "root_loc_min_x", text="")
        subcol.enabled = self.root_use_loc_min_x

        row.separator()
        row.prop(self, "root_use_loc_max_x", text="Max X")
        subcol = row.column()
        subcol.prop(self, "root_loc_max_x", text="")
        subcol.enabled = self.root_use_loc_max_x
        row.enabled = self.root_cp_loc_x

        # Min/Max Y
        row = column.row(align=True)
        row.prop(self, "root_use_loc_min_y", text="Min Y")

        subcol = row.column()
        subcol.prop(self, "root_loc_min_y", text="")
        subcol.enabled = self.root_use_loc_min_y

        row.separator()
        row.prop(self, "root_use_loc_max_y", text="Max Y")
        subcol = row.column()
        subcol.prop(self, "root_loc_max_y", text="")
        subcol.enabled = self.root_use_loc_max_y
        row.enabled = self.root_cp_loc_y

        # Min/Max Z
        row = column.row(align=True)
        row.prop(self, "root_use_loc_min_z", text="Min Z")

        subcol = row.column()
        subcol.prop(self, "root_loc_min_z", text="")
        subcol.enabled = self.root_use_loc_min_z

        row.separator()
        row.prop(self, "root_use_loc_max_z", text="Max Z")
        subcol = row.column()
        subcol.prop(self, "root_loc_max_z", text="")
        subcol.enabled = self.root_use_loc_max_z
        row.enabled = self.root_cp_loc_z

        column.separator()

        row = column.row()
        row.prop(self, "bake_similar")
        
        if self.bake_similar:

            row = column.row()
            row.prop(self, "only_selected_action")

            row = column.row()
            row.prop(self, "by_name")

            if self.by_name:
                subcol = row.column()
                subcol.prop(self, 'include')

                row = column.row()
                col = row.column()
                col.label(text="Prefix")
                col.prop(self, 'prefix', text="")

                col = row.column()
                col.label(text="Contain:")
                col.prop(self, 'contain', text="")

                col = row.column()
                col.label(text="Suffix:")
                col.prop(self, 'suffix', text="")

            row = column.row()
            row.prop(self, "action_select")

            if self.action_select:

                subcol = row.column()
                subcol.prop(self, 'include_a')

                row = column.split(factor=0.80, align=True)
                row.prop_search(self, 'action_l',
                            bpy.data,
                            "actions")
                
                row.prop(self, 'action_l')
                row.prop(self, 'clean_all', toggle=True, icon='PANEL_CLOSE')
                row.prop(self, 'clean_last',toggle=True, icon='TRACKING_CLEAR_BACKWARDS')

                i = 0
                row = column.split(factor=0.33, align=True)

                for act in self.action_collection:
                    if i == 3:
                        row = column.split(factor=0.33, align=True)
                        i = 0

                    row.label(text=act, icon='ACTION')

                    i += 1

        column.separator()

        row = column.split(factor=0.33, align=True)
        row.prop(self, "custom_Frame", text="Frame")
        row.prop(self, "play", toggle=True, icon='PLAY')
        row.prop(self, "action_range", toggle=True, icon='PREVIEW_RANGE')

        row = column.row(align=True)
        row.prop(self, "transfert_root", toggle=True, icon='ARMATURE_DATA')

    def correct_action(self, action, context):

        if not self.bake_similar:
            return True
        
        if self.only_selected_action:
            selected_act = selected_action(context)
            if not action in selected_act:
                return False

        incl = -1
        incls = -1
        inclc = -1

        
        if self.by_name:
            if self.include == 'include':
                if self.prefix:
                    list_ = self.prefix.split(",")
                    incl = 0
                    for li in list_:
                        if li and not action.name.startswith(li):
                            incl -= 1
                        if li and action.name.startswith(li):
                            incl += 1
                    if incl < 0:
                        return self.test_list_action(action)

                if self.suffix:
                    list_ = self.suffix.split(",")
                    incls = 0
                    for li in list_:
                        if li and not action.name.endswith(li):
                            incls -= 1
                        if li and action.name.endswith(li):
                            incls += 1
                    if incls < 0:
                        return self.test_list_action(action)
                    
                if self.contain:
                    list_ = self.contain.split(",")
                    inclc = 0
                    for li in list_:
                        if li and not li in action.name:
                            inclc -= 1
                        if li and li in action.name:
                            inclc += 1
                    if inclc < 0:
                        return self.test_list_action(action)
            
            else:
                if self.prefix:
                    list_ = self.prefix.split(",")
                    for li in list_:
                        if li and action.name.startswith(li):
                            return False

                if self.suffix:
                    list_ = self.suffix.split(",")
                    for li in list_:
                        if li and action.name.endswith(li):
                            return False

                if self.contain:
                    list_ = self.contain.split(",")
                    for li in list_:
                        if li and li in action.name:
                            return False
        
        if self.action_select:

            if self.include_a == 'include':

                if self.action_collection and action.name not in self.action_collection:
                    return False or (incl >= 0 or incls >= 0 or inclc >= 0)
            
            elif self.action_collection and action.name in self.action_collection:
                return False
        
        return True
    
    def test_list_action(self, action):
        if self.action_select:
            if self.include_a == 'include':

                if self.action_collection and action.name in self.action_collection:
                    return True
        return False

    def _set_defaults(self, context, rig_settings, force = False):

        if not rig_settings:
            return
        
        o = ops.get_ob_or_armature(context, context.active_object)

        if force or (not self.root_motion_bone and rig_settings.root in o.pose.bones):
            self.root_motion_bone = rig_settings.root

        if force or (not self.motion_bone and rig_settings.spine.hips in o.pose.bones):
            self.motion_bone = rig_settings.spine.hips
            self.channel = rig_settings.spine.hips

    def invoke(self, context, event):

        """Fill root and hips field according to character settings"""
        self._rootbo_transfs = []

        self._rootbo_transfs_local = []

        self._hip_bone_transfs = []
        self._all_floating_mats = []

        self._stored_motion_bone = ""
        self._stored_channel = ""
        self._stored_motion_type = self.obj_or_bone
        self._transforms_stored = False

        #reset variable

        o = ops.get_ob_or_armature(context, context.active_object)

        if o.data.retarget_retarget.has_settings():
            self.rig_preset = '--Current--'

        else:
            self.rig_preset = preset_handler.findPreset(o)

        if self.root_motion_bone and self.root_motion_bone not in o.pose.bones:
            self.root_motion_bone = ""

        if self.motion_bone and self.motion_bone not in o.pose.bones:
            self.motion_bone = ""

        if self.channel:
            channelbag = None
            action = o.animation_data.action
            slot = o.animation_data.action_slot
            if slot:
                channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)
            if not channelbag or (channelbag and self.channel not in channelbag.groups):
                self.channel = ""

        #init the custom_Frame
        self.custom_Frame = context.scene.frame_current

        rig_settings = o.data.retarget_retarget
        if self.rig_preset != "--Current--":
            rig_settings = preset_handler.set_preset_skel(self.rig_preset, context)


        self._set_defaults(context, rig_settings)

        return self.execute(context)

    def init(self, context):
        self._stored_motion_bone = ""
        self._stored_channel = ""
        self._stored_motion_type = self.obj_or_bone
        self._transforms_stored = False

        self._store_transforms(context)


    def _get_floating_bones(self, context):
        arm_ob = context.active_object

        # TODO: check controls with animation curves instead
        def consider_bone(bone):
            if self.root_motion_bone and bone.name == self.root_motion_bone and self.obj_or_bone == "bone":
                return False
            
            for child_of_cns in reversed(bone.constraints):
                if child_of_cns.influence == 1.0 and not child_of_cns.mute:
                    return False

            return bone.name in arm_ob.pose.bones

        rig_bones = [bone for bone in arm_ob.pose.bones if bone and consider_bone(bone)]

        motion_bone = self.motion_bone
        if not self.motion_bone:
            if self.channel in arm_ob.pose.bones:
                motion_bone = self.channel
            else:
                for bone in arm_ob.pose.bones:
                    motion_bone = bone.name
                    break

        list_float = list()

        #find floating bone
        for bone in rig_bones:
            tmp = bone
            its_float = True
            while tmp.parent:
                
                if tmp.parent.name == motion_bone:
                    its_float = False
                    break
                if tmp in list_float:
                    its_float = False
                    break
                tmp = tmp.parent

            if its_float:
                list_float.append(bone)

        return list_float

    def _clear_cache(self):
        self._all_floating_mats.clear()
        self._hip_bone_transfs.clear()
        self._rootbo_transfs_local.clear()

        self._rootbo_transfs.clear()

    def _store_transforms(self, context):
        self._clear_cache()
        arm_ob = context.active_object

        try:
            if self.bone_or_channel == "channel":
                if self.channel in arm_ob.pose.bones:
                    hip_bone = arm_ob.pose.bones[self.channel]
                else:
                    hip_bone = arm_ob
            else:
                hip_bone = arm_ob.pose.bones[self.motion_bone]
        except KeyError:
            return
        if self.obj_or_bone == 'bone' and self.root_motion_bone:
            root_bone = arm_ob.pose.bones[self.root_motion_bone]
        else:
            root_bone = arm_ob

        floating_bones = self._get_floating_bones(context)

        start, end = self._get_start_end(context)

        current_position = arm_ob.data.pose_position

        if self.offset_type == 'start':
            context.scene.frame_set(start)
        elif self.offset_type == 'end':
            context.scene.frame_set(end)
        else:
            arm_ob.data.pose_position = 'REST'

        context.scene.frame_set(start)
        arm_ob.data.pose_position = current_position

        for frame_num in range(start, end + 1):

            context.scene.frame_set(frame_num)

            if self.bone_or_channel == "channel" and not self.channel in arm_ob.pose.bones:
                self._hip_bone_transfs.append( hip_bone.matrix_world.copy())
                #TODO fix this
                self._all_floating_mats.append(list([ arm_ob.matrix_world.copy() @  b.matrix.copy() for b in floating_bones]))
            else:
                self._hip_bone_transfs.append(hip_bone.matrix.copy())

                self._all_floating_mats.append(list([b.matrix.copy() for b in floating_bones]))


            if self.obj_or_bone == 'object':
                self._rootbo_transfs.append(root_bone.matrix_world.copy())
                self._rootbo_transfs_local.append( root_bone.matrix_world.copy() )

            else:
                self._rootbo_transfs.append(root_bone.matrix.copy())
                self._rootbo_transfs_local.append(arm_ob.matrix_world.copy() @ root_bone.matrix.copy().inverted())

        self._stored_motion_bone = self.motion_bone
        self._stored_channel = self.channel
        self._stored_motion_type = self.obj_or_bone
        self._transforms_stored = True

    def _cache_dirty(self):
        if self._stored_motion_bone != self.motion_bone:
            return True
        if self._stored_channel != self.channel:
            return True
        if self._stored_motion_type != self.obj_or_bone:
            return True

        return False

    preset_updater = ""

    def execute(self, context):

        o = ops.get_ob_or_armature(context, context.active_object)
        #test if its local
        if o.library is not None:
            return {'FINISHED'}

        self.number_trg.clear()

        bake_up = list(context.selected_objects)

        current_m = context.mode
        
        actif =  context.active_object

        armatures = ops.get_selected_obs(context)
        for ob in armatures:

            if ob.type != 'ARMATURE':
                continue

            if ob.library is not None:
                continue

            context.view_layer.objects.active = ob
            bpy.ops.object.mode_set(mode='POSE')

            actions = []
            if self.bake_similar:
                actions = [action for action in bpy.data.actions if action and validate_actions(action, ob.path_resolve) and self.correct_action(action, context)]
                self.number_trg[ob.name] = actions
            else:
                if ob.animation_data and ob.animation_data.action:
                    actions.append(ob.animation_data.action)

            #force setting on second object forward
            if o != ob:
                rig_settings = ob.data.retarget_retarget
                if self.rig_preset != "--Current--":
                    rig_settings = preset_handler.set_preset_skel(self.rig_preset, context)
                self._set_defaults(context, rig_settings, force = True)

            if not self.root_motion_bone in ob.pose.bones and self.obj_or_bone == "bone":
                continue

            if not self.motion_bone in ob.pose.bones and self.bone_or_channel == "bone":
                continue

            if not self.channel and self.bone_or_channel == "channel":
                continue

            if not self.transfert_root:
                bpy.ops.object.mode_set(mode=current_m)
                if self.play and not context.screen.is_animation_playing:
                    bpy.ops.screen.animation_play()
                continue

            for action in actions:

                if not action:
                    continue

                if not ob.animation_data:
                    ob.animation_data_create()

                ob.animation_data.action = action

                #no need 

                # if self.obj_or_bone == "bone":
                #     root = ob.pose.bones[self.root_motion_bone]
                #     root.matrix_basis = Matrix()

                if not ob.animation_data.action_slot:
                    for slot in action.slots:
                        if ops.validate_slot(action, slot, ob.path_resolve, armature= bool(ob.type == "'ARMATURE'")):
                            ob.animation_data.action_slot = slot
                            break

                if not ob.animation_data.action_slot:
                    continue

                self.channelbag = anim_utils.action_get_channelbag_for_slot(action, ob.animation_data.action_slot)

                if not self.channelbag and self.bone_or_channel == "channel":
                    continue

                if self.new_anim_suffix:
                    action_dupli = ob.animation_data.action.copy()

                    action_name = ob.animation_data.action.name
                    action_dupli.name = f'{action_name}{self.new_anim_suffix}'
                    action_dupli.use_fake_user = ob.animation_data.action.use_fake_user
                    ob.animation_data.action = action_dupli

                    self.channelbag = anim_utils.action_get_channelbag_for_slot(action_dupli, ob.animation_data.action_slot)

                self.init(context)

                #if self._cache_dirty():
                #    self._store_transforms(context)

                if not self._transforms_stored:
                    self.report({'WARNING'}, "No transforms stored")

                self.action_offs(context, current_m)

                if self.del_keyframe :
                    self.del_Keyframe_f(context)

                start, end = self._get_start_end(context)
                context.scene.frame_set(start)

        o = ops.get_ob_or_armature(context, context.active_object)
        
        if self.action_range and o.animation_data and o.animation_data.action:
            bpy.ops.object.retarget_action_to_range()

        if self.custom_Frame != context.scene.frame_current:
            context.scene.frame_current = self.custom_Frame

        bpy.ops.object.mode_set(mode= current_m)
        if self.play and not context.screen.is_animation_playing:
            bpy.ops.screen.animation_play()
        for o in bake_up:
            o.select_set(True, view_layer = context.view_layer)
        context.view_layer.objects.active = actif
        return {'FINISHED'}

    def del_Keyframe_f(self, context):

        if self.bone_or_channel == "channel":
            bone_name = self.channel
            bone = context.active_object
        else:
            bone_name = self.motion_bone
            bone = context.active_object.pose.bones[bone_name]

        # if self.obj_or_bone == "bone" and bone_name == self.root_motion_bone:
        #     return

        if self.channelbag and bone_name in self.channelbag.groups:

            group = self.channelbag.groups[bone_name]
            del_fc = []
            axis_names = ["X", "Y", "Z"]
            quat_names = ["W", "X", "Y", "Z"] # For quaternion rotations

            for fcurve in group.channels:
                data_path = fcurve.data_path

                if self.bone_or_channel == "bone" and not bone_name in data_path:
                    continue

                if 'location' in data_path:

                    if axis_names[fcurve.array_index] =="X" and not self.position_x:
                        continue

                    if axis_names[fcurve.array_index] =="Y" and not self.position_y:
                        continue

                    if axis_names[fcurve.array_index] =="Z" and not self.position_z:
                        continue

                if 'rotation' in data_path:

                    if data_path.endswith('rotation_quaternion')  or data_path.endswith('rotation_axis_angle'):

                        if quat_names[fcurve.array_index] =="W" and (not self.rotation_x or not self.rotation_y or not self.rotation_z):
                            continue

                        if quat_names[fcurve.array_index] =="X" and not self.rotation_x:
                            continue

                        if quat_names[fcurve.array_index] =="Y" and not self.rotation_y:
                            continue

                        if quat_names[fcurve.array_index] =="Z" and not self.rotation_z:
                            continue
                    else:
                        if axis_names[fcurve.array_index] =="X" and not self.rotation_x:
                            continue

                        if axis_names[fcurve.array_index] =="Y" and not self.rotation_y:
                            continue

                        if axis_names[fcurve.array_index] =="Z" and not self.rotation_z:
                            continue

                if 'scale' in data_path and not self.scale_freeze:
                    continue

                del_fc.append(fcurve)

            for fc in reversed(del_fc):
                self.channelbag.fcurves.remove(fc)

            bone.location[0] = 0
            bone.location[1] = 0
            bone.location[2] = 0


    @staticmethod
    def _get_start_end(context):
        action = context.active_object.animation_data.action
        start, end = action.frame_range

        return int(start), int(end)

    def action_offs(self, context, current_m):
        start, end = self._get_start_end(context)
        current = context.scene.frame_current

        if self.bone_or_channel == "channel":
            if self.channel in context.active_object.pose.bones:
                hip_bone = context.active_object.pose.bones[self.channel]
            else:
                hip_bone = context.active_object
        else:
            hip_bone = context.active_object.pose.bones[self.motion_bone]

        if self.keep_offset and self.offset_type == 'end':
            context.scene.frame_set(end)
            if self.bone_or_channel == "channel" and not self.channel in context.active_object.pose.bones:
                end_mat = hip_bone.matrix_world.copy()
            else:
                end_mat = hip_bone.matrix.copy()
        else:
            end_mat = Matrix()

        context.scene.frame_set(start)

        if self.bone_or_channel == "channel" and not self.channel in context.active_object.pose.bones:
            start_mat = hip_bone.matrix_world.copy()
        else:
            start_mat = hip_bone.matrix.copy()

        start_mat_inverse = start_mat.inverted()

        if self.keep_offset:
            if self.offset_type == 'rest':
                if self.bone_or_channel == "channel" and not self.channel in context.active_object.pose.bones:
                    offset_mat = context.active_object.data.matrix_local.inverted()
                else:
                    offset_mat = context.active_object.data.bones[hip_bone.name].matrix_local.inverted()
            elif self.offset_type == 'start':
                offset_mat = start_mat_inverse
            elif self.offset_type == 'end':
                offset_mat = end_mat.inverted()
        else:
            offset_mat = Matrix()


        if self.obj_or_bone == 'object':
            root_bone = context.active_object
        else:
            root_bone_name = ""
            if self.root_motion_bone:
                root_bone_name = self.root_motion_bone
            try:
                root_bone = context.active_object.pose.bones[root_bone_name]
            except (TypeError, KeyError):
                self.report({'WARNING'}, f"{root_bone_name} not found in target")
                bpy.ops.object.mode_set(mode=current_m)
                return {'FINISHED'}

        context.scene.frame_set(start)
        keyframe_options = {'INSERTKEY_VISUAL', 'INSERTKEY_CYCLE_AWARE'}

        add_loc_rot_key(root_bone, start, keyframe_options)

        if any((self.root_cp_scal_x, self.root_cp_scal_y, self.root_cp_scal_z)):
            add_scal_key(root_bone, start, keyframe_options)

        root_matrix = root_bone.matrix if self.obj_or_bone == 'bone' else context.active_object.matrix_world
        for i, frame_num in enumerate(range(start, end + 1)):
            context.scene.frame_set(frame_num)
            
            rootmo_transf = self._hip_bone_transfs[i] @ offset_mat

            if self.root_cp_loc_x:
                if self.root_use_loc_min_x:
                    rootmo_transf[0][3] = max(rootmo_transf[0][3], self.root_loc_min_x)
                if self.root_use_loc_max_x:
                    rootmo_transf[0][3] = min(rootmo_transf[0][3], self.root_loc_max_x)
            else:
                rootmo_transf[0][3] = root_matrix[0][3]
            if self.root_cp_loc_y:
                if self.root_use_loc_min_y:
                    rootmo_transf[1][3] = max(rootmo_transf[1][3], self.root_loc_min_y)
                if self.root_use_loc_max_y:
                    rootmo_transf[1][3] = min(rootmo_transf[1][3], self.root_loc_max_y)
            else:
                rootmo_transf[1][3] = root_matrix[1][3]
            if self.root_cp_loc_z:
                if self.root_use_loc_min_z:
                    rootmo_transf[2][3] = max(rootmo_transf[2][3], self.root_loc_min_z)
                if self.root_use_loc_max_z:
                    rootmo_transf[2][3] = min(rootmo_transf[2][3], self.root_loc_max_z)
            else:
                rootmo_transf[2][3] = root_matrix[2][3]

            if self.root_cp_rot_x + self.root_cp_rot_y + self.root_cp_rot_z < 2:
                # need at least two axis to make this work, don't use rotation

                #set the offset
                mat_trans = mathutils.Matrix.Translation((offset_mat[0][3],offset_mat[1][3],offset_mat[2][3]))
                if offset_mat == Matrix():
                    no_rot = self._rootbo_transfs[i]
                else:
                    tmp = self._rootbo_transfs[i]
                    no_rot =  mat_trans @ tmp
                    # no_rot = tmp  @ offset_mat
                    # no_rot[0][2] = tmp[0][2]
                    # no_rot[1][2] = tmp[1][2]
                    # no_rot[2][2] = tmp[2][2]

                no_rot[0][3] = rootmo_transf[0][3]
                no_rot[1][3] = rootmo_transf[1][3]
                no_rot[2][3] = rootmo_transf[2][3]

                rootmo_transf = no_rot
            else:
                rootmo_transf.transpose()
                root_transp = root_matrix.transposed()

                if not self.root_cp_rot_z:
                    # XY plane
                    rootmo_transf[1][2] = root_transp[1][2]
                    rootmo_transf[0][2] = root_transp[0][2]

                    y_axis = rootmo_transf[1].to_3d()
                    y_axis.normalize()

                    x_axis = y_axis.cross(root_transp[2].to_3d())
                    x_axis.normalize()

                    z_axis = x_axis.cross(y_axis)
                    z_axis.normalize()
                elif not self.root_cp_rot_x:
                    # ZY plane
                    rootmo_transf[1][0] = root_transp[1][0]
                    rootmo_transf[2][0] = root_transp[2][0]

                    z_axis = rootmo_transf[2].to_3d().normalized()
                    up = root_transp[1].to_3d()
                    x_axis = up.cross(z_axis).normalized()
                    y_axis = z_axis.cross(x_axis)
                    y_axis.normalize()
                else:
                    # XZ plane
                    rootmo_transf[2][1] = root_transp[2][1]
                    rootmo_transf[0][1] = root_transp[0][1]

                    z_axis = rootmo_transf[2].to_3d().normalized()
                    up = root_transp[1].to_3d()
                    x_axis = up.cross(z_axis).normalized()
                    y_axis = z_axis.cross(x_axis)

                rootmo_transf[0] = x_axis.to_4d()
                rootmo_transf[1] = y_axis.to_4d()
                rootmo_transf[2] = z_axis.to_4d()

                rootmo_transf.transpose()

            if any ((self.root_cp_scal_x, self.root_cp_scal_y, self.root_cp_scal_z)):

                rot_tmp = self._rootbo_transfs[i]

                if self.root_cp_scal_x:
                    rootmo_transf[1][1] = rot_tmp[1][1]
                    rootmo_transf[2][1] = rot_tmp[2][1]

                if self.root_cp_scal_y:
                    rootmo_transf[0][1] = rot_tmp[0][1]
                    rootmo_transf[2][1] = rot_tmp[2][1]

                if self.root_cp_scal_z:
                    rootmo_transf[0][1] = rot_tmp[0][1]
                    rootmo_transf[1][1] = rot_tmp[1][1]


            if self.obj_or_bone == 'object':
                root_bone.matrix_world = rootmo_transf
            else:
                root_bone.matrix = rootmo_transf

            add_loc_key(root_bone, frame_num, keyframe_options)

            if any((self.root_cp_rot_x, self.root_cp_rot_y, self.root_cp_rot_z)):
                add_rot_key(root_bone, frame_num, keyframe_options)

            if any((self.root_cp_scal_x, self.root_cp_scal_y, self.root_cp_scal_z)):
                add_scal_key(root_bone, frame_num, keyframe_options)


        floating_bones = self._get_floating_bones(context)
        for i, frame_num in enumerate(range(start, end + 1)):
            context.scene.frame_set(frame_num)

            if self.obj_or_bone == 'object' and self.root_motion_bone:
                context.active_object.pose.bones[self.root_motion_bone].matrix = root_bone.matrix_world.inverted() @ context.active_object.pose.bones[self.root_motion_bone].matrix

            floating_mats = self._all_floating_mats[i]
            for bone, mat in zip(floating_bones, floating_mats):
                if self.obj_or_bone == 'object':
                    # TODO: should get matrix at frame 0
                    mat = root_bone.matrix_world.inverted() @ mat

                bone.matrix = mat
                add_loc_rot_key(bone, frame_num, set())
        
        #do linear 
        action = context.active_object.animation_data.action
        slot = context.active_object.animation_data.action_slot
        channelbag = anim_utils.action_get_channelbag_for_slot(action,slot)
        if channelbag:
            for fcurve in channelbag.fcurves:

                if not fcurve.group:
                    continue
                
                validate = False
                if root_bone.name in fcurve.group.name:
                    validate = True
                else:
                    try:
                        root_bone.path_resolve(fcurve.data_path)
                        validate = True
                    except:
                        pass
                
                if not validate:
                    for bone in floating_bones:
                        if bone.name in fcurve.group.name:
                            validate = True
                            break
                if not validate:
                    continue

                for kf in fcurve.keyframe_points:
                    kf.interpolation = 'LINEAR'
                fcurve.keyframe_points.deduplicate()
                fcurve.update()

        context.scene.frame_set(current)


classes = (
	 ActionRangeToScene,
     ActionNlaRangeToScene,
     AdjustAnimation,
	 ConstraintStatus,
	 SelectConstrainedControls,
	 AlignBone,
	 ConvertBoneNaming,
	 ConvertGameFriendly,
	 ExtractMetarig,
     BindToMetarig,
	 MergeHeadTails,
	 ConstrainToArmature,
     UnbindArmature,
	 BakeConstrainedActions,
     ActionNameCandidates,
     RenameActionsFromFbxFiles,
     Mirror,
     ApplyAsRestPose,
     ApplyRotation,
	 CreateTransformOffset,
	 AddRoot,
	 AddRootMotion,

)


def register_classes():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Action.retarget_name_candidates = bpy.props.CollectionProperty(type=ActionNameCandidates)


def unregister_classes():

    del bpy.types.Action.retarget_name_candidates

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)