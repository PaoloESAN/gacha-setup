from __future__ import annotations

"""UEFormat v10 (AttributeFormatRestructure) model reader.

This module intentionally stays separate from the legacy reader so the existing
Blender-side import code and all custom changes remain untouched for UEFormat <= 9.
"""

import numpy as np

from .classes import (
    Bone,
    ConvexCollision,
    Material,
    MorphTarget,
    MorphTargetData,
    Socket,
    UEModel,
    UEModelLOD,
    UEModelSkeleton,
    UEModelSkeletonMetadata,
    VertexColor,
    VirtualBone,
    Weight,
)
from .reader import FArchiveReader
from ..logging import Log


def iter_attributes(ar: FArchiveReader):
    """Yield (name, bounded reader) for a v10 attribute set."""
    count = ar.read_int()
    for _ in range(count):
        name = ar.read_fstring()
        byte_size = ar.read_int()
        yield name, ar.chunk(byte_size)


def _mirror_pos(value, scale: float):
    return np.asarray(value) * scale * (1, -1, 1)


def _mirror_normal(value):
    return np.asarray(value) * (1, -1, 1)


def _mirror_quat(value):
    return np.asarray(value) * (1, -1, 1, -1)


def read_material(ar: FArchiveReader) -> Material:
    return Material(
        material_name=ar.read_fstring(),
        material_path=ar.read_fstring(),
        first_index=ar.read_int(),
        num_faces=ar.read_int(),
    )


def read_weight(ar: FArchiveReader) -> Weight:
    # v10 explicitly serializes the bone index as uint16.
    return Weight(
        bone_index=ar.read_short() & 0xFFFF,
        vertex_index=ar.read_int(),
        weight=ar.read_float(),
    )


def read_morph_delta(ar: FArchiveReader, scale: float) -> MorphTargetData:
    return MorphTargetData(
        position=_mirror_pos(ar.read_float_vector(3), scale),
        normals=_mirror_normal(ar.read_float_vector(3)),
        vertex_index=ar.read_int(),
    )


def read_morph(ar: FArchiveReader, scale: float) -> MorphTarget:
    name = ar.read_fstring()
    deltas = ar.read_serialized_array(lambda r: read_morph_delta(r, scale))
    return MorphTarget(name=name, deltas=deltas)


def read_vertex_color(ar: FArchiveReader) -> VertexColor:
    name = ar.read_fstring()
    count = ar.read_int()
    data = (np.array(ar.read_byte_vector(count * 4)).reshape(count, 4) / 255).astype(np.float32)
    return VertexColor(name, data)


def read_lod(ar: FArchiveReader, scale: float) -> UEModelLOD:
    data = UEModelLOD(name=ar.read_fstring())

    for name, payload in iter_attributes(ar):
        if name == "VERTICES":
            count = payload.read_int()
            data.vertices = _mirror_pos(
                np.array(payload.read_float_vector(count * 3)).reshape(count, 3),
                scale,
            )

        elif name == "NORMALS":
            count = payload.read_int()
            flattened = np.array(payload.read_float_vector(count * 4))
            data.normals = _mirror_normal(flattened.reshape(-1, 4)[:, 1:])

        elif name == "TANGENTS":
            # Current legacy Blender importer does not consume tangent data.
            pass

        elif name == "TEXCOORDS":
            data.uvs = []
            channel_count = payload.read_int()
            for _ in range(channel_count):
                # v10 stores a channel name before the UV array.
                payload.read_fstring()
                uv_count = payload.read_int()
                uvs = np.array(payload.read_float_vector(uv_count * 2)).reshape(uv_count, 2)
                uvs = uvs * (1, -1) + (0, 1)
                data.uvs.append(uvs)

        elif name == "INDICES":
            count = payload.read_int()
            data.indices = np.array(payload.read_int_vector(count), dtype=np.int32).reshape(count // 3, 3)

        elif name == "VERTEXCOLORS":
            data.colors = payload.read_serialized_array(read_vertex_color)

        elif name == "MATERIALS":
            data.materials = payload.read_serialized_array(read_material)

        elif name == "WEIGHTS":
            data.weights = payload.read_serialized_array(read_weight)

        elif name == "MORPHTARGETS":
            data.morphs = payload.read_serialized_array(lambda r: read_morph(r, scale))

        else:
            Log.warn(f"Unknown v10 LOD attribute: {name}")

    return data


def read_bone(ar: FArchiveReader, scale: float) -> Bone:
    name = ar.read_fstring()
    parent_index = ar.read_int()
    position = _mirror_pos(ar.read_float_vector(3), scale)
    rotation = _mirror_quat(ar.read_float_vector(4))
    # v10 also stores bone scale. The current Blender-side Bone DTO/creation
    # path does not use it, so consume it and keep the existing pipeline intact.
    ar.read_float_vector(3)
    return Bone(name, parent_index, position, rotation)


def read_socket(ar: FArchiveReader, scale: float) -> Socket:
    name = ar.read_fstring()
    parent_name = ar.read_fstring()
    position = _mirror_pos(ar.read_float_vector(3), scale)
    rotation = _mirror_quat(ar.read_float_vector(4))
    socket_scale = _mirror_pos(ar.read_float_vector(3), scale)
    return Socket(name, parent_name, position, rotation, socket_scale)


def read_virtual_bone(ar: FArchiveReader) -> VirtualBone:
    return VirtualBone(
        source_name=ar.read_fstring(),
        target_name=ar.read_fstring(),
        virtual_name=ar.read_fstring(),
    )


def read_skeleton(ar: FArchiveReader, scale: float) -> UEModelSkeleton:
    data = UEModelSkeleton()

    for name, payload in iter_attributes(ar):
        if name == "METADATA":
            data.metadata = UEModelSkeletonMetadata(payload.read_fstring())
        elif name == "BONES":
            data.bones = payload.read_serialized_array(lambda r: read_bone(r, scale))
        elif name == "SOCKETS":
            data.sockets = payload.read_serialized_array(lambda r: read_socket(r, scale))
        elif name == "VIRTUALBONES":
            data.virtual_bones = payload.read_serialized_array(read_virtual_bone)
        else:
            Log.warn(f"Unknown v10 skeleton attribute: {name}")

    return data


def read_collision(ar: FArchiveReader, scale: float) -> ConvexCollision:
    name = ar.read_fstring()
    vertices_count = ar.read_int()
    vertices = _mirror_pos(
        np.array(ar.read_float_vector(vertices_count * 3)).reshape(vertices_count, 3),
        scale,
    )
    indices_count = ar.read_int()
    indices = np.array(ar.read_int_vector(indices_count), dtype=np.int32).reshape(indices_count // 3, 3)
    return ConvexCollision(name=name, vertices=vertices, indices=indices)


def read_model(ar: FArchiveReader, scale: float) -> UEModel:
    data = UEModel()

    for name, payload in iter_attributes(ar):
        if name == "LODS":
            data.lods = payload.read_serialized_array(lambda r: read_lod(r, scale))
        elif name == "SKELETON":
            data.skeleton = read_skeleton(payload, scale)
        elif name == "COLLISION":
            data.collisions = payload.read_serialized_array(lambda r: read_collision(r, scale))
        else:
            Log.warn(f"Unknown v10 model attribute: {name}")

    return data
